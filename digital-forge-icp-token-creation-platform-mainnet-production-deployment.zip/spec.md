# Digital Forge ICP Token Creation Platform   Mainnet Production Deployment

## Overview
Digital Forge ICP is a production-ready Internet Computer application that enables users to create and deploy custom ICRC-2 tokens with built-in taxation features. The platform provides a user-friendly interface for token creation and management with integrated treasury fee collection and donation features, deployed on the Internet Computer mainnet.

## Authentication & Wallet Integration
- Internet Identity integration for secure user authentication
- **Production-grade ICP Web3 wallet connection functionality** supporting **Plug** and other popular mainnet wallets
- **Enhanced Plug wallet detection system** with improved reliability and user experience:
  - **Immediate detection initialization** that checks for `window.ic.plug` availability and sets detection state instantly
  - **Robust connection handling** with 30-second timeout and user alerts when Plug is missing
  - **Proper principal storage** ensuring connected wallet principal is correctly stored and managed
  - **Persistent session management** with disconnect and reconnect functionality for seamless user experience
  - **Safe component lifecycle handling** with proper initialization during mount and cleanup on unmount
  - **Enhanced error handling** with clear user feedback for connection failures and missing wallet scenarios
- **Enhanced connection persistence system**:
  - **Automatic reconnection functionality** using `await window.ic.plug.isConnected()` and `await window.ic.plug.requestConnect()` for previously authorized sessions
  - **localStorage persistence** for wallet principal and connection state across browser sessions
  - **Session recovery** that automatically re-establishes connections on page load if previously authorized
  - **Always-connected state maintenance** across page reloads ensuring seamless user experience
- **Manual retry functionality**:
  - **"Retry Detection" button** in wallet interface when status remains "Not Detected" for more than 2 seconds
  - **Manual detection trigger** calling `detectPlugWallet()` function on user request
  - **Reconnect Wallet functionality** in `WalletButton.tsx` dropdown for reinitializing detection
- **Enhanced visual feedback system**:
  - **Dynamic wallet button states** with glowing animation during detection and green pulse when connected
  - **Hover state messaging** showing "Plug Detected — Connect Now" once detection completes
  - **Real-time status indicators** displaying "Detecting" → "Detected" → "Connected" progression
  - **Toast notifications** for detection success/failure with detailed status information
- **Comprehensive debugging and diagnostics**:
  - **Visible debug logging** showing detection start, retry attempts, and success states in UI
  - **Console logging** with detailed information about detection attempts and wallet state
  - **5-second timeout messaging** displaying in-app prompts when Plug isn't found, suggesting reload or extension re-enabling
  - **Permission validation** with detailed console logs confirming injection status and authorization state
- **Persistent connection state caching** in sessionStorage and localStorage for seamless reload recovery ensuring users never lose their connection during minting
- **Post-window-load initialization** ensuring Plug provider initialization only occurs after the browser window fully loads to prevent race condition failures
- **Wallet connection state management** with connection status indicators and wallet switching capabilities
- **Wallet address display** and connection confirmation in the UI
- **Enhanced wallet authorization retry logic** that preserves all user token creation inputs across connection attempts
- **Locked wallet detection** with clear error messaging when Plug wallet is locked or transactions are rejected, preventing unnecessary redirects
- **Verified connection flow** ensuring connection prompts trigger correctly and signature flow can proceed without page reloads
- **Extended wallet confirmation logic** that waits indefinitely until the user confirms or cancels the Plug signature, ensuring the transaction popup stays open for as long as necessary

## Core Features

### Token Creation Wizard
A four-step process for creating custom tokens:

1. **Basic Info**: Token name, symbol, description, total supply, and decimals
   - Media upload capability supporting PNG, JPEG, GIF, MP4, MP3 formats
   - File size validation with 50 MB maximum limit
   - **Strict 1:1 square aspect ratio enforcement (512 × 512 px)** with smart center-cropping and scaling for all uploaded token emblems
   - **Intelligent center-cropping and scaling** for non-square media to maintain proportion without distortion
   - **Enhanced upload preview containers** with consistent border radius, drop-shadow, and alignment matching the Digital Forge emblem aesthetic
   - **Optimized preview system** prepared for static and animated media (image, GIF, MP4) with cohesive grid display optimization
   - Optional description field for token details
2. **Tax Configuration**: 
   - **Individual module-based tax configuration only** - no global buy/sell tax input fields
   - Dynamic collapsible module system for Treasury, Burn, Reflection, Liquidity, Yield, and Support options
   - Each module button creates expandable configuration sections with smooth animated transitions
   - Multiple instances per module type supported with individual remove controls
   - Module-specific configuration fields:
     - **Treasury**: Buy Tax % and Sell Tax % inputs with "Unify" toggle for synchronized percentages, Split toggle for dual-side configuration, and **Treasury Wallet Address** input field labeled "Your Project's Treasury Wallet Address" with placeholder text "Paste your project treasury wallet address…" and real-time address format validation
     - **Burn**: Buy Tax % and Sell Tax % inputs with "Unify" toggle for synchronized percentages, Split toggle for dual-side configuration
     - **Reflection**: Buy Tax % and Sell Tax % inputs with "Unify" toggle for synchronized percentages, Split toggle for dual-side configuration, **with automatic self-token reflection targeting the minted token's canister ID**
     - **Liquidity**: Buy Tax % and Sell Tax % inputs with "Unify" toggle for synchronized percentages, Split toggle for dual-side configuration, **with automatic burn address routing for all LP tokens**
     - **Yield**: Percentage input with Split toggle and Reward Token Address field
     - **Support**: Percentage input with Split toggle and **Token Address field** for designating another project's token to burn
   - **Real-time tax aggregation system** that automatically calculates total buy and sell tax percentages from all active modules
   - **Tax range validation** ensuring combined totals stay between 0.25% and 25% for both buy and sell taxes
   - **Dynamic total tax summary display** showing real-time calculated "Total Buy Tax" and "Total Sell Tax" percentages
   - Helper text explaining that totals are automatically calculated from active modules - no manual total entry required
   - Total tax summary includes note: "Includes automatic 0.25% treasury fee on all transactions"
3. **Advanced Settings**: Additional token parameters and features
4. **Review**: Final confirmation before deployment with "Confirm Payment & Deploy" modal that handles ICP payment and deployment confirmation
   - **Verified Plug connection requirement** ensuring minting cannot proceed unless a verified Plug connection and account principal are active
   - **Form and payment state persistence** through reconnect cycles, preventing restarts after detection delays
   - **Final tax summary section** displaying calculated "Total Buy Tax" and "Total Sell Tax" before minting
   - **Liquidity burn confirmation** indicating that all LP tokens created during minting are automatically sent to a permanent burn address and are non-recoverable
   - Tax validation confirmation before allowing deployment
   - **Enhanced Web3 wallet payment integration** with reliable Plug wallet detection and proper signing window triggering
   - **Mandatory 1 ICP minting fee requirement** with funds sent to treasury wallet `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936`
   - **Strict wallet signature confirmation requirement** - mint process proceeds only after confirmed wallet signature and successful on-chain ICP transfer
   - **Enhanced transaction status handling** for both successful and declined wallet transactions with clear UI feedback
   - **Robust deployment error handling** with detailed error messages and complete form state preservation across all connection and payment attempts
   - **Enhanced variant response processing** with proper serialization/deserialization validation
   - **Persistent form data management** that preserves all user token creation inputs across wallet connection attempts and authorization retries
   - **Real-time on-chain mint flow execution** with immediate dashboard and Forged Tokens UI updates upon successful completion
   - **Success/failure feedback system** with clear status indicators and next steps
   - **Locked wallet error handling** displaying clear error messages when Plug wallet is locked or transactions are rejected instead of redirecting to download page
   - **Canister ID display and copy-to-clipboard** functionality showing the real deployed token's Canister ID upon successful deployment for ICPSwap/Sonic liquidity addition
   - **Comprehensive backend error handling** with structured success/error responses preventing silent failures and canister traps
   - **Detailed error logging and feedback** providing human-readable error messages for payment verification, authorization, and mint fee validation failures
   - **Progressive status messaging** displaying "Payment verified — awaiting token creation" and specific failure reasons instead of generic error screens
   - **Extended wallet confirmation logic** that waits indefinitely until the user confirms or cancels the Plug signature
   - **Visible "✅ Token Created Successfully" confirmation** displayed to the UI after successful minting with valid Canister ID
   - **Guaranteed transaction completion** ensuring that when Plug wallet confirmation completes, the backend `createToken` function executes fully, writes token metadata to the registry, and returns the minted token's Canister ID and success message
   - **Robust exception handling** in `recordPayment` and `createToken` functions that catch and log all exceptions while returning explicit success or error messages instead of trapping
   - **Detailed user-facing error messages** for known failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other specific error conditions
   - **Transaction status response codes** for improved reliability and frontend synchronization

### Forged Tokens Community Explorer
A comprehensive community explorer for discovering and analyzing all minted tokens:

- **Universal Token Display**: Shows all tokens forged on the platform regardless of creator with automatic `communityExplorer = true` setting for newly minted tokens
- **Real-time UI updates** that immediately reflect newly minted tokens after successful on-chain deployment
- **Enhanced Token Discovery Grid**: Responsive card layout displaying all community-minted tokens with full branding support
- **Enhanced Token Card Details**: Each token card displays:
  - **Strict 1:1 square aspect ratio token emblems (512 × 512 px)** with consistent styling (border radius, shadow)
  - **Uniform emblem thumbnails** with smart center-cropping and scaling for cohesive grid display
  - Token name, symbol, and creator information
  - Total supply and circulating supply
  - Buy tax and sell tax rates for all configured modules
  - Treasury fee percentage and creation date
  - **Uniformly styled emblem previews** maintaining strict square aspect ratio across all card sizes
  - Short description text
  - Mint status and deployment information
  - Dynamic description and token metadata
  - View count, like count, and comment count display
- **Interactive Token Selection**: Click-to-select token cards with visual selection indicators
- **Enhanced Dexscreener Integration**: 
  - Embedded Dexscreener widget displayed in modal or expanded card view when token is selected
  - **Widget positioned beneath square emblem display** with proper visual alignment
  - Live price charts and trading data display
  - Responsive chart embedding with accurate visualization
- **Token Detail Modal**: Interactive modal system with smooth transitions showing:
  - **Strict 1:1 square aspect ratio emblem display (512 × 512 px)** with consistent styling
  - **Uniform emblem thumbnails** with smart center-cropping and scaling
  - Detailed token information and community insights
  - Chart preview integration via Dexscreener widget positioned below emblem
  - Creator details and token metadata
  - **Uniformly styled emblem display** with proper alignment on desktop and mobile
  - Comment and interaction features
- **Enhanced Filtering and Search**:
  - Search functionality by token name, symbol, or creator
  - Dynamic filter options by views, likes, tags, creation date ranges, tax rates, and token status
  - Sort options by creation date, name, total supply, treasury fee, views, or likes
- **Community Interaction Features**:
  - Like functionality for tokens with count tracking
  - Comment system for token discussions
  - View count tracking for token popularity metrics
- **Live Data Refresh**: Server connection to pull all tokens via `getForgedTokens` endpoint with automatic refresh capabilities and error handling
- **Real-time data synchronization** displaying accurate mint confirmation and on-chain metrics immediately after successful transactions
- **Enhanced Media Preview System**: **Strict 1:1 square aspect ratio enforcement (512 × 512 px)** for all token emblems with smart center-cropping, scaling, thumbnail generation, video previews, audio previews, and comprehensive preview capabilities

### Token Management Dashboard
- **User-Specific Activity Metrics**: Displays personalized statistics for authenticated users including:
  - Number of tokens minted by the user
  - Treasury configurations created
  - Total fees paid for token creation
  - User's token deployment history
  - Personal token performance metrics
- **Global Platform Statistics**: Shows platform-wide metrics visible to all users including:
  - Total tokens created on the platform
  - Total supply across all tokens
  - Platform-wide treasury fee collection
  - Community engagement statistics
- **Your Tokens Section**: Token dashboard displaying user's created tokens with **uniform square emblem thumbnails (512 × 512 px)**
- **Smart center-cropping and scaling** for emblem display consistency
- View token details and statistics
- Access to deployed token information
- **Real-time transaction and supply data refresh** displaying accurate mint confirmation and on-chain metrics immediately after successful wallet transactions with enhanced live updates

### Token Lookup System
A dedicated page accessible from the navigation bar for token discovery and analysis:

- **Search Interface**: Clean search bar for entering token Canister ID or transaction hash
- **Token Metadata Display**: Comprehensive token information layout similar to ICARIA design including:
  - **General Information Section**: Token address, name, symbol, initial supply, current supply, ownership status, trading status
  - **Tax Information Section**: Detailed breakdown of all configured tax modules with rates and reward tokens
  - **Treasury Fee Display**: Shows the automatic 0.25% treasury fee and any custom treasury configurations
  - **Module Configuration Details**: Lists all active modules (Treasury, Burn, Reflection, Liquidity, Yield, Support) with their specific settings
  - **Copy-to-clipboard functionality** for token addresses and important data
- **Error Handling**: Proper error messages for invalid canister IDs or tokens not found
- **Responsive Design**: Maintains dark theme with purple/blue gradients consistent with platform styling
- **Navigation Integration**: Seamlessly integrated with existing navigation structure

### Media Upload System
- File upload integration during token creation process
- Support for PNG, JPEG, GIF, MP4, MP3 formats
- File size validation with 50 MB maximum limit
- **Strict 1:1 square aspect ratio processing (512 × 512 px)** with intelligent center-cropping and scaling for non-square uploads
- **Smart center-cropping and scaling** to maintain proportion without distortion
- Caffeine blob storage integration for media files
- Media URL linking in backend token metadata with proper token association including `mediaUrl` and `mediaType` fields
- **Uniform square thumbnail generation (512 × 512 px)** for community explorer preview

### Payment System
- **Enhanced Web3 wallet integration** for ICP payment processing with support for **Plug** and other popular mainnet wallets
- **Improved Plug wallet detection** with immediate state setting and robust connection handling
- **Enhanced connection persistence** with automatic reconnection using `isConnected()` and `requestConnect()` methods plus localStorage state management
- **Manual retry functionality** with "Retry Detection" and "Reconnect Wallet" buttons for user-initiated detection
- **Enhanced visual feedback system** with dynamic button states, hover messaging, and real-time status progression
- **Comprehensive debugging system** with visible logging, console diagnostics, timeout messaging, and permission validation
- **Mandatory 1 ICP minting fee** for token creation payable to treasury wallet `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936`
- **Strict wallet signature requirement** - mint process proceeds only after confirmed wallet signature and successful on-chain ICP transfer
- **Enhanced payment verification and validation** - backend validates ICP payment confirmation before token deployment
- **Robust transaction status handling** for successful and declined wallet transactions with clear UI feedback
- **Complete form state preservation** across all wallet connection attempts and authorization retries
- **Enhanced payment error handling** with retry mechanisms and detailed error feedback
- **Payment state persistence** to prevent duplicate charges on retry attempts
- **Real-time transaction confirmation** with immediate data refresh on successful payments and on-chain mint execution
- **Locked wallet error handling** with clear error messaging when Plug wallet is locked or transactions are rejected
- **Signed Plug transaction flow** ensuring proper payment record creation in backend followed by verification and on-chain token deployment returning real Canister ID
- **Comprehensive backend error handling** preventing silent failures with structured success/error responses instead of canister traps
- **Detailed error logging and human-readable feedback** for payment verification, authorization, and mint fee validation failures
- **Extended wallet confirmation logic** that waits indefinitely until the user confirms or cancels the Plug signature, ensuring the transaction popup stays open for as long as necessary
- **Guaranteed payment completion flow** ensuring that `recordPayment` and `createToken` functions properly catch and log all exceptions while returning explicit success or error messages instead of trapping
- **Comprehensive exception handling** in backend payment functions that ensures the frontend never receives unhandled null responses or crashes
- **Detailed user-facing error messages** for specific failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other known error conditions
- **Transaction status response codes** for improved reliability and frontend synchronization with the backend payment verification process

### Buy Me a Coffee Feature
- "Buy me a Coffee ☕" donation component with wallet address `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936`
- Positioned as a small, subtle link with icon and short text in the footer area, bottom-left alignment
- Placed directly next to or under "Powered by Internet Computer" text
- Copy-to-clipboard functionality for wallet address
- Minimal, dark-theme-friendly styling with modest hover effects
- Visible across all pages including the community token explorer and token lookup
- Does not block or overlap any interface elements

## Enhanced Fee-on-Transfer System

### Automatic Proportional Distribution Logic
- **Validated Automatic Fee-on-Transfer Implementation**: All minted tokens implement validated fee-on-transfer functionality that triggers on every buy/sell transaction with comprehensive testing
- **Validated Proportional Shareholder Distribution**: All configured tax percentages (Treasury, Burn, Reflection, Liquidity, Yield, Support) are automatically distributed proportionally to token holders based on their ownership percentages with mathematical precision validation
- **Real-time Balance Calculation with Validation**: The system calculates current token holder balances and ownership percentages at the time of each transaction with accuracy verification
- **Multi-Module Distribution with Testing**: Each configured module (Treasury, Burn, Reflection, Liquidity, Yield, Support) distributes its respective percentage proportionally across all shareholders with comprehensive validation
- **Validated Self-Token Reflection System**: Reflection modules automatically distribute rewards in the same token being transacted (using the token's own canister ID) proportionally to shareholders with end-to-end testing
- **Validated Reward Token Integration**: Yield modules distribute rewards in the specified reward token address proportionally to shareholders with end-to-end testing
- **Validated Support Token Integration**: Support modules distribute rewards to the specified token address for burning proportionally to shareholders with comprehensive verification
- **Treasury Module Custom Address Support**: Treasury modules distribute rewards to the user-specified treasury wallet address proportionally to shareholders, separate from the fixed 0.25% builder fee
- **Automatic Liquidity Burn System**: All LP tokens created during liquidity provision are automatically sent to a permanent burn address (non-recoverable) with no routing to developer or creator wallets
- **Elimination of Manual Recipients**: The system completely eliminates manual tax recipient configuration - all distributions are automatic and proportional with validation

### Fixed Treasury Fee System with Validation
- **Validated Static 0.25% Treasury Fee**: Every transaction automatically deducts a fixed 0.25% treasury fee routed exclusively to developer wallet `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` with routing verification
- **Separate from User Configurations**: The 0.25% treasury fee operates independently of user-configured tax modules with isolation testing
- **Universal Application with Validation**: Applied to all buy/sell transactions, transfers, and reward distributions with comprehensive verification

### Developer Wallet Whitelist System
- **Developer Wallet Whitelist**: Wallet address `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` is completely whitelisted from all fees and restrictions
- **No Mint Fees**: Developer wallet pays no 1 ICP minting fees when creating tokens
- **No Transaction Fees**: Developer wallet pays no 0.25% fee-on-transfer fees on any transactions
- **No Swap Restrictions**: Developer wallet has unrestricted swap capabilities on all tokens
- **Full Reward Eligibility**: Developer wallet receives full proportional rewards from all tax modules based on token holdings

### Validated Transaction Processing Flow
- **Validated Buy Transaction Processing**: 
  1. Check if sender is developer wallet - if yes, skip all fees and restrictions
  2. Deduct 0.25% treasury fee to developer wallet with routing verification
  3. Calculate and distribute each configured module's buy tax percentage proportionally to all token holders with mathematical validation
  4. Process self-token reflection distributions for Reflection modules using the token's own canister ID with end-to-end testing
  5. Process reward token distributions for Yield modules with end-to-end testing
  6. Process token distributions for Support modules with comprehensive verification
  7. Process treasury distributions to user-specified treasury addresses for Treasury modules
  8. **Automatically burn all LP tokens to permanent burn address for Liquidity modules**
- **Validated Sell Transaction Processing**:
  1. Check if sender is developer wallet - if yes, skip all fees and restrictions
  2. Deduct 0.25% treasury fee to developer wallet with routing verification
  3. Calculate and distribute each configured module's sell tax percentage proportionally to all token holders with mathematical validation
  4. Process self-token reflection distributions for Reflection modules using the token's own canister ID with end-to-end testing
  5. Process reward token distributions for Yield modules with end-to-end testing
  6. Process token distributions for Support modules with comprehensive verification
  7. Process treasury distributions to user-specified treasury addresses for Treasury modules
  8. **Automatically burn all LP tokens to permanent burn address for Liquidity modules**
- **Validated Automatic Execution**: All distributions occur automatically without manual intervention or recipient specification with comprehensive testing

### Permanent Liquidity Burn System
- **Constant Burn Address**: All LP tokens are sent to a permanent burn address (e.g., zero principal "aaaaa-aa" or standard dead address) that is non-recoverable
- **No Developer/Creator Routing**: Complete removal of any conditional checks that route liquidity to developer or creator wallets
- **Automatic Burn Processing**: All liquidity created during token minting is automatically burned without user intervention
- **Permanent Lock Confirmation**: UI confirmation text indicates that all liquidity is automatically burned and permanently locked during token creation

## Enhanced Frontend-Backend Data Validation

### Robust Variant Handling
- **Comprehensive Variant Validation**: All React Query hooks in `useQueries.ts` implement robust variant handling with null checks for canister query and mutation responses
- **Defensive Decoding**: Safe handling of empty or malformed variant types for `getToken`, `getForgedTokens`, `lookupToken`, and module-related queries
- **Inline Data Validation**: Each render component (CreateTokenWizard, ForgedTokens, Dashboard, TokenLookup) includes inline checks for missing variant payloads (`if (!data || !data.value) return;`) to prevent frontend crashes
- **User-Friendly Fallbacks**: Replace raw variant logs with user-friendly messages like "No data available yet" for better user experience
- **Backend Query Consistency**: All backend `query` functions consistently return valid variants with properly unwrapped data (e.g., `?metadata` handled correctly or `null` managed appropriately)
- **Enhanced Deployment Response Handling**: Robust processing of deployment responses with proper variant serialization/deserialization
- **Enhanced Form State Preservation**: Maintain all user form data across wallet connection attempts, authorization retries, and submission attempts to prevent reset after errors
- **Detailed Error Feedback**: Provide specific error messages for deployment failures with actionable guidance

### Error Handling and Recovery
- **Graceful Error States**: Frontend components handle missing or invalid data gracefully without crashing
- **Loading State Management**: Proper loading states while data is being fetched or validated
- **Error Message Display**: Clear, user-friendly error messages when data validation fails
- **Retry Mechanisms**: Automatic retry logic for failed queries with exponential backoff
- **Data Integrity Checks**: Validation of data structure and types before rendering components
- **Deployment Error Recovery**: Specific error handling for deployment failures with form state preservation
- **Payment Error Handling**: Robust payment error processing with retry capabilities and state management
- **Enhanced Wallet Transaction Error Handling**: Proper error handling for declined wallet transactions, connection failures, signature rejections, and Plug wallet detection issues
- **Token Lookup Error Handling**: Proper error handling for invalid canister IDs and token not found scenarios
- **Locked Wallet Error Handling**: Clear error messaging when Plug wallet is locked or transactions are rejected

### Comprehensive Backend Error Handling
- **Structured Response System**: All backend functions return structured success/error responses using Result variants instead of trapping the canister
- **Exception Catching and Logging**: Comprehensive try-catch blocks in `recordPayment`, `verifyPaymentWithLedger`, and `createToken` functions with detailed error logging
- **Payment Verification Error Handling**: Specific error handling for payment verification failures, authorization issues, and mint fee validation problems
- **Human-Readable Error Messages**: All error responses include clear, actionable error messages for frontend display
- **Progressive Status Messaging**: Backend provides specific status updates like "Payment verified — awaiting token creation" and detailed failure reasons
- **Transaction State Persistence**: Backend maintains transaction state to prevent duplicate processing and provide consistent error recovery
- **Comprehensive Logging System**: Detailed logging of all exceptions, payment states, and transaction attempts for debugging and monitoring with context including payer ID, payment ID, and timestamp
- **Frontend Error Integration**: Backend error responses are properly consumed by `useQueries.ts` and displayed in toast notifications instead of causing application crashes or blank "Application error" screens
- **No Silent Failures**: Backend never triggers `Debug.trap` on recoverable user errors - all errors return structured variant responses with human-readable messages
- **Robust Try-Catch Wrapping**: All critical backend operations (`recordPayment`, `verifyPaymentWithLedger`, `createToken`) are wrapped in comprehensive try-catch handlers that capture any Motoko traps or failures
- **Detailed Error Logging**: All caught exceptions are logged to the console with detailed error information for admin diagnosis instead of throwing traps
- **Structured Variant Responses**: All payment and mint operations return structured variant responses (`#success`, `#error`) with human-readable messages for frontend consumption
- **Toast Notification Integration**: Frontend displays backend error messages clearly through toast notifications, preventing white "Application error occurred" screens
- **Guaranteed Exception Handling**: The `recordPayment` and `createToken` functions must properly catch and log all exceptions while returning explicit success or error messages instead of trapping, ensuring the frontend never receives unhandled null responses or crashes
- **Comprehensive Transaction Completion**: When Plug wallet confirmation completes, the backend `createToken` function must execute fully, write token metadata to the registry, and return the minted token's Canister ID and success message
- **Detailed User-Facing Error Messages**: Backend provides specific error messages for known failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other identifiable error conditions instead of generic crashes
- **Transaction Status Response Codes**: Backend implements transaction status response codes to improve reliability and frontend synchronization with the payment verification and token creation process

## Cinematic Molten-Forge Blue-Magenta-Cyan UI Design

### Visual Design System
- **Cinematic molten-forge theme** with glowing blue-magenta-cyan gradients and molten ember visuals throughout the application
- **Animated forge hero** on landing page with dynamic fire and ember effects in blue-magenta-cyan color palette
- **Branded Digital Forge emblem** prominently displayed across all major sections:
  - Landing page header and hero section
  - Token creation wizard header
  - Dashboard header and navigation
  - Community explorer header
  - Footer branding
- **Glowing gradient backgrounds** with blue, magenta, cyan, and molten metal tones
- **Molten metal visual effects** for buttons, cards, and interactive elements with blue-magenta-cyan color scheme
- **Animated transitions** with forge-inspired effects for page navigation and component interactions
- **Cinematic lighting effects** with dynamic shadows and highlights in blue-magenta-cyan palette
- **Ember particle animations** for background ambiance and interactive feedback with blue-magenta-cyan glow

### Component Styling
- **Glowing button states** with molten blue-magenta-cyan hover effects and pulsing animations
- **Metallic card designs** with forge-inspired borders and shadow effects in blue-magenta-cyan theme
- **Animated progress indicators** with molten metal flow animations in blue-magenta-cyan colors
- **Neon text highlights** for important information and call-to-action elements with blue-magenta-cyan glow
- **Forge-themed icons** and visual elements throughout the interface with blue-magenta-cyan accents
- **Dynamic background patterns** with subtle ember and flame motifs in blue-magenta-cyan palette
- **Responsive glow effects** that adapt to user interactions and system states with blue-magenta-cyan theme

## Mainnet Production Deployment Requirements

### Internet Computer Mainnet Deployment
- **Production-ready canister deployment** on Internet Computer mainnet with optimized performance and security
- **Mainnet-compatible wallet integration** with verified Plug wallet detection and signing functionality
- **Live ICP payment processing** with real treasury wallet routing and transaction confirmation
- **On-chain token deployment** with actual Canister ID generation and display for ICPSwap/Sonic integration
- **Production-grade security hardening** with comprehensive audit trails and monitoring
- **Scalable architecture** optimized for mainnet performance and user load
- **Real-time data synchronization** with immediate updates after successful transactions
- **Enhanced error handling** for production environment with robust recovery mechanisms
- **Complete English language content** throughout the application interface
- **Mainnet-ready fee-on-transfer functionality** with validated proportional distribution logic
- **Production wallet persistence** ensuring connection state maintains across browser sessions
- **Live transaction processing** with actual on-chain execution and confirmation
- **Comprehensive backend error handling** preventing silent failures and canister traps in production environment
- **Robust payment verification system** with detailed error logging and human-readable feedback for production transactions
- **Guaranteed transaction completion system** ensuring that backend payment and token creation functions execute fully and return proper success/error responses without trapping

### Deployment Validation Checklist
- Backend canister compilation and optimization for mainnet
- Fee-on-transfer logic validation and testing on mainnet
- Proportional distribution algorithm verification with live transactions
- Self-token reflection logic validation and testing on mainnet
- Support token burning logic validation and testing on mainnet
- Developer wallet whitelist logic validation and testing on mainnet
- Treasury fee routing confirmation to developer wallet on mainnet
- Liquidity burn address validation and testing on mainnet
- Module configuration processing validation on mainnet
- Inter-canister communication testing on mainnet
- **Production Web3 wallet payment system integration verification** with improved Plug wallet detection
- **Enhanced wallet detection system validation** with immediate state setting and robust connection handling on mainnet
- **Connection persistence system validation** with automatic reconnection and session recovery on mainnet
- **Manual retry system validation** for "Retry Detection" and "Reconnect Wallet" functionality on mainnet
- **Visual feedback system validation** with dynamic button states, hover messaging, and status progression for detection success/failure notifications on mainnet
- **Debugging system validation** for visible logging, console diagnostics, and timeout messaging functionality on mainnet
- **LocalStorage validation** for connection state and wallet principal persistence across browser sessions and reloads on mainnet
- **Production ICP payment validation and confirmation workflow testing** with strict signature requirements on mainnet
- **Treasury wallet routing validation for 1 ICP minting fees** on mainnet
- Token metadata and media handling validation on mainnet
- Community explorer integration testing on mainnet
- Dashboard metrics integration testing on mainnet
- Token lookup system integration testing on mainnet
- Wallet connectivity and transaction processing on mainnet
- Error handling and recovery mechanisms on mainnet
- Performance optimization for mainnet load
- Security audit and validation completion for mainnet
- **Production deployment response handling validation** on mainnet
- **Production form state preservation during deployment validation** across all wallet connection attempts on mainnet
- **Success/error feedback system validation** on mainnet
- **Real-time data refresh validation after successful transactions** with immediate UI updates on mainnet
- **Canister ID display and copy-to-clipboard validation** for ICPSwap/Sonic integration readiness on mainnet
- **Brave browser compatibility validation** with Shields off support verified on mainnet
- **Cinematic molten-forge blue-magenta-cyan UI validation** with complete visual design system implementation on mainnet
- **Backend error handling validation** ensuring no silent failures or canister traps during payment confirmation and token minting on mainnet
- **Structured response system validation** confirming all backend functions return proper success/error variants on mainnet
- **Exception handling validation** for comprehensive try-catch coverage in payment and token creation functions on mainnet
- **Human-readable error message validation** ensuring clear feedback reaches frontend users on mainnet
- **Progressive status messaging validation** for payment verification and token creation status updates on mainnet
- **Extended wallet confirmation validation** ensuring transaction popup stays open indefinitely until user confirms or cancels on mainnet
- **Toast notification validation** for backend error messages displayed to users instead of application crashes on mainnet
- **Try-catch wrapper validation** for all critical backend operations preventing Motoko traps and failures on mainnet
- **Error logging validation** ensuring all exceptions are logged to console with detailed information for admin diagnosis on mainnet
- **Structured variant response validation** confirming all payment and mint operations return proper `#success`/`#error` variants on mainnet
- **Frontend toast integration validation** ensuring backend error messages display clearly through toast notifications on mainnet
- **Transaction completion validation** ensuring `recordPayment` and `createToken` functions execute fully and return proper responses without trapping on mainnet
- **Exception handling validation** confirming all backend payment functions catch and log exceptions while returning explicit success/error messages on mainnet
- **User-facing error message validation** ensuring specific error messages for payment mismatch, invalid timestamp, treasury address mismatch, and other known failure cases on mainnet
- **Transaction status response code validation** confirming improved reliability and frontend synchronization with backend payment verification process on mainnet

## Backend Architecture

### Token Factory Canister
- Manages token creation registry on mainnet
- **Automatically sets `communityExplorer = true` for all newly minted tokens** to ensure universal visibility
- Deploys new ICRC-2 token instances dynamically with enhanced fee-on-transfer functionality on mainnet
- Handles inter-canister communication with Treasury on mainnet
- Stores comprehensive token metadata including media URLs with `mediaUrl` and `mediaType` fields, total supply, and detailed tax configurations
- **Processes strict 1:1 aspect ratio media validation and storage (512 × 512 px)** with smart center-cropping and scaling metadata
- **Handles intelligent center-cropping and scaling** for non-square media uploads
- Processes treasury fee collection logic on mainnet
- **Production ICP payment verification from Web3 wallets before token deployment** with improved Plug wallet integration
- **Strict wallet signature validation preventing simulated or unsigned mints** on mainnet
- **Routes 1 ICP minting fees to treasury wallet** `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936` on mainnet
- **Implements developer wallet whitelist** for `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` exempting from all fees and restrictions on mainnet
- Processes dynamic module configurations from frontend including multiple instances per module type
- **Stores treasury wallet addresses from Treasury module configurations** with proper validation and association
- **Stores token addresses from Support module configurations** with proper validation for burning functionality
- **Automatically configures Reflection modules to use the token's own canister ID** for self-token reward distributions
- **Implements permanent burn address constant** for all liquidity burns (e.g., zero principal "aaaaa-aa" or standard dead address)
- **Validates aggregated tax totals from frontend ensuring they fall within 0.25% to 25% range for both buy and sell taxes**
- **Rejects token creation if aggregated tax totals exceed allowed range**
- Implements comprehensive testing endpoints for validation workflows
- **Manages uniform square emblem file references (512 × 512 px)** and blob storage integration with proper token association including `mediaUrl` and `mediaType` binding
- **Provides production `getForgedTokens` endpoint for community explorer** returning all tokens regardless of creator with filtering and sorting capabilities including views, likes, and tags
- **Provides `lookupToken` endpoint** for token lookup by canister ID or transaction hash
- **Provides user activity metrics endpoints** for dashboard statistics including tokens minted, treasury configurations, and fees paid
- Stores additional metadata for community features including creator details, dynamic descriptions, and community interaction data
- Manages community interaction backend logic for likes, comments, and view count tracking
- **Production Fee-on-Transfer Configuration**: Stores and manages all module configurations for automatic proportional distribution logic on mainnet
- **Self-Token Reflection Configuration**: Automatically assigns the token's canister ID to Reflection modules during token creation on mainnet
- **Support Token Burning Configuration**: Stores and manages token addresses for Support module burning functionality on mainnet
- **Liquidity Burn Configuration**: Stores and enforces permanent burn address routing for all LP tokens with no developer/creator routing options on mainnet
- **Developer Wallet Whitelist Configuration**: Stores and enforces developer wallet exemptions from all fees and restrictions on mainnet
- **Validation and Testing Infrastructure**: Comprehensive backend validation functions for distribution logic, state persistence, and error handling on mainnet
- **Robust Variant Response Handling**: Ensures all query functions return properly structured variants with valid data payloads and proper null handling
- **Production Deployment Response Processing**: Ensures all deployment responses are properly serialized and wrapped before returning to frontend
- **Production Web3 Wallet Payment Integration**: Robust payment processing with wallet signature validation and confirmation handling including improved Plug wallet detection
- **Real-time Data Refresh Support**: Provides immediate data updates after successful wallet transactions and on-chain mint execution
- **Mainnet deployment optimization** with performance tuning and security hardening
- **Comprehensive Error Handling System**: Implements structured success/error responses using Result variants instead of canister traps
- **Exception Catching and Logging**: Try-catch blocks in all critical functions (`recordPayment`, `verifyPaymentWithLedger`, `createToken`) with detailed error logging for payment verification, authorization, and mint fee validation
- **Human-Readable Error Response Generation**: All error conditions return clear, actionable error messages for frontend display
- **Transaction State Management**: Maintains payment and deployment state to prevent duplicate processing and ensure consistent error recovery
- **Progressive Status Communication**: Provides specific status updates throughout the payment and token creation process
- **Context-Rich Logging**: All exception logging includes payer ID, payment ID, timestamp, and sufficient context for debugging validation logic
- **No Silent Failures**: Never triggers `Debug.trap` on recoverable user errors - all errors return structured variant responses
- **Robust Try-Catch Wrapping**: All critical backend operations (`recordPayment`, `verifyPaymentWithLedger`, `createToken`) are wrapped in comprehensive try-catch handlers that capture any Motoko traps or failures
- **Detailed Error Logging**: All caught exceptions are logged to the console with detailed error information for admin diagnosis instead of throwing traps
- **Structured Variant Responses**: All payment and mint operations return structured variant responses (`#success`, `#error`) with human-readable messages for frontend consumption
- **Guaranteed Exception Handling in Payment Functions**: The `recordPayment` and `createToken` functions must properly catch and log all exceptions while returning explicit success or error messages instead of trapping, ensuring the frontend never receives unhandled null responses or crashes
- **Complete Transaction Execution**: When Plug wallet confirmation completes, the `createToken` function must execute fully, write token metadata to the registry, and return the minted token's Canister ID and success message
- **Specific User-Facing Error Messages**: Backend provides detailed error messages for known failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other identifiable error conditions instead of generic crashes
- **Transaction Status Response Codes**: Implements transaction status response codes to improve reliability and frontend synchronization with the payment verification and token creation process

### Token Template Canister
- ICRC-2 compatible token implementation with enhanced fee-on-transfer functionality on mainnet
- **Validated Automatic Proportional Distribution System**: Implements automatic fee-on-transfer that distributes all configured tax percentages proportionally to token holders based on ownership percentages with comprehensive validation on mainnet
- **Real-time Balance Calculation with Verification**: Calculates current token holder balances and ownership percentages for each transaction with accuracy testing on mainnet
- **Multi-Module Distribution Logic with Validation**: Supports multiple instances per module type (Treasury, Burn, Reflection, Liquidity, Yield, Support) with independent proportional distributions and comprehensive testing on mainnet
- **Self-Token Reflection Implementation**: Reflection modules automatically distribute rewards in the same token using the token's own canister ID with comprehensive validation on mainnet
- **Treasury Address Distribution Support**: Processes Treasury module distributions to user-specified treasury wallet addresses with validation on mainnet
- **Validated Reward Token Integration**: Processes Yield module distributions in specified reward token addresses with end-to-end verification on mainnet
- **Validated Support Token Burning Integration**: Processes Support module distributions to specified token addresses for burning with comprehensive testing on mainnet
- **Automatic Liquidity Burn Implementation**: All LP tokens created during liquidity provision are automatically sent to permanent burn address with no recovery options on mainnet
- **Validated Automatic 0.25% Treasury Fee**: Fixed treasury fee on all transactions routed exclusively to developer wallet `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` with routing verification on mainnet
- **Developer Wallet Whitelist Implementation**: Complete exemption of developer wallet from all fees, restrictions, and limitations with full reward eligibility on mainnet
- **Elimination of Manual Recipients**: Completely eliminates need for manual tax recipient configuration through automatic proportional distribution with validation on mainnet
- Standard token operations (transfer, approve, etc.) with enhanced fee-on-transfer processing on mainnet
- **Validated Transaction Processing Logic**: Comprehensive buy/sell transaction processing with automatic distribution execution and testing on mainnet
- Testing and validation methods for fee distribution and reward calculations on mainnet
- Enhanced metadata exposure for community explorer integration
- **Distribution Logging with Validation**: Comprehensive logging of all proportional distributions and calculations with audit trails on mainnet
- **Self-Token Reflection Logging**: Comprehensive logging of all self-token reflection distributions with audit trails on mainnet
- **Support Token Burning Logging**: Comprehensive logging of all Support module token burning distributions with audit trails on mainnet
- **Liquidity Burn Logging**: Comprehensive logging of all LP token burns to permanent address with audit trails on mainnet
- **Developer Wallet Exemption Logging**: Comprehensive logging of all developer wallet exemptions and reward distributions on mainnet
- **Validation Functions**: Built-in testing and validation methods for distribution accuracy and system integrity on mainnet
- **Consistent Variant Responses**: Ensures all query responses use proper variant structures with valid data payloads
- **Production Deployment Response Handling**: Proper response serialization for deployment confirmation
- **Mainnet optimization** with gas efficiency and performance improvements

### Treasury Canister
- **Collects and manages 1 ICP minting fees to treasury address** `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936` on mainnet
- **Collects and manages 0.25% treasury fees to developer address** `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` on mainnet
- Handles automatic 0.25% treasury fee collection from token operations with validation on mainnet
- **Production Web3 wallet payment verification** for token creation with signature validation and improved Plug wallet detection
- **Strict prevention of simulated or unsigned mints** by requiring confirmed wallet signatures and successful on-chain ICP transfers on mainnet
- **Implements developer wallet whitelist** exempting `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` from all fees on mainnet
- Fee management and accounting on mainnet
- Records and manages state updates for all token creations and payments on mainnet
- **Tracks user activity metrics** including tokens minted, treasury configurations, and fees paid per user
- Testing endpoints for fee validation and payment confirmation workflows on mainnet
- **Production Distribution Tracking with Validation**: Tracks and logs all automatic proportional distributions across all tokens with comprehensive verification on mainnet
- **Self-Token Reflection Tracking**: Tracks and logs all self-token reflection distributions with comprehensive verification on mainnet
- **Support Token Burning Tracking**: Tracks and logs all Support module token burning distributions with comprehensive verification on mainnet
- **Liquidity Burn Tracking**: Tracks and logs all LP token burns to permanent address with comprehensive verification on mainnet
- **Developer Wallet Exemption Tracking**: Tracks and logs all developer wallet exemptions and reward distributions on mainnet
- **Validation and Audit Functions**: Comprehensive validation functions for payment processing and fee collection accuracy on mainnet
- **Reliable Variant Handling**: Ensures all treasury operations return consistent variant structures with proper error handling
- **Production Payment Processing**: Robust payment confirmation with Web3 wallet integration and error handling including improved Plug wallet detection
- **Real-time Transaction Processing**: Immediate confirmation and data updates after successful wallet transactions and on-chain mint execution
- **Mainnet security hardening** with enhanced audit trails and monitoring
- **Comprehensive Error Handling System**: Implements structured success/error responses for all treasury operations using Result variants
- **Payment Verification Error Handling**: Specific error handling for payment verification failures, expired payments, and authorization issues
- **Transaction State Persistence**: Maintains payment and transaction state to prevent duplicate processing and ensure error recovery
- **Human-Readable Error Response Generation**: All treasury error conditions return clear, actionable error messages for frontend display
- **Progressive Payment Status Communication**: Provides specific status updates throughout the payment verification and processing workflow
- **Robust Try-Catch Wrapping**: All critical treasury operations are wrapped in comprehensive try-catch handlers that capture any Motoko traps or failures
- **Detailed Error Logging**: All caught exceptions are logged to the console with detailed error information for admin diagnosis instead of throwing traps
- **Structured Variant Responses**: All treasury payment and verification operations return structured variant responses (`#success`, `#error`) with human-readable messages for frontend consumption

## Data Storage

### Backend Data
- Token registry with comprehensive deployment records including total supply and tax configurations on mainnet
- **Universal community explorer flags** with automatic `communityExplorer = true` setting for all newly minted tokens
- User token creation history on mainnet
- **User activity metrics** including tokens minted, treasury configurations, and fees paid per user
- **Production Web3 wallet payment transaction records** with signature validation and confirmation status including improved Plug wallet detection
- **Treasury wallet routing records** for 1 ICP minting fees to `ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936` on mainnet
- **Developer wallet routing records** for 0.25% treasury fees to `f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256` on mainnet
- **Developer wallet whitelist records** for exemptions from all fees and restrictions on mainnet
- Enhanced token metadata including treasury fee configuration, dynamic tax module settings, media URLs with `mediaUrl` and `mediaType` fields, descriptions, total supply, and creator details
- **Treasury wallet addresses from Treasury module configurations** with proper validation and token association
- **Token addresses from Support module configurations** with proper validation for burning functionality
- **Self-token reflection configuration data** with automatic canister ID assignment for Reflection modules
- **Permanent burn address constant** for all liquidity burns with validation and audit trails
- **Uniform square emblem processing metadata (512 × 512 px)** including original dimensions, smart cropping parameters, and scaling information
- Multiple module instance configurations per token with reward token addresses and token addresses
- **Aggregated tax total validation records ensuring compliance with 0.25% to 25% range**
- Treasury balance and transaction logs on mainnet
- **Production Web3 wallet mint fee payment status** for each token with signature confirmation including improved Plug wallet detection
- Treasury fee collection records from token operations on mainnet
- **Validated token holder ownership percentages for proportional tax distribution with real-time balance tracking** on mainnet
- **Comprehensive distribution logs for all automatic proportional reward distributions with validation** on mainnet
- **Module-specific distribution records for Treasury, Burn, Reflection, Liquidity, Yield, and Support modules with verification** on mainnet
- **Self-token reflection distribution records** with automatic canister ID targeting on mainnet
- **Support token burning distribution records** with token address targeting for burning on mainnet
- **Liquidity burn records for all LP tokens sent to permanent burn address** on mainnet
- **Developer wallet exemption records** for all fee exemptions and reward distributions on mainnet
- Testing and validation state records for system integrity checks on mainnet
- **Uniform square emblem file references (512 × 512 px)** and blob storage URLs with proper token association including `mediaUrl` and `mediaType` binding and thumbnail generation
- Community explorer metadata including dynamic descriptions, creator information, and community interaction data
- Community interaction data including like counts, comment counts, view counts, and user interaction tracking
- **Validated Fee-on-Transfer configuration data for automatic distribution logic** on mainnet
- **Self-token reflection configuration data** for automatic canister ID assignment on mainnet
- **Support token burning configuration data** for token address targeting on mainnet
- **Liquidity burn configuration data for permanent address routing** on mainnet
- **Developer wallet whitelist configuration data** for complete fee exemptions on mainnet
- **Validation and testing data for comprehensive system verification** on mainnet
- **Data integrity validation logs for variant handling and error tracking**
- **Production deployment state tracking** with success/failure status, error details, and real-time update triggers
- **Production Web3 wallet payment confirmation records** with transaction details, retry history, and improved Plug wallet detection logs
- **Real-time transaction data** for immediate refresh after successful wallet transactions and on-chain mint execution
- **Mainnet deployment records** with performance metrics and security audit logs
- **Comprehensive error handling logs** including exception details, payment verification failures, and authorization issues with context (payer ID, payment ID, timestamp)
- **Transaction state persistence records** for preventing duplicate processing and ensuring error recovery
- **Human-readable error message logs** for all backend error conditions and user feedback
- **Progressive status tracking records** for payment verification and token creation workflow stages
- **Try-catch exception logs** for all critical backend operations with detailed error information for admin diagnosis
- **Structured variant response logs** tracking all `#success` and `#error` responses for payment and mint operations
- **Backend error handling audit trails** ensuring no silent failures or canister traps in production environment
- **Payment function exception handling records** ensuring `recordPayment` and `createToken` functions catch and log all exceptions while returning explicit success/error messages
- **Transaction completion tracking** ensuring backend functions execute fully and return proper responses without trapping
- **User-facing error message records** for specific failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other known error conditions
- **Transaction status response code logs** for improved reliability and frontend synchronization with backend payment verification process

### Frontend Data
- User session and authentication state
- **Production Web3 wallet connection state** including connected wallet type, address, connection status, and improved Plug wallet detection status
- **Enhanced wallet detection state** tracking immediate detection and robust connection handling
- **Connection persistence state** with automatic reconnection and session recovery when wallet session exists
- **Manual retry state** for "Retry Detection" and "Reconnect Wallet" button functionality and status
- **Visual feedback state** with dynamic button states, hover messaging, and status progression showing detection success/failure
- **Debugging state** for visible logging, console diagnostics, and timeout messaging functionality
- **LocalStorage connection state** for persistent connection and wallet principal across browser sessions and page reloads
- **Production wallet transaction state** including payment progress, confirmation status, error handling, and improved Plug wallet detection feedback
- Token creation wizard progress including dynamic module states and multiple instance tracking
- **Treasury wallet address input states with validation feedback**
- **Support token address input states with validation feedback**
- **Self-token reflection UI states** indicating automatic targeting without user input requirements
- **Real-time tax aggregation state tracking total buy and sell tax percentages**
- **Tax validation state ensuring totals stay within 0.25% to 25% range**
- Wallet connection status
- Token dashboard data (fetched from backend) including user-specific and global metrics
- **Token lookup search state** and results display
- **Production Web3 wallet payment confirmation status** with transaction tracking and improved Plug wallet detection
- **Real-time data refresh state** for immediate updates after successful transactions and on-chain mint execution
- Dynamic array state management for collapsible module instances
- Form validation states and error handling
- Testing mode flags and validation results display
- Enhanced Community Token Explorer state including search filters, sort preferences, selected token, live refresh status, and community interaction states
- Enhanced Dexscreener widget integration state and responsive chart rendering
- Token detail modal display states and transition management
- **Production media upload progress with strict 1:1 aspect ratio validation states (512 × 512 px)** including GIF, MP4, MP3 support
- **Smart center-cropping and scaling state management** for non-square media processing
- **Uniform square emblem styling and alignment states (512 × 512 px)** for consistent display
- Community interaction frontend state (likes, comments, views)
- **Liquidity burn confirmation states** indicating automatic permanent burning
- **Self-token reflection confirmation states** indicating automatic canister ID targeting
- **Support token burning confirmation states** indicating token address targeting
- **Developer wallet exemption states** indicating complete fee exemptions
- **Validation and testing interface states for system verification**
- **Error handling states for variant validation and data integrity checks**
- **Loading and retry states for robust data fetching**
- **Production deployment state management** with form data persistence across all wallet connection attempts and submission attempts
- **Production Web3 wallet payment processing states** with retry mechanisms, error recovery, and improved Plug wallet detection
- **Transaction status states** for successful and declined wallet transactions
- **Success/failure feedback states** with detailed error messages, next steps, and real-time UI updates
- **Locked wallet error states** with clear messaging when Plug wallet is locked or transactions are rejected
- **Canister ID display states** with copy-to-clipboard functionality for deployed tokens
- **Cinematic molten-forge blue-magenta-cyan UI states** for theme elements, animations, and visual effects
- **Backend error handling states** for displaying structured error responses from backend functions via toast notifications instead of application crashes
- **Progressive status messaging states** for payment verification and token creation workflow updates
- **Error modal and toast states** for displaying human-readable error messages instead of application crashes
- **Transaction state persistence** for maintaining form data and payment status across error recovery attempts
- **Extended wallet confirmation states** that wait indefinitely until user confirms or cancels Plug signature
- **Toast notification states** for displaying backend error messages clearly instead of white "Application error occurred" screens
- **Structured variant response handling states** for processing `#success` and `#error` responses from backend operations
- **Frontend error integration states** for consuming backend error responses and displaying them appropriately

## Enhanced Token Metadata
Backend TokenMetadata type includes:
- **Community explorer visibility flag** automatically set to `true` for all newly minted tokens
- Treasury fee percentage (including automatic 0.25%)
- Dynamic tax module configurations with support for multiple instances per module type
- **Treasury wallet addresses from Treasury module configurations** with proper validation
- **Token addresses from Support module configurations** with proper validation for burning functionality
- **Self-token reflection configuration** with automatic canister ID assignment for Reflection modules
- **Permanent burn address for all liquidity burns** with validation and audit trails
- **Developer wallet whitelist flag** for complete fee exemptions
- **Aggregated buy and sell tax totals validated within 0.25% to 25% range**
- Reward token addresses for yield modules
- Token addresses for support modules
- Buy/sell tax percentages for each module instance
- Total supply and circulating supply information
- **Production Web3 wallet mint fee payment status** with signature confirmation including improved Plug wallet detection
- **Uniform square emblem media URL (512 × 512 px)** for uploaded branding content with proper token association including `mediaUrl` and `mediaType` fields and thumbnail references
- **Emblem processing metadata** including strict aspect ratio validation, smart cropping parameters, and scaling information
- Optional description text field with dynamic content support
- Creator details and metadata
- All existing token configuration parameters
- Validation timestamps and testing status flags
- Community explorer compatibility metadata
- Community interaction metadata including like counts, comment counts, and view counts
- **Validated Fee-on-Transfer distribution configuration for automatic proportional reward distribution** on mainnet
- **Self-token reflection configuration** for automatic canister ID targeting on mainnet
- **Support token burning configuration** for token address targeting on mainnet
- **Liquidity burn configuration for permanent address routing** on mainnet
- **Developer wallet whitelist configuration** for complete fee exemptions on mainnet
- **Token holder balance tracking for real-time ownership percentage calculations with validation** on mainnet
- **Validation and testing metadata for system verification** on mainnet
- **Data integrity validation flags and error tracking metadata**
- **Production deployment metadata** with success/failure status, completion timestamps, and real-time update triggers
- **Production Web3 wallet payment confirmation metadata** with transaction details, signature validation, and improved Plug wallet detection logs
- **Real-time transaction metadata** for immediate data refresh capabilities and on-chain mint execution tracking
- **Mainnet deployment metadata** with performance benchmarks and security validation records
- **Error handling metadata** including exception logs, payment verification status, and authorization tracking
- **Transaction state metadata** for duplicate prevention and error recovery support
- **Progressive status metadata** for payment and deployment workflow tracking
- **Try-catch exception metadata** for all critical backend operations with detailed error information
- **Structured variant response metadata** tracking all `#success` and `#error` responses for operations
- **Backend error handling metadata** ensuring no silent failures or canister traps in production

## Network Configuration
- Support for local ICP replica development
- **Mainnet deployment capability with production-ready configuration**
- Environment-specific canister configurations for mainnet
- Automatic Candid interface generation for TypeScript integration
- Testing environment setup with mock data and validation scenarios
- **Caffeine blob storage integration for uniform square emblem files (512 × 512 px)** including `mediaUrl` and `mediaType` binding
- Enhanced third-party widget integration support (Dexscreener) with responsive chart functionality
- **Production Web3 wallet integration support** for Plug and other popular mainnet wallets with improved Plug wallet detection
- **ICP Ledger integration** for payment processing and transaction confirmation on mainnet
- **Comprehensive validation and testing infrastructure** for mainnet
- **Robust error handling and retry mechanisms for network operations** on mainnet
- **Production deployment network handling** with proper error recovery, retry logic, and real-time updates
- **Production Web3 wallet payment network integration** with robust confirmation, error handling, and improved Plug wallet detection
- **Real-time data synchronization** for immediate updates after successful transactions and on-chain mint execution
- **Mainnet security hardening** with production monitoring and alerting
- **Performance optimization** for mainnet scalability and efficiency
- **Comprehensive backend error handling network integration** with structured response processing and error recovery
- **Transaction state persistence network support** for maintaining payment and deployment state across network operations
- **Try-catch network error handling** for all critical backend operations with detailed logging and recovery mechanisms
- **Structured variant response network processing** for reliable `#success` and `#error` response handling across network operations

## Technical Requirements
- React frontend with Tailwind CSS styling
- **Motoko backend canisters with enhanced fee-on-transfer functionality optimized for mainnet deployment**
- Internet Identity authentication
- **Production Web3 wallet integration** supporting **Plug** and other popular mainnet wallets with improved Plug wallet detection logic
- **Enhanced wallet detection system** with immediate state setting and robust connection handling including 30-second timeout and user alerts
- **Proper principal storage** ensuring connected wallet principal is correctly stored and managed across sessions
- **Persistent session management** with disconnect and reconnect functionality for seamless user experience
- **Safe component lifecycle handling** with proper initialization during mount and cleanup on unmount
- **Enhanced error handling** with clear user feedback for connection failures and missing wallet scenarios
- **Connection state management** ensuring UI defaults to "Connect Wallet" when Plug is installed but not yet connected
- **Automatic reconnection functionality** using `await window.ic.plug.isConnected()` and `await window.ic.plug.requestConnect()` that auto-reconnects on mount without user action if wallet session exists
- **Manual retry button integration** with "Retry Detection" and "Reconnect Wallet" functionality for reinitializing detection
- **Enhanced visual feedback system** with dynamic button states, hover messaging, and status progression for detection success/failure status
- **Comprehensive debugging system** with visible logging, console diagnostics, and timeout messaging for troubleshooting
- **LocalStorage integration** for persistent connection state and wallet principal caching across browser sessions and page reloads
- **Verified connection flow** ensuring connection prompts trigger correctly and signature flow can proceed without page reloads
- **Extended wallet confirmation logic** that waits indefinitely until the user confirms or cancels the Plug signature, ensuring the transaction popup stays open for as long as necessary
- **ICP Ledger integration** for payment processing and transaction confirmation on mainnet
- Inter-canister communication on mainnet
- TypeScript declarations from Candid interfaces
- Copy-to-clipboard functionality for wallet addresses and Canister IDs
- Smooth CSS animations for collapsible module transitions and modal displays
- Dynamic React state management for multiple module instances
- **Production Web3 wallet connection management** with connection status indicators, wallet switching, and improved Plug wallet detection
- **Production wallet payment integration** with automatic transaction triggering, signature confirmation, and improved Plug wallet detection
- **Production transaction status handling** for successful and declined wallet transactions with error feedback
- **Treasury wallet address input validation with real-time format checking**
- **Support token address input validation with real-time format checking**
- **Self-token reflection UI components** indicating automatic canister ID targeting without user input fields
- **Real-time tax aggregation logic with live calculation updates**
- **Tax range validation with user feedback for out-of-range configurations**
- **Liquidity burn confirmation UI with clear indication of permanent burning**
- **Developer wallet whitelist UI components** indicating complete fee exemptions
- **Comprehensive testing framework integration with mainnet validation**
- Error handling and validation throughout all components
- **Production media upload with strict 1:1 square aspect ratio processing (512 × 512 px)** including GIF, MP4, MP3 support with thumbnail generation and proper token association including `mediaUrl` and `mediaType` binding
- **Smart center-cropping and scaling functionality** for non-square media to maintain proportion without distortion
- **Enhanced upload preview containers** with consistent border radius, drop-shadow, and alignment matching Digital Forge emblem aesthetic
- **Uniform square emblem styling (512 × 512 px)** with consistent border radius, shadow, and alignment across all components
- Responsive card grid layouts for token displays with selection states
- Enhanced search, filter, and sort functionality for token listings including views, likes, and tags filters
- Enhanced Dexscreener widget integration with responsive design and accurate chart rendering positioned beneath square emblems
- Modal system for detailed token viewing with smooth transitions
- Live data refresh capabilities for community explorer
- **Uniform square emblem display consistency (512 × 512 px)** across desktop and mobile views
- Community interaction features including like, comment, and view functionality
- **Token lookup search interface** with canister ID and transaction hash support
- **Dashboard metrics display** with user-specific and global statistics
- **Navigation integration** for Token Lookup page with seamless routing
- **Validated advanced fee-on-transfer processing with automatic proportional distribution logic** on mainnet
- **Self-token reflection processing** with automatic canister ID targeting for Reflection modules on mainnet
- **Support token burning processing** with token address targeting for burning functionality on mainnet
- **Automatic liquidity burn processing with permanent burn address routing** on mainnet
- **Developer wallet whitelist processing** with complete fee exemptions and full reward eligibility on mainnet
- **Real-time balance calculation and ownership percentage tracking with validation** on mainnet
- **Multi-module distribution processing with reward token integration and comprehensive testing** on mainnet
- **Comprehensive validation and testing infrastructure for system verification** on mainnet
- **Robust variant handling with null checks and defensive decoding in React Query hooks**
- **Graceful error handling with user-friendly fallback messages**
- **Inline data validation checks in all render components to prevent crashes**
- **Consistent backend query responses with proper variant structure and data payload validation**
- **Production deployment processing** with proper variant serialization/deserialization and complete form state preservation across all wallet connection attempts
- **Production Web3 wallet payment processing integration** with robust error handling, retry mechanisms, and improved Plug wallet detection
- **Real-time data refresh** for immediate updates after successful wallet transactions and on-chain mint execution
- **Success/failure feedback systems** with detailed error messages, user guidance, and real-time UI updates
- **Production form data persistence** across all wallet connection attempts, authorization retries, and submission attempts
- **Locked wallet error handling** with clear messaging when Plug wallet is locked or transactions are rejected
- **Canister ID display and copy-to-clipboard functionality** for deployed tokens ready for ICPSwap/Sonic integration
- **Cinematic molten-forge blue-magenta-cyan UI implementation** with glowing gradients, molten ember visuals, animated forge hero, and branded emblem display
- **Mainnet deployment readiness** with production-grade security, performance, and monitoring
- **Sonic and ICPSwap integration compatibility** for liquidity addition and live transaction testing
- **Complete English language content** throughout the application interface
- **Comprehensive backend error handling system** with structured success/error responses using Result variants instead of canister traps
- **Exception catching and logging** in all critical backend functions (`recordPayment`, `verifyPaymentWithLedger`, `createToken`) with detailed error tracking for payment verification, authorization, and mint fee validation
- **Human-readable error response generation** for all backend error conditions with clear, actionable messages for frontend display
- **Transaction state management** in backend to prevent duplicate processing and ensure consistent error recovery
- **Progressive status communication** from backend providing specific updates throughout payment and token creation workflows
- **Frontend error integration** consuming structured backend error responses and displaying them in toast notifications instead of causing application crashes or blank "Application error" screens
- **Backend error logging and monitoring** for comprehensive debugging and production monitoring of payment and deployment failures with context including payer ID, payment ID, and timestamp
- **No Silent Failures**: Backend never triggers `Debug.trap` on recoverable user errors - all errors return structured variant responses with human-readable messages
- **Robust Try-Catch Wrapping**: All critical backend operations (`recordPayment`, `verifyPaymentWithLedger`, `createToken`) are wrapped in comprehensive try-catch handlers that capture any Motoko traps or failures
- **Detailed Error Logging**: All caught exceptions are logged to the console with detailed error information for admin diagnosis instead of throwing traps
- **Structured Variant Responses**: All payment and mint operations return structured variant responses (`#success`, `#error`) with human-readable messages for frontend consumption
- **Toast Notification Integration**: Frontend displays backend error messages clearly through toast notifications, preventing white "Application error occurred" screens
- **Guaranteed Exception Handling in Payment Functions**: The `recordPayment` and `createToken` functions must properly catch and log all exceptions while returning explicit success or error messages instead of trapping, ensuring the frontend never receives unhandled null responses or crashes
- **Complete Transaction Execution Guarantee**: When Plug wallet confirmation completes, the backend `createToken` function must execute fully, write token metadata to the registry, and return the minted token's Canister ID and success message
- **Specific User-Facing Error Messages**: Backend provides detailed error messages for known failure cases including payment mismatch, invalid timestamp, treasury address mismatch, and other identifiable error conditions instead of generic crashes
- **Transaction Status Response Codes**: Backend implements transaction status response codes to improve reliability and frontend synchronization with the payment verification and token creation process
