import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../hooks/useQueries';
import { Button } from './ui/button';
import WalletButton from './WalletButton';
import { useQueryClient } from '@tanstack/react-query';
import { Coins, Menu, X, Flame } from 'lucide-react';
import { useState } from 'react';

type View = 'home' | 'create' | 'dashboard' | 'forged' | 'lookup';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export default function Header({ currentView, onNavigate }: HeaderProps) {
  const { login, clear, loginStatus, identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const queryClient = useQueryClient();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAuthenticated = !!identity;
  const disabled = loginStatus === 'logging-in';
  const buttonText = loginStatus === 'logging-in' ? 'Connecting...' : isAuthenticated ? 'Logout' : 'Connect Identity';

  const handleAuth = async () => {
    if (isAuthenticated) {
      await clear();
      queryClient.clear();
      onNavigate('home');
    } else {
      try {
        await login();
      } catch (error: any) {
        console.error('Login error:', error);
        if (error.message === 'User is already authenticated') {
          await clear();
          setTimeout(() => login(), 300);
        }
      }
    }
  };

  const navItems = [
    { label: 'Home', view: 'home' as View, requiresAuth: false },
    { label: 'Forged Tokens', view: 'forged' as View, requiresAuth: false },
    { label: 'Token Lookup', view: 'lookup' as View, requiresAuth: false },
    { label: 'Create Token', view: 'create' as View, requiresAuth: true },
    { label: 'Dashboard', view: 'dashboard' as View, requiresAuth: true },
  ];

  return (
    <header className="sticky top-0 z-50 border-b-2 border-primary/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="absolute inset-0 forge-gradient opacity-5 -z-10" />
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onNavigate('home')}>
            <div className="relative">
              <div className="absolute inset-0 forge-glow rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              <img 
                src="/assets/generated/digital-forge-logo-transparent.dim_200x200.png" 
                alt="Digital Forge ICP" 
                className="h-10 w-10 relative z-10 group-hover:scale-110 transition-transform" 
              />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold forge-text-gradient">
                Digital Forge
              </span>
              <span className="text-xs text-muted-foreground -mt-1">ICP Token Factory</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => {
              if (item.requiresAuth && !isAuthenticated) return null;
              return (
                <button
                  key={item.view}
                  onClick={() => onNavigate(item.view)}
                  className={`text-sm font-medium transition-all hover:text-primary relative group ${
                    currentView === item.view ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  {item.label}
                  {currentView === item.view && (
                    <div className="absolute -bottom-1 left-0 right-0 h-0.5 forge-gradient" />
                  )}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            {isAuthenticated && userProfile && (
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-2 border-primary/20">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-sm font-medium">{userProfile.name}</span>
              </div>
            )}
            <WalletButton />
            <Button
              onClick={handleAuth}
              disabled={disabled}
              variant={isAuthenticated ? 'outline' : 'default'}
              size="sm"
              className={`gap-2 hidden sm:flex ${!isAuthenticated ? 'forge-gradient border-0 hover:opacity-90' : 'border-2 border-primary/30'}`}
            >
              {isAuthenticated ? <Coins className="h-4 w-4" /> : <Flame className="h-4 w-4" />}
              {buttonText}
            </Button>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t-2 border-primary/20 space-y-2">
            {navItems.map((item) => {
              if (item.requiresAuth && !isAuthenticated) return null;
              return (
                <button
                  key={item.view}
                  onClick={() => {
                    onNavigate(item.view);
                    setMobileMenuOpen(false);
                  }}
                  className={`block w-full text-left px-4 py-2 text-sm font-medium transition-colors hover:bg-accent rounded-md ${
                    currentView === item.view ? 'text-primary bg-accent' : 'text-muted-foreground'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            <div className="px-4 pt-2">
              <Button
                onClick={handleAuth}
                disabled={disabled}
                variant={isAuthenticated ? 'outline' : 'default'}
                size="sm"
                className={`w-full gap-2 ${!isAuthenticated ? 'forge-gradient border-0' : 'border-2 border-primary/30'}`}
              >
                {isAuthenticated ? <Coins className="h-4 w-4" /> : <Flame className="h-4 w-4" />}
                {buttonText}
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
