import { useWallet } from '../hooks/useWallet';
import { Button } from './ui/button';
import { Wallet, LogOut, Copy, Check, RefreshCw, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';

export default function WalletButton() {
  const { connected, connecting, address, connectPlug, disconnect, reconnectWallet, detecting, detected } = useWallet();
  const [copied, setCopied] = useState(false);
  const [reconnecting, setReconnecting] = useState(false);

  const handleConnect = async () => {
    await connectPlug();
  };

  const handleReconnect = async () => {
    setReconnecting(true);
    const success = await reconnectWallet();
    setReconnecting(false);
    
    if (!success && !connecting) {
      toast.info('Wallet connection required', {
        description: 'Click "Connect Wallet" to establish a new connection.',
      });
    }
  };

  const handleCopyAddress = async () => {
    if (address) {
      try {
        await navigator.clipboard.writeText(address);
        setCopied(true);
        toast.success('Address copied to clipboard');
        setTimeout(() => setCopied(false), 2000);
      } catch (error) {
        toast.error('Failed to copy address');
      }
    }
  };

  const getStatusIndicator = () => {
    if (connected) {
      return (
        <div 
          className="h-2 w-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" 
          title="Connected"
        />
      );
    }
    if (detecting) {
      return (
        <div title="Detecting wallet...">
          <Loader2 className="h-3 w-3 text-amber-500 animate-spin" />
        </div>
      );
    }
    if (detected) {
      return (
        <div 
          className="h-2 w-2 rounded-full bg-blue-500 shadow-[0_0_6px_rgba(59,130,246,0.5)]" 
          title="Wallet detected"
        />
      );
    }
    return <div className="h-2 w-2 rounded-full bg-muted-foreground/50" title="No wallet detected" />;
  };

  const getButtonText = () => {
    if (connecting) return 'Connecting...';
    if (detecting) return 'Detecting...';
    if (detected && !connected) return 'Connect Wallet';
    if (!detected) return 'Install Plug';
    return 'Connect Wallet';
  };

  const getButtonClassName = () => {
    let baseClass = "gap-2 relative transition-all duration-300";
    
    if (connected) {
      return `${baseClass} shadow-[0_0_15px_rgba(34,197,94,0.3)] hover:shadow-[0_0_20px_rgba(34,197,94,0.4)]`;
    }
    if (detecting) {
      return `${baseClass} animate-pulse`;
    }
    if (detected && !connected) {
      return `${baseClass} shadow-[0_0_10px_rgba(59,130,246,0.2)] hover:shadow-[0_0_15px_rgba(59,130,246,0.3)]`;
    }
    
    return baseClass;
  };

  const getTooltipContent = () => {
    if (connected) return 'Wallet connected';
    if (connecting) return 'Connecting to wallet...';
    if (detecting) return 'Searching for Plug wallet...';
    if (detected) return 'Plug Detected — Connect Now';
    return 'Install Plug wallet extension';
  };

  if (!connected) {
    return (
      <div className="flex items-center gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={handleConnect} 
                disabled={connecting || detecting} 
                className={getButtonClassName()}
              >
                {getStatusIndicator()}
                <Wallet className="h-4 w-4" />
                {getButtonText()}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{getTooltipContent()}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {detected && !connecting && !detecting && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  onClick={handleReconnect}
                  disabled={reconnecting || connecting}
                  variant="outline"
                  size="icon"
                >
                  <RefreshCw className={`h-4 w-4 ${reconnecting ? 'animate-spin' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Reconnect existing session</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          className={`gap-2 ${getButtonClassName()}`}
        >
          {getStatusIndicator()}
          <span className="hidden sm:inline font-mono text-xs">
            {address?.slice(0, 8)}...{address?.slice(-6)}
          </span>
          <Wallet className="h-4 w-4 sm:hidden" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          Wallet Connected
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleCopyAddress} className="gap-2 cursor-pointer">
          {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
          <span className="font-mono text-xs truncate">{address}</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          onClick={handleReconnect} 
          className="gap-2 cursor-pointer"
          disabled={reconnecting}
        >
          <RefreshCw className={`h-4 w-4 ${reconnecting ? 'animate-spin' : ''}`} />
          {reconnecting ? 'Reconnecting...' : 'Reconnect Wallet'}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={disconnect} className="gap-2 cursor-pointer text-destructive">
          <LogOut className="h-4 w-4" />
          Disconnect
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
