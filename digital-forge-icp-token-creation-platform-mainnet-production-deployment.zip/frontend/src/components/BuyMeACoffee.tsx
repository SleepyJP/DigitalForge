import { Coffee, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

const TREASURY_ADDRESS = 'f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256';

export default function BuyMeACoffee() {
  const [copied, setCopied] = useState(false);
  const [showAddress, setShowAddress] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(TREASURY_ADDRESS);
      setCopied(true);
      toast.success('Address copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy address');
    }
  };

  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <button
        onClick={() => setShowAddress(!showAddress)}
        className="flex items-center gap-1.5 hover:text-foreground transition-colors"
      >
        <Coffee className="h-3.5 w-3.5" />
        <span>Buy me a Coffee</span>
      </button>
      {showAddress && (
        <div className="flex items-center gap-1.5 animate-in fade-in slide-in-from-left-2 duration-200">
          <code className="text-xs bg-muted/50 px-2 py-0.5 rounded">
            {TREASURY_ADDRESS.slice(0, 8)}...{TREASURY_ADDRESS.slice(-6)}
          </code>
          <button
            onClick={handleCopy}
            className="hover:text-foreground transition-colors"
            title="Copy address"
          >
            {copied ? (
              <Check className="h-3.5 w-3.5 text-green-500" />
            ) : (
              <Copy className="h-3.5 w-3.5" />
            )}
          </button>
        </div>
      )}
    </div>
  );
}
