import { useState } from 'react';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

export default function ProfileSetupModal() {
  const [name, setName] = useState('');
  const [showAuthError, setShowAuthError] = useState(false);
  const saveProfile = useSaveCallerUserProfile();
  const { identity, login, loginStatus } = useInternetIdentity();

  const isAuthenticated = !!identity && !identity.getPrincipal().isAnonymous();
  const isLoggingIn = loginStatus === 'logging-in';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate authentication first
    if (!isAuthenticated) {
      setShowAuthError(true);
      toast.error('Please connect your Internet Identity first');
      return;
    }

    // Validate name input
    if (!name.trim()) {
      toast.error('Please enter your name');
      return;
    }

    if (name.trim().length > 100) {
      toast.error('Name is too long (max 100 characters)');
      return;
    }

    try {
      setShowAuthError(false);
      await saveProfile.mutateAsync({ name: name.trim() });
      toast.success('Profile created successfully!');
    } catch (error: any) {
      console.error('Profile creation error:', error);
      
      // Parse error message from backend
      const errorMessage = error?.message || String(error);
      
      if (errorMessage.includes('Unauthorized') || errorMessage.includes('Anonymous')) {
        setShowAuthError(true);
        toast.error('Authentication required. Please connect your Internet Identity.');
      } else if (errorMessage.includes('name cannot be empty')) {
        toast.error('Profile name cannot be empty');
      } else if (errorMessage.includes('name too long')) {
        toast.error('Profile name is too long (max 100 characters)');
      } else {
        toast.error('Failed to create profile. Please try again.');
      }
      
      // Preserve form data - don't clear the name field
    }
  };

  const handleLogin = async () => {
    try {
      setShowAuthError(false);
      await login();
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error('Failed to connect Internet Identity');
    }
  };

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>Welcome to Digital Forge ICP!</DialogTitle>
          <DialogDescription>
            Please set up your profile to continue. This will be your display name on the platform.
          </DialogDescription>
        </DialogHeader>

        {showAuthError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You need to connect your Internet Identity before creating a profile.
            </AlertDescription>
          </Alert>
        )}

        {!isAuthenticated ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Please connect your Internet Identity to create your profile.
            </p>
            <Button 
              onClick={handleLogin} 
              className="w-full" 
              disabled={isLoggingIn}
            >
              {isLoggingIn ? 'Connecting...' : 'Connect Internet Identity'}
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <Input
                id="name"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoFocus
                maxLength={100}
              />
              <p className="text-xs text-muted-foreground">
                {name.length}/100 characters
              </p>
            </div>
            <Button 
              type="submit" 
              className="w-full" 
              disabled={saveProfile.isPending || !name.trim()}
            >
              {saveProfile.isPending ? 'Creating Profile...' : 'Create Profile'}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
