import { Heart, Flame } from 'lucide-react';
import BuyMeACoffee from './BuyMeACoffee';

interface FooterProps {
  showDonation?: boolean;
}

export default function Footer({ showDonation = false }: FooterProps) {
  return (
    <footer className="border-t-2 border-primary/20 bg-background/95 backdrop-blur relative">
      <div className="absolute inset-0 forge-gradient opacity-5 -z-10" />
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Flame className="h-4 w-4 text-amber-500" />
            <span>© 2025 Digital Forge. Built with</span>
            <Heart className="h-4 w-4 text-red-500 fill-red-500" />
            <span>using</span>
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-primary hover:underline"
            >
              caffeine.ai
            </a>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-3 md:gap-4">
            <span className="text-sm text-muted-foreground flex items-center gap-2">
              <span className="forge-text-gradient font-semibold">Powered by Internet Computer</span>
            </span>
            {showDonation && <BuyMeACoffee />}
          </div>
        </div>
      </div>
    </footer>
  );
}
