import { useEffect, useState } from 'react';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile } from './hooks/useQueries';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import CreateTokenWizard from './pages/CreateTokenWizard';
import Dashboard from './pages/Dashboard';
import ForgedTokens from './pages/ForgedTokens';
import TokenLookup from './pages/TokenLookup';
import ProfileSetupModal from './components/ProfileSetupModal';
import { Toaster } from './components/ui/sonner';
import { ThemeProvider } from 'next-themes';

type View = 'home' | 'create' | 'dashboard' | 'forged' | 'lookup';

export default function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const [currentView, setCurrentView] = useState<View>('home');

  // Check if user is authenticated (not anonymous)
  const isAuthenticated = !!identity && !identity.getPrincipal().isAnonymous();
  
  // Only show profile setup if:
  // 1. User is authenticated (not anonymous)
  // 2. Profile data has been fetched
  // 3. Profile is null (doesn't exist yet)
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  useEffect(() => {
    if (!isAuthenticated && (currentView === 'create' || currentView === 'dashboard')) {
      setCurrentView('home');
    }
  }, [isAuthenticated, currentView]);

  if (isInitializing) {
    return (
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-primary/5">
          <div className="text-center">
            <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
            <p className="text-muted-foreground">Initializing...</p>
          </div>
        </div>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="flex min-h-screen flex-col bg-gradient-to-br from-background via-background to-primary/5">
        <Header currentView={currentView} onNavigate={setCurrentView} />
        <main className="flex-1">
          {currentView === 'home' && <HomePage onNavigate={setCurrentView} />}
          {currentView === 'create' && <CreateTokenWizard onNavigate={setCurrentView} />}
          {currentView === 'dashboard' && <Dashboard onNavigate={setCurrentView} />}
          {currentView === 'forged' && <ForgedTokens onNavigate={setCurrentView} />}
          {currentView === 'lookup' && <TokenLookup onNavigate={setCurrentView} />}
        </main>
        <Footer showDonation={currentView !== 'home'} />
        {showProfileSetup && <ProfileSetupModal />}
        <Toaster />
      </div>
    </ThemeProvider>
  );
}
