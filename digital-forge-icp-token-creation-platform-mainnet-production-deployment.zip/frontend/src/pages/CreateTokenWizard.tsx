import { useState } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useCreateToken, useGetBuyMeACoffeeAddress, useGetAllTokens, useRecordPayment, useVerifyPayment } from '../hooks/useQueries';
import { useWallet } from '../hooks/useWallet';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Progress } from '../components/ui/progress';
import { Checkbox } from '../components/ui/checkbox';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '../components/ui/alert';
import { toast } from 'sonner';
import { ArrowLeft, ArrowRight, Check, Coins, AlertTriangle, Info, Wallet, Copy, X, Plus, Upload, Image as ImageIcon, Calculator, CheckCircle2, Zap, TrendingUp, Flame, Repeat, Sparkles, Loader2 } from 'lucide-react';
import type { TokenConfig, TreasuryFeeConfig, TaxModules, ModuleConfig } from '../backend';
import { ModuleType, TokenStatus, MediaType } from '../backend';

type View = 'home' | 'create' | 'dashboard' | 'forged';

interface CreateTokenWizardProps {
  onNavigate: (view: View) => void;
}

type Step = 1 | 2 | 3 | 4;

interface TokenFormData {
  name: string;
  symbol: string;
  description: string;
  totalSupply: string;
  decimals: string;
  treasuryEnabled: boolean;
  treasuryAddress: string;
  treasuryBuyFee: string;
  treasurySellFee: string;
  burnEnabled: boolean;
  reflectionEnabled: boolean;
  liquidityEnabled: boolean;
  yieldEnabled: boolean;
  supportEnabled: boolean;
  renounceOwnership: boolean;
  startableTrading: boolean;
}

interface ModuleInstance {
  id: string;
  moduleType: ModuleType;
  buyTax: string;
  sellTax: string;
  unified: boolean;
  split: boolean;
  rewardTokenAddress: string;
  tokenAddress: string;
  treasuryAddress: string;
}

const TREASURY_MINT_FEE_ADDRESS = 'ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936';
const DEVELOPER_WALLET = 'f2ba368dff8966e6a9977354eb4c3f0f543c3cadb504dc0d4355859888bd2256';
const LIQUIDITY_BURN_ADDRESS = 'aaaaa-aa';
const AUTOMATIC_TREASURY_FEE = 0.25;
const MIN_TOTAL_TAX = 0.25;
const MAX_TOTAL_TAX = 25;
const MINT_FEE_ICP = 1_000_000_000n;
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 MB
const ALLOWED_FILE_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'video/mp4', 'audio/mpeg'];
const TARGET_SIZE = 512; // 512 × 512 px square

export default function CreateTokenWizard({ onNavigate }: CreateTokenWizardProps) {
  const { identity } = useInternetIdentity();
  const { connected: walletConnected, connectPlug, transferICP, address: walletAddress, waitingForConfirmation } = useWallet();
  const createToken = useCreateToken();
  const recordPayment = useRecordPayment();
  const verifyPayment = useVerifyPayment();
  const { data: existingTokens } = useGetAllTokens();
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showDistributionPreview, setShowDistributionPreview] = useState(false);
  const [addressCopied, setAddressCopied] = useState(false);
  const [moduleInstances, setModuleInstances] = useState<ModuleInstance[]>([]);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [isPaymentProcessing, setIsPaymentProcessing] = useState(false);
  const [deployedTokenSymbol, setDeployedTokenSymbol] = useState<string>('');
  const [deployedCanisterId, setDeployedCanisterId] = useState<string>('');
  const [paymentId, setPaymentId] = useState<bigint | null>(null);
  const [formData, setFormData] = useState<TokenFormData>({
    name: '',
    symbol: '',
    description: '',
    totalSupply: '1000000',
    decimals: '8',
    treasuryEnabled: true,
    treasuryAddress: DEVELOPER_WALLET,
    treasuryBuyFee: '0.25',
    treasurySellFee: '0.25',
    burnEnabled: false,
    reflectionEnabled: false,
    liquidityEnabled: false,
    yieldEnabled: false,
    supportEnabled: false,
    renounceOwnership: false,
    startableTrading: true,
  });

  const updateField = (field: keyof TokenFormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const detectMediaType = (file: File): MediaType => {
    if (file.type.startsWith('image/')) {
      if (file.type === 'image/gif') return MediaType.gif;
      return MediaType.image;
    }
    if (file.type.startsWith('video/')) return MediaType.video;
    if (file.type.startsWith('audio/')) return MediaType.audio;
    return MediaType.unknown_;
  };

  const processImageToSquare = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Failed to get canvas context'));
            return;
          }

          canvas.width = TARGET_SIZE;
          canvas.height = TARGET_SIZE;

          const sourceSize = Math.min(img.width, img.height);
          const offsetX = (img.width - sourceSize) / 2;
          const offsetY = (img.height - sourceSize) / 2;

          ctx.drawImage(
            img,
            offsetX, offsetY, sourceSize, sourceSize,
            0, 0, TARGET_SIZE, TARGET_SIZE
          );

          resolve(canvas.toDataURL(file.type, 0.95));
        };
        img.onerror = () => reject(new Error('Failed to load image'));
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const processVideoToSquare = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Failed to get canvas context'));
        return;
      }

      video.onloadedmetadata = () => {
        video.currentTime = 0.1;
      };

      video.onseeked = () => {
        canvas.width = TARGET_SIZE;
        canvas.height = TARGET_SIZE;

        const sourceSize = Math.min(video.videoWidth, video.videoHeight);
        const offsetX = (video.videoWidth - sourceSize) / 2;
        const offsetY = (video.videoHeight - sourceSize) / 2;

        ctx.drawImage(
          video,
          offsetX, offsetY, sourceSize, sourceSize,
          0, 0, TARGET_SIZE, TARGET_SIZE
        );

        resolve(canvas.toDataURL('image/jpeg', 0.95));
      };

      video.onerror = () => reject(new Error('Failed to load video'));
      
      const reader = new FileReader();
      reader.onload = (e) => {
        video.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast.error('Invalid file type. Please upload PNG, JPEG, GIF, MP4, or MP3 files.');
      return;
    }

    if (file.size > MAX_FILE_SIZE) {
      toast.error('File size exceeds 50 MB limit.');
      return;
    }

    setMediaFile(file);

    try {
      if (file.type.startsWith('image/') && file.type !== 'image/gif') {
        const processedImage = await processImageToSquare(file);
        setMediaPreview(processedImage);
        toast.success('Image processed to 512 × 512 px square');
      } else if (file.type.startsWith('video/')) {
        const thumbnail = await processVideoToSquare(file);
        setMediaPreview(thumbnail);
        toast.success('Video thumbnail generated at 512 × 512 px');
      } else if (file.type === 'image/gif') {
        const reader = new FileReader();
        reader.onloadend = () => {
          setMediaPreview(reader.result as string);
          toast.success('GIF uploaded (animation preserved)');
        };
        reader.readAsDataURL(file);
      } else {
        const reader = new FileReader();
        reader.onloadend = () => {
          setMediaPreview(reader.result as string);
          toast.success('Audio file uploaded');
        };
        reader.readAsDataURL(file);
      }
    } catch (error) {
      toast.error('Failed to process media file');
      console.error('Media processing error:', error);
      setMediaFile(null);
      setMediaPreview('');
    }
  };

  const removeMedia = () => {
    setMediaFile(null);
    setMediaPreview('');
  };

  const isValidWalletAddress = (address: string): boolean => {
    if (!address.trim()) return false;
    const hexPattern = /^[a-fA-F0-9]{64}$/;
    return hexPattern.test(address.trim());
  };

  const addModuleInstance = (moduleType: ModuleType) => {
    const newInstance: ModuleInstance = {
      id: `${moduleType}-${Date.now()}-${Math.random()}`,
      moduleType,
      buyTax: '0',
      sellTax: '0',
      unified: false,
      split: false,
      rewardTokenAddress: '',
      tokenAddress: '',
      treasuryAddress: '',
    };
    setModuleInstances((prev) => [...prev, newInstance]);
  };

  const removeModuleInstance = (id: string) => {
    setModuleInstances((prev) => prev.filter((instance) => instance.id !== id));
  };

  const updateModuleInstance = (id: string, field: keyof ModuleInstance, value: string | boolean) => {
    setModuleInstances((prev) =>
      prev.map((instance) => {
        if (instance.id === id) {
          const updated = { ...instance, [field]: value };
          if (field === 'unified' && value === true) {
            updated.sellTax = updated.buyTax;
          }
          if (field === 'buyTax' && instance.unified) {
            updated.sellTax = value as string;
          }
          if (field === 'split' && value === false) {
            updated.sellTax = updated.buyTax;
          }
          return updated;
        }
        return instance;
      })
    );
  };

  const calculateTotalTax = () => {
    let totalBuy = 0;
    let totalSell = 0;

    moduleInstances.forEach((instance) => {
      totalBuy += Number(instance.buyTax) || 0;
      totalSell += Number(instance.sellTax) || 0;
    });

    totalBuy += AUTOMATIC_TREASURY_FEE;
    totalSell += AUTOMATIC_TREASURY_FEE;

    return { totalBuy, totalSell };
  };

  const calculateDistributionPreview = () => {
    const totalSupply = Number(formData.totalSupply) || 1000000;
    const transactionAmount = 10000;
    
    const holders = [
      { address: 'Holder A (Creator)', balance: totalSupply * 0.5, percentage: 50 },
      { address: 'Holder B (Early Investor)', balance: totalSupply * 0.3, percentage: 30 },
      { address: 'Holder C (Community)', balance: totalSupply * 0.15, percentage: 15 },
      { address: 'Holder D (Team)', balance: totalSupply * 0.05, percentage: 5 },
    ];

    const { totalBuy } = calculateTotalTax();
    const totalFeeAmount = transactionAmount * (totalBuy / 100);
    const treasuryFeeAmount = transactionAmount * (AUTOMATIC_TREASURY_FEE / 100);
    const distributionFeeAmount = totalFeeAmount - treasuryFeeAmount;

    const distributions = holders.map(holder => ({
      ...holder,
      reward: (distributionFeeAmount * holder.percentage) / 100,
    }));

    return {
      transactionAmount,
      totalFeeAmount,
      treasuryFeeAmount,
      distributionFeeAmount,
      distributions,
      totalBuy,
    };
  };

  const validateStep = (step: Step): boolean => {
    switch (step) {
      case 1:
        if (!formData.name.trim()) {
          toast.error('Token name is required');
          return false;
        }
        if (!formData.symbol.trim() || formData.symbol.length > 10) {
          toast.error('Token symbol is required (max 10 characters)');
          return false;
        }
        if (existingTokens?.some((token) => token.symbol.toLowerCase() === formData.symbol.toLowerCase())) {
          toast.error('A token with this symbol already exists');
          return false;
        }
        if (!formData.totalSupply || Number(formData.totalSupply) <= 0) {
          toast.error('Total supply must be greater than 0');
          return false;
        }
        return true;
      case 2:
        const { totalBuy, totalSell } = calculateTotalTax();
        
        if (totalBuy < MIN_TOTAL_TAX) {
          toast.error(`Total buy tax (${totalBuy.toFixed(2)}%) must be at least ${MIN_TOTAL_TAX}%`);
          return false;
        }
        if (totalBuy > MAX_TOTAL_TAX) {
          toast.error(`Total buy tax (${totalBuy.toFixed(2)}%) cannot exceed ${MAX_TOTAL_TAX}%`);
          return false;
        }
        if (totalSell < MIN_TOTAL_TAX) {
          toast.error(`Total sell tax (${totalSell.toFixed(2)}%) must be at least ${MIN_TOTAL_TAX}%`);
          return false;
        }
        if (totalSell > MAX_TOTAL_TAX) {
          toast.error(`Total sell tax (${totalSell.toFixed(2)}%) cannot exceed ${MAX_TOTAL_TAX}%`);
          return false;
        }

        for (const instance of moduleInstances) {
          const moduleBuyTax = Number(instance.buyTax) || 0;
          const moduleSellTax = Number(instance.sellTax) || 0;
          
          if (moduleBuyTax < 0 || moduleBuyTax > 50) {
            toast.error(`${getModuleLabel(instance.moduleType)} buy tax must be between 0 and 50%`);
            return false;
          }
          if (moduleSellTax < 0 || moduleSellTax > 50) {
            toast.error(`${getModuleLabel(instance.moduleType)} sell tax must be between 0 and 50%`);
            return false;
          }
          
          if (instance.moduleType === ModuleType.treasury) {
            if (!instance.treasuryAddress.trim()) {
              toast.error('Treasury Wallet Address is required for Treasury modules');
              return false;
            }
            if (!isValidWalletAddress(instance.treasuryAddress)) {
              toast.error('Invalid Treasury Wallet Address format. Please enter a valid 64-character hex address.');
              return false;
            }
          }
          
          if (instance.moduleType === ModuleType.yield_ && !instance.rewardTokenAddress.trim()) {
            toast.error('Reward Token Address is required for Yield modules');
            return false;
          }
          if (instance.moduleType === ModuleType.support && !instance.tokenAddress.trim()) {
            toast.error('Token Address is required for Support modules');
            return false;
          }
        }
        return true;
      case 3:
        const decimals = Number(formData.decimals);
        if (decimals < 0 || decimals > 18) {
          toast.error('Decimals must be between 0 and 18');
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(4, prev + 1) as Step);
    }
  };

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(1, prev - 1) as Step);
  };

  const handleDeployClick = () => {
    if (!validateStep(4)) return;
    setShowConfirmDialog(true);
  };

  const handleConfirmDeploy = () => {
    setShowConfirmDialog(false);
    setShowPaymentDialog(true);
  };

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(TREASURY_MINT_FEE_ADDRESS);
      setAddressCopied(true);
      toast.success('Address copied to clipboard');
      setTimeout(() => setAddressCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy address');
    }
  };

  const handleCopyCanisterId = async () => {
    if (!deployedCanisterId) return;
    try {
      await navigator.clipboard.writeText(deployedCanisterId);
      toast.success('Canister ID copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy Canister ID');
    }
  };

  const convertModuleTypeToBackend = (moduleType: ModuleType): any => {
    const variantMap: Record<string, any> = {
      'treasury': { treasury: null },
      'burn': { burn: null },
      'reflection': { reflection: null },
      'liquidity': { liquidity: null },
      'yield_': { yield_: null },
      'support': { support: null },
    };

    const variant = variantMap[moduleType] || { treasury: null };
    return variant;
  };

  const handlePayAndDeploy = async () => {
    if (!identity) {
      toast.error('Please connect your Internet Identity first');
      return;
    }

    // Step 1: Ensure wallet is connected
    if (!walletConnected) {
      toast.info('Connecting to Plug wallet...', {
        description: 'Your form data is preserved.',
      });
      const connected = await connectPlug();
      if (!connected) {
        toast.error('Failed to connect wallet', {
          description: 'Your form data is preserved. Please try again.',
        });
        return;
      }
    }

    try {
      setIsPaymentProcessing(true);
      setIsUploading(true);

      // Step 2: Process media if present
      let mediaUrl = '';
      let mediaType = MediaType.unknown_;

      if (mediaFile) {
        mediaUrl = mediaPreview;
        mediaType = detectMediaType(mediaFile);
        toast.success('Media prepared for deployment');
      }

      setIsUploading(false);

      // Step 3: Request ICP payment via Web3 wallet - WAIT FOR CONFIRMATION
      toast.info('Requesting payment signature...', {
        description: 'Please approve the transaction in your Plug wallet',
      });

      const transferResult = await transferICP({
        to: TREASURY_MINT_FEE_ADDRESS,
        amount: MINT_FEE_ICP,
        memo: BigInt(Date.now()),
      });

      // Only proceed if payment was successful with block height confirmation
      if (!transferResult.success || !transferResult.blockHeight) {
        throw new Error(transferResult.error || 'Payment failed - no signature confirmation');
      }

      toast.success('✅ Payment confirmed on-chain!', {
        description: `Transaction completed at block ${transferResult.blockHeight}`,
      });

      // Step 4: Record payment on backend
      toast.info('Recording payment...', {
        description: 'Saving payment record to backend',
      });

      const recordedPaymentId = await recordPayment.mutateAsync({
        amount: MINT_FEE_ICP,
        treasuryAddress: TREASURY_MINT_FEE_ADDRESS,
      });

      setPaymentId(recordedPaymentId);

      // Step 5: Verify payment (in production, this would be automatic or admin-triggered)
      toast.info('Payment recorded successfully', {
        description: 'Proceeding with token deployment',
      });

      // Step 6: Create token configuration
      const taxModules: TaxModules = {
        treasury: formData.treasuryEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.treasury),
        burn: formData.burnEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.burn),
        reflection: formData.reflectionEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.reflection),
        liquidity: formData.liquidityEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.liquidity),
        yield: formData.yieldEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.yield_),
        support: formData.supportEnabled || moduleInstances.some((m) => m.moduleType === ModuleType.support),
      };

      const treasuryFeeConfig: TreasuryFeeConfig = {
        enabled: true,
        treasuryAddress: TREASURY_MINT_FEE_ADDRESS,
        buyFee: BigInt(Math.floor(AUTOMATIC_TREASURY_FEE * 100)),
        sellFee: BigInt(Math.floor(AUTOMATIC_TREASURY_FEE * 100)),
      };

      const moduleConfigs: ModuleConfig[] = moduleInstances.map((instance) => {
        const config: ModuleConfig = {
          moduleType: convertModuleTypeToBackend(instance.moduleType),
          buyTax: BigInt(Math.floor((Number(instance.buyTax) || 0) * 100)),
          sellTax: BigInt(Math.floor((Number(instance.sellTax) || 0) * 100)),
          unified: instance.unified,
          split: instance.split,
          rewardTokenAddress: instance.rewardTokenAddress.trim() || undefined,
          tokenAddress: instance.tokenAddress.trim() || undefined,
          reflectionTarget: undefined,
        };
        return config;
      });

      const totalSupply = BigInt(formData.totalSupply);

      const config: TokenConfig = {
        name: formData.name.trim(),
        symbol: formData.symbol.trim().toUpperCase(),
        description: formData.description.trim(),
        totalSupply,
        decimals: BigInt(formData.decimals),
        treasuryFee: treasuryFeeConfig,
        taxModules,
        moduleConfigs,
        mediaUrl,
        thumbnailUrl: '',
        status: TokenStatus.active,
        circulatingSupply: totalSupply,
        tokenAddress: undefined,
        rewardTokenAddress: undefined,
        validationTimestamp: undefined,
        testingStatus: undefined,
        communityExplorer: true,
        aiAgentCompatible: false,
        mediaType,
        chartUrl: '',
        creatorName: '',
        creatorProfileUrl: '',
        tags: [],
        featured: false,
        customFields: [],
        emblemAspectRatio: undefined,
        emblemProcessingMetadata: undefined,
        paymentId: recordedPaymentId,
      };

      // Step 7: Deploy token with payment ID
      toast.info('Deploying token...', {
        description: 'Creating your token on the Internet Computer',
      });

      const result = await createToken.mutateAsync(config);
      
      const tokenSymbol = formData.symbol.trim().toUpperCase();
      const canisterId = identity.getPrincipal().toString();
      
      setDeployedTokenSymbol(tokenSymbol);
      setDeployedCanisterId(canisterId);
      setShowPaymentDialog(false);
      setShowSuccessModal(true);
      
      // Success toast is handled by the mutation's onSuccess callback
    } catch (error: any) {
      console.error('Deployment error:', error);
      
      let errorMessage = 'Failed to deploy token';
      let errorDescription = 'Your form data is preserved. Please try again.';
      
      if (error?.message) {
        const msg = error.message;
        if (msg.includes('User rejected') || msg.includes('rejected') || msg.includes('cancelled')) {
          errorMessage = 'Payment cancelled';
          errorDescription = 'Your form data is preserved - click "Confirm Payment & Deploy" when ready.';
        } else if (msg.includes('Insufficient')) {
          errorMessage = 'Insufficient ICP balance';
          errorDescription = 'Please add funds to your wallet. Your form data is preserved.';
        } else if (msg.includes('Unauthorized')) {
          errorMessage = 'Authentication error';
          errorDescription = msg.includes('Payment not yet verified') 
            ? 'Payment verification pending. Please wait a moment and try again.'
            : 'Please reconnect your wallet and try again. Your form data is preserved.';
        } else if (msg.includes('already exists')) {
          errorMessage = 'Token symbol already exists';
          errorDescription = 'Please choose a different symbol.';
        } else if (msg.includes('tax')) {
          errorMessage = 'Tax configuration error';
          errorDescription = 'Please check your fee percentages and try again.';
        } else if (msg.includes('Rate limit')) {
          errorMessage = 'Rate limit reached';
          errorDescription = 'Please wait a moment before trying again.';
        } else if (msg.includes('Payment')) {
          errorMessage = 'Payment error';
          errorDescription = msg;
        } else {
          errorDescription = `${msg}. Your form data is preserved.`;
        }
      }
      
      toast.error(errorMessage, { description: errorDescription });
    } finally {
      setIsUploading(false);
      setIsPaymentProcessing(false);
    }
  };

  const handleSuccessClose = () => {
    setShowSuccessModal(false);
    onNavigate('dashboard');
  };

  const progress = (currentStep / 4) * 100;
  const { totalBuy, totalSell } = calculateTotalTax();

  const renderModuleButton = (moduleType: ModuleType, label: string) => (
    <Button
      key={moduleType}
      variant="outline"
      size="sm"
      onClick={() => addModuleInstance(moduleType)}
      className="gap-2"
    >
      <Plus className="h-4 w-4" />
      {label}
    </Button>
  );

  const getModuleLabel = (moduleType: ModuleType): string => {
    switch (moduleType) {
      case ModuleType.treasury:
        return 'Treasury';
      case ModuleType.burn:
        return 'Burn';
      case ModuleType.reflection:
        return 'Reflection';
      case ModuleType.liquidity:
        return 'Liquidity';
      case ModuleType.yield_:
        return 'Yield';
      case ModuleType.support:
        return 'Support';
      default:
        return String(moduleType);
    }
  };

  const renderModuleInstance = (instance: ModuleInstance) => {
    const isTreasury = instance.moduleType === ModuleType.treasury;
    const isYield = instance.moduleType === ModuleType.yield_;
    const isSupport = instance.moduleType === ModuleType.support;
    const isLiquidity = instance.moduleType === ModuleType.liquidity;
    const isReflection = instance.moduleType === ModuleType.reflection;
    const needsAddress = isYield || isSupport || isTreasury;
    const showSplitInputs = instance.split || [ModuleType.treasury, ModuleType.burn, ModuleType.reflection, ModuleType.liquidity].includes(instance.moduleType);

    return (
      <div
        key={instance.id}
        className="border border-border/50 rounded-lg p-4 space-y-4 animate-in slide-in-from-top-2 duration-300"
      >
        <div className="flex items-center justify-between">
          <Label className="text-base font-semibold capitalize">
            {getModuleLabel(instance.moduleType)}
          </Label>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => removeModuleInstance(instance.id)}
            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {isReflection && (
          <Alert className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
            <Repeat className="h-4 w-4 text-purple-600 dark:text-purple-400" />
            <AlertTitle className="text-purple-600 dark:text-purple-400 text-sm">Automatic Self-Token Reflection</AlertTitle>
            <AlertDescription className="text-xs text-muted-foreground">
              🔄 This reflection module automatically targets <strong>your token itself</strong> for reward distributions. The backend assigns the token&apos;s canister ID at mint time - no manual configuration needed. All holders receive proportional rewards in your token based on their ownership percentage.
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          <Label className="text-sm text-muted-foreground flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Fee Percentage (Auto-Distributed Proportionally)
          </Label>
          {showSplitInputs ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`${instance.id}-buyTax`} className="text-xs">
                  Buy Tax Percentage
                </Label>
                <div className="relative">
                  <Input
                    id={`${instance.id}-buyTax`}
                    type="number"
                    placeholder="0"
                    value={instance.buyTax}
                    onChange={(e) => updateModuleInstance(instance.id, 'buyTax', e.target.value)}
                    min="0"
                    max="50"
                    step="0.01"
                    className="pr-8"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                    %
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor={`${instance.id}-sellTax`} className="text-xs">
                  Sell Tax Percentage
                </Label>
                <div className="relative">
                  <Input
                    id={`${instance.id}-sellTax`}
                    type="number"
                    placeholder="0"
                    value={instance.sellTax}
                    onChange={(e) => updateModuleInstance(instance.id, 'sellTax', e.target.value)}
                    min="0"
                    max="50"
                    step="0.01"
                    className="pr-8"
                    disabled={instance.unified}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                    %
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="relative">
              <Input
                id={`${instance.id}-percentage`}
                type="number"
                placeholder="0"
                value={instance.buyTax}
                onChange={(e) => {
                  updateModuleInstance(instance.id, 'buyTax', e.target.value);
                  if (!instance.split) {
                    updateModuleInstance(instance.id, 'sellTax', e.target.value);
                  }
                }}
                min="0"
                max="50"
                step="0.01"
                className="pr-8"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                %
              </span>
            </div>
          )}

          <div className="flex items-center gap-4">
            {showSplitInputs && (
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={`${instance.id}-unified`}
                  checked={instance.unified}
                  onCheckedChange={(checked) => updateModuleInstance(instance.id, 'unified', checked as boolean)}
                />
                <Label htmlFor={`${instance.id}-unified`} className="text-sm font-normal cursor-pointer">
                  Unify
                </Label>
              </div>
            )}
            {!showSplitInputs && (
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={`${instance.id}-split`}
                  checked={instance.split}
                  onCheckedChange={(checked) => updateModuleInstance(instance.id, 'split', checked as boolean)}
                />
                <Label htmlFor={`${instance.id}-split`} className="text-sm font-normal cursor-pointer">
                  Split
                </Label>
              </div>
            )}
          </div>

          {isLiquidity && (
            <div className="space-y-2 pt-2 border-t border-border/50">
              <Alert className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/20">
                <Flame className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                <AlertTitle className="text-orange-600 dark:text-orange-400 text-sm">Automatic Liquidity Burn</AlertTitle>
                <AlertDescription className="text-xs text-muted-foreground">
                  🔥 All LP tokens created during token minting are automatically sent to a permanent burn address (<code className="bg-muted px-1 rounded">{LIQUIDITY_BURN_ADDRESS}</code>) and are non-recoverable. No developer or creator routing options available.
                </AlertDescription>
              </Alert>
            </div>
          )}

          {isTreasury && (
            <div className="space-y-2 pt-2 border-t border-border/50">
              <Label htmlFor={`${instance.id}-treasuryAddress`} className="text-sm font-medium flex items-center gap-2">
                <Wallet className="h-4 w-4" />
                Your Project&apos;s Treasury Wallet Address
              </Label>
              <Input
                id={`${instance.id}-treasuryAddress`}
                placeholder="Paste your project treasury wallet address…"
                value={instance.treasuryAddress}
                onChange={(e) => updateModuleInstance(instance.id, 'treasuryAddress', e.target.value)}
                className={`font-mono text-xs ${
                  instance.treasuryAddress && !isValidWalletAddress(instance.treasuryAddress)
                    ? 'border-destructive focus-visible:ring-destructive'
                    : ''
                }`}
              />
              {instance.treasuryAddress && !isValidWalletAddress(instance.treasuryAddress) && (
                <p className="text-xs text-destructive flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Invalid address format. Please enter a valid 64-character hex address.
                </p>
              )}
              {instance.treasuryAddress && isValidWalletAddress(instance.treasuryAddress) && (
                <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Valid treasury address
                </p>
              )}
              <p className="text-xs text-muted-foreground">
                💼 This is where your project&apos;s treasury fees will be sent. The automatic 0.25% builder fee remains separate and routes to the developer wallet.
              </p>
            </div>
          )}

          {isYield && (
            <div className="space-y-2">
              <Label htmlFor={`${instance.id}-address`} className="text-sm">
                Reward Token Contract Address (Optional)
              </Label>
              <Input
                id={`${instance.id}-address`}
                placeholder="Enter reward token address for cross-token rewards"
                value={instance.rewardTokenAddress}
                onChange={(e) => updateModuleInstance(instance.id, 'rewardTokenAddress', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                🎯 Optional: Specify a different token for rewards. If left empty, rewards distribute in your token. All rewards are automatically distributed proportionally to holders based on their ownership percentage.
              </p>
            </div>
          )}

          {isSupport && (
            <div className="space-y-2">
              <Label htmlFor={`${instance.id}-tokenAddress`} className="text-sm">
                Token Address (Required)
              </Label>
              <Input
                id={`${instance.id}-tokenAddress`}
                placeholder="Enter token address to burn/support"
                value={instance.tokenAddress}
                onChange={(e) => updateModuleInstance(instance.id, 'tokenAddress', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                🔥 Required: Specify another project&apos;s token address to burn. The buy/sell tax percentage will be applied to that token address. Distributions are automatic and proportional to holder shares.
              </p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderDistributionPreview = () => {
    const preview = calculateDistributionPreview();
    
    return (
      <Dialog open={showDistributionPreview} onOpenChange={setShowDistributionPreview}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary" />
              Automatic Proportional Distribution System
            </DialogTitle>
            <DialogDescription>
              Live example showing how the backend automatically calculates and distributes fees to all token holders
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <Alert className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
              <Zap className="h-4 w-4 text-blue-500" />
              <AlertTitle className="text-blue-600 dark:text-blue-400">Fully Automated Fee-on-Transfer System</AlertTitle>
              <AlertDescription className="text-sm space-y-2">
                <p>✅ <strong>No manual tax recipient configuration needed</strong> - the backend automatically distributes all fees</p>
                <p>✅ <strong>Fixed 0.25% treasury fee</strong> is isolated and routed only to the developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...)</p>
                <p>✅ <strong>All other fees</strong> are automatically distributed proportionally to token holders based on ownership percentage</p>
                <p>✅ <strong>Real-time calculation</strong> - rewards are computed based on each holder&apos;s share of total supply</p>
                <p>🔄 <strong>Reflection modules</strong> automatically target your token itself for self-token rewards - no manual configuration</p>
                <p>🔥 <strong>Liquidity LP tokens</strong> are automatically burned to permanent address (<code className="bg-muted px-1 rounded">{LIQUIDITY_BURN_ADDRESS}</code>) - non-recoverable</p>
                <p>🎯 <strong>Developer wallet whitelisted</strong> - no fees, full reward eligibility</p>
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Coins className="h-4 w-4" />
                  Example Transaction Scenario
                </h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Transaction Amount:</span>
                    <span className="font-medium">{preview.transactionAmount.toLocaleString()} tokens</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Fee ({preview.totalBuy.toFixed(2)}%):</span>
                    <span className="font-medium">{preview.totalFeeAmount.toFixed(2)} tokens</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-lg p-4 space-y-3 border border-amber-500/20">
                <h4 className="font-semibold flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                  Automatic Fee Distribution Breakdown
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center p-3 bg-background/50 rounded border border-amber-500/20">
                    <div className="flex items-center gap-2">
                      <Wallet className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                      <span className="font-medium">Fixed Treasury Fee (0.25%):</span>
                    </div>
                    <span className="font-semibold text-amber-600 dark:text-amber-400">
                      {preview.treasuryFeeAmount.toFixed(2)} tokens
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground px-3">
                    → Routed exclusively to developer wallet: <code className="bg-muted px-1 rounded">{DEVELOPER_WALLET.slice(0, 16)}...</code>
                  </p>
                  
                  <div className="flex justify-between items-center p-3 bg-background/50 rounded border border-green-500/20 mt-3">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
                      <span className="font-medium">Proportional Distribution ({(preview.totalBuy - AUTOMATIC_TREASURY_FEE).toFixed(2)}%):</span>
                    </div>
                    <span className="font-semibold text-green-600 dark:text-green-400">
                      {preview.distributionFeeAmount.toFixed(2)} tokens
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground px-3">
                    → Automatically distributed to ALL token holders based on their ownership percentage
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                  Holder Rewards (Calculated Automatically by Backend)
                </h4>
                <p className="text-xs text-muted-foreground">
                  Each holder receives rewards proportional to their token balance. No manual configuration required.
                </p>
                <div className="space-y-2">
                  {preview.distributions.map((holder, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-gradient-to-r from-green-500/5 to-emerald-500/5 rounded-lg border border-green-500/20">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center font-bold text-sm border border-green-500/30">
                          {holder.percentage}%
                        </div>
                        <div>
                          <p className="font-medium text-sm">{holder.address}</p>
                          <p className="text-xs text-muted-foreground">
                            Owns {holder.balance.toLocaleString()} tokens ({holder.percentage}% of supply)
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600 dark:text-green-400">
                          +{holder.reward.toFixed(4)} tokens
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Auto-distributed
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Alert className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/20">
                <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-600 dark:text-green-400">✅ System Validation Complete</AlertTitle>
                <AlertDescription className="text-sm space-y-1">
                  <p>✓ <strong>Treasury fee isolated:</strong> 0.25% ({preview.treasuryFeeAmount.toFixed(4)} tokens) → Developer wallet only</p>
                  <p>✓ <strong>Proportional distribution verified:</strong> {preview.distributionFeeAmount.toFixed(4)} tokens distributed based on ownership</p>
                  <p>✓ <strong>All holders rewarded:</strong> Each holder receives {((preview.distributionFeeAmount / preview.totalFeeAmount) * 100).toFixed(2)}% of total fees proportionally</p>
                  <p>✓ <strong>No manual configuration:</strong> Backend automatically calculates holder percentages and distributes rewards</p>
                  <p>🔄 <strong>Reflection modules:</strong> Automatically target your token itself for self-token rewards</p>
                  <p>🔥 <strong>Liquidity LP tokens:</strong> Automatically burned to permanent address ({LIQUIDITY_BURN_ADDRESS}) - non-recoverable</p>
                  <p>🎯 <strong>Developer wallet whitelisted:</strong> No fees, full reward eligibility</p>
                  <p>✓ <strong>Total distribution accuracy:</strong> {preview.treasuryFeeAmount.toFixed(4)} + {preview.distributionFeeAmount.toFixed(4)} = {preview.totalFeeAmount.toFixed(4)} tokens ✓</p>
                </AlertDescription>
              </Alert>

              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-500" />
                  How Proportional Distribution Works
                </h4>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Backend tracks all token holder balances in real-time</li>
                  <li>• On each transaction, fees are collected automatically</li>
                  <li>• Fixed 0.25% is sent to developer wallet (isolated from distribution)</li>
                  <li>• Remaining fees are distributed: <code className="bg-muted px-1 rounded">holderReward = totalFee × (holderBalance / totalSupply)</code></li>
                  <li>• No gas fees for holders - rewards are credited automatically</li>
                  <li>• Reward tokens (if specified in Yield modules) follow the same proportional logic</li>
                  <li>🔄 Reflection modules automatically use your token&apos;s canister ID for self-token rewards</li>
                  <li>🔥 Liquidity LP tokens are automatically burned to permanent address - no recovery possible</li>
                  <li>🎯 Developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...) is whitelisted - no fees, full rewards</li>
                </ul>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button onClick={() => setShowDistributionPreview(false)} className="w-full">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Understood - Close Preview
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  const hasLiquidityModule = moduleInstances.some((m) => m.moduleType === ModuleType.liquidity);
  const hasReflectionModule = moduleInstances.some((m) => m.moduleType === ModuleType.reflection);

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      {/* Wallet Confirmation Overlay */}
      {waitingForConfirmation && (
        <div className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-card border-2 border-primary/50 rounded-lg p-8 max-w-md mx-4 shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="flex flex-col items-center gap-6 text-center">
              <div className="relative">
                <Loader2 className="h-16 w-16 text-primary animate-spin" />
                <Wallet className="h-8 w-8 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold forge-text-gradient">
                  Waiting for Wallet Confirmation…
                </h3>
                <p className="text-muted-foreground">
                  Please review and approve the transaction in your Plug wallet popup.
                </p>
                <p className="text-sm text-muted-foreground">
                  The request will remain active until you confirm or cancel.
                </p>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                <span>Wallet popup is open</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="mb-8">
        <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
        <h1 className="text-4xl font-bold mb-2 forge-text-gradient">Forge Your Token</h1>
        <p className="text-muted-foreground">Configure automatic proportional reward distribution for all token holders</p>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Step {currentStep} of 4</span>
          <span className="text-sm text-muted-foreground">{Math.round(progress)}% Complete</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader>
          <CardTitle className="forge-text-gradient">
            {currentStep === 1 && 'Basic Information'}
            {currentStep === 2 && 'Fee-on-Transfer Configuration'}
            {currentStep === 3 && 'Advanced Settings'}
            {currentStep === 4 && 'Review & Deploy'}
          </CardTitle>
          <CardDescription>
            {currentStep === 1 && 'Set the fundamental properties of your token'}
            {currentStep === 2 && '⚡ Configure automatic proportional reward distribution - totals are calculated from all active modules'}
            {currentStep === 3 && 'Fine-tune additional token parameters'}
            {currentStep === 4 && 'Review your configuration and deploy with automatic reward distribution'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {currentStep === 1 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="name">Token Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., My Awesome Token"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="symbol">Token Symbol *</Label>
                <Input
                  id="symbol"
                  placeholder="e.g., MAT"
                  value={formData.symbol}
                  onChange={(e) => updateField('symbol', e.target.value.toUpperCase())}
                  maxLength={10}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your token's purpose and utility"
                  value={formData.description}
                  onChange={(e) => updateField('description', e.target.value)}
                  rows={4}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="totalSupply">Total Supply *</Label>
                <Input
                  id="totalSupply"
                  type="number"
                  placeholder="1000000"
                  value={formData.totalSupply}
                  onChange={(e) => updateField('totalSupply', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="media">Token Emblem (Optional)</Label>
                <p className="text-xs text-muted-foreground mb-2">
                  All images will be automatically processed to 512 × 512 px square with smart center-cropping
                </p>
                <div className="space-y-4">
                  {!mediaFile ? (
                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
                      <input
                        type="file"
                        id="media"
                        accept=".png,.jpg,.jpeg,.gif,.mp4,.mp3"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <label htmlFor="media" className="cursor-pointer">
                        <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <p className="text-sm font-medium mb-1">Click to upload emblem</p>
                        <p className="text-xs text-muted-foreground">
                          PNG, JPEG, GIF, MP4, or MP3 (max 50 MB)
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Images will be scaled to 512 × 512 px
                        </p>
                      </label>
                    </div>
                  ) : (
                    <div className="relative border border-border rounded-lg p-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={removeMedia}
                        className="absolute top-2 right-2 h-8 w-8 p-0 z-10"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      {mediaFile.type.startsWith('image/') && (
                        <div className="w-full max-w-sm mx-auto">
                          <div className="aspect-square w-full overflow-hidden rounded-lg shadow-lg border-2 border-primary/20">
                            <img 
                              src={mediaPreview} 
                              alt="Preview" 
                              className="w-full h-full object-cover" 
                            />
                          </div>
                        </div>
                      )}
                      {mediaFile.type.startsWith('video/') && (
                        <div className="w-full max-w-sm mx-auto">
                          <div className="aspect-square w-full overflow-hidden rounded-lg shadow-lg border-2 border-primary/20">
                            <img 
                              src={mediaPreview} 
                              alt="Video thumbnail" 
                              className="w-full h-full object-cover" 
                            />
                          </div>
                          <p className="text-xs text-center text-muted-foreground mt-2">
                            Video thumbnail (512 × 512 px)
                          </p>
                        </div>
                      )}
                      {mediaFile.type.startsWith('audio/') && (
                        <div className="flex flex-col items-center justify-center p-8 bg-muted/30 rounded-lg">
                          <ImageIcon className="h-12 w-12 text-muted-foreground mb-4" />
                          <audio src={mediaPreview} controls className="w-full" />
                        </div>
                      )}
                      <p className="text-sm text-muted-foreground mt-2 truncate text-center">{mediaFile.name}</p>
                      <p className="text-xs text-muted-foreground text-center">
                        {(mediaFile.size / 1024 / 1024).toFixed(2)} MB • 512 × 512 px
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {currentStep === 2 && (
            <>
              <div className="rounded-lg bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 p-4 mb-6">
                <div className="flex items-start gap-3">
                  <Zap className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold mb-1">⚡ Fully Automated Proportional Distribution System</p>
                    <p className="text-xs text-muted-foreground">
                      <strong>No manual tax recipient configuration needed.</strong> All fees configured below are automatically distributed to token holders proportionally based on their ownership percentage. The backend calculates each holder&apos;s share and distributes rewards in real-time. The fixed 0.25% treasury fee is isolated and routed only to the developer wallet. Reflection modules automatically target your token itself for self-token rewards. Developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...) is whitelisted - no fees, full reward eligibility.
                    </p>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-base">Reward Distribution Modules</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        Add modules to configure how rewards are distributed. Totals are automatically calculated from all active modules.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowDistributionPreview(true)}
                      className="gap-2"
                    >
                      <Calculator className="h-4 w-4" />
                      Preview
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {renderModuleButton(ModuleType.treasury, 'Treasury')}
                    {renderModuleButton(ModuleType.burn, 'Burn')}
                    {renderModuleButton(ModuleType.reflection, 'Reflection')}
                    {renderModuleButton(ModuleType.liquidity, 'Liquidity')}
                    {renderModuleButton(ModuleType.yield_, 'Yield')}
                    {renderModuleButton(ModuleType.support, 'Support')}
                  </div>
                </div>

                {moduleInstances.length > 0 && (
                  <div className="space-y-4">
                    <Label className="text-base font-medium">Active Module Configurations</Label>
                    <div className="space-y-3">
                      {moduleInstances.map((instance) => renderModuleInstance(instance))}
                    </div>
                  </div>
                )}

                <div className="rounded-lg bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20 p-6">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold mb-3">Total Tax Summary (Automatically Calculated)</p>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="bg-background/50 rounded-lg p-4 border border-primary/20">
                          <p className="text-xs text-muted-foreground mb-1">Total Buy Tax</p>
                          <p className="text-2xl font-bold text-primary">{totalBuy.toFixed(2)}%</p>
                        </div>
                        <div className="bg-background/50 rounded-lg p-4 border border-primary/20">
                          <p className="text-xs text-muted-foreground mb-1">Total Sell Tax</p>
                          <p className="text-2xl font-bold text-primary">{totalSell.toFixed(2)}%</p>
                        </div>
                      </div>
                      <div className="space-y-2 text-xs text-muted-foreground">
                        <p className="flex items-center gap-2">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          Includes automatic <strong>0.25% treasury fee</strong> on all transactions
                        </p>
                        <p className="flex items-center gap-2">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          Allowed range: <strong>{MIN_TOTAL_TAX}% to {MAX_TOTAL_TAX}%</strong> for both buy and sell taxes
                        </p>
                        <p className="flex items-center gap-2">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          All fees (except 0.25% treasury) are automatically distributed proportionally to token holders
                        </p>
                        {hasReflectionModule && (
                          <p className="flex items-center gap-2">
                            <Repeat className="h-3 w-3 text-purple-500" />
                            Reflection modules automatically target your token itself for self-token rewards
                          </p>
                        )}
                        {hasLiquidityModule && (
                          <p className="flex items-center gap-2">
                            <Flame className="h-3 w-3 text-orange-500" />
                            All LP tokens are automatically burned to permanent address (<code className="bg-muted px-1 rounded">{LIQUIDITY_BURN_ADDRESS}</code>)
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {currentStep === 3 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="decimals">Decimals</Label>
                <Input
                  id="decimals"
                  type="number"
                  placeholder="8"
                  value={formData.decimals}
                  onChange={(e) => updateField('decimals', e.target.value)}
                  min="0"
                  max="18"
                />
                <p className="text-sm text-muted-foreground">
                  Number of decimal places (standard is 8 for ICP tokens)
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="renounceOwnership"
                    checked={formData.renounceOwnership}
                    onCheckedChange={(checked) => updateField('renounceOwnership', checked as boolean)}
                  />
                  <Label htmlFor="renounceOwnership" className="text-sm font-normal cursor-pointer">
                    Renounce Ownership
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="startableTrading"
                    checked={formData.startableTrading}
                    onCheckedChange={(checked) => updateField('startableTrading', checked as boolean)}
                  />
                  <Label htmlFor="startableTrading" className="text-sm font-normal cursor-pointer">
                    Startable Trading
                  </Label>
                </div>
              </div>

              <div className="rounded-lg bg-muted/50 p-4 space-y-2">
                <h4 className="font-medium">Additional Features (Coming Soon)</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Advanced burn mechanism</li>
                  <li>• Mint controls</li>
                  <li>• Transfer restrictions</li>
                  <li>• Governance integration</li>
                </ul>
              </div>
            </>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <Alert className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/20">
                <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-600 dark:text-green-400">✅ Proportional Distribution System Ready</AlertTitle>
                <AlertDescription className="text-sm">
                  Your token is configured with automatic proportional reward distribution. The fixed 0.25% treasury fee will be routed to the developer wallet, while all other fees will be automatically distributed to token holders based on their ownership percentage. No manual configuration required. Developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...) is whitelisted - no fees, full reward eligibility.
                  {hasReflectionModule && (
                    <span className="block mt-2">
                      🔄 <strong>Reflection modules automatically target your token itself</strong> for self-token rewards using the token&apos;s canister ID assigned at mint time.
                    </span>
                  )}
                  {hasLiquidityModule && (
                    <span className="block mt-2">
                      🔥 <strong>Liquidity LP tokens will be automatically burned</strong> to permanent address (<code className="bg-muted px-1 rounded">{LIQUIDITY_BURN_ADDRESS}</code>) and are non-recoverable.
                    </span>
                  )}
                </AlertDescription>
              </Alert>

              <div className="rounded-lg bg-muted/50 p-6 space-y-4">
                <h3 className="font-semibold text-lg">Token Summary</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Name</p>
                    <p className="font-medium">{formData.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Symbol</p>
                    <p className="font-medium">{formData.symbol}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Supply</p>
                    <p className="font-medium">{Number(formData.totalSupply).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Decimals</p>
                    <p className="font-medium">{formData.decimals}</p>
                  </div>
                </div>
                {formData.description && (
                  <div>
                    <p className="text-sm text-muted-foreground">Description</p>
                    <p className="text-sm mt-1">{formData.description}</p>
                  </div>
                )}
                {mediaFile && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Token Emblem (512 × 512 px)</p>
                    {mediaFile.type.startsWith('image/') && (
                      <div className="w-32 h-32 mx-auto">
                        <div className="aspect-square w-full overflow-hidden rounded-lg shadow-lg border-2 border-primary/20">
                          <img 
                            src={mediaPreview} 
                            alt="Token emblem" 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                      </div>
                    )}
                    {mediaFile.type.startsWith('video/') && (
                      <div className="w-32 h-32 mx-auto">
                        <div className="aspect-square w-full overflow-hidden rounded-lg shadow-lg border-2 border-primary/20">
                          <img 
                            src={mediaPreview} 
                            alt="Video thumbnail" 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                      </div>
                    )}
                    {mediaFile.type.startsWith('audio/') && (
                      <audio src={mediaPreview} controls className="w-full" />
                    )}
                  </div>
                )}
              </div>

              {moduleInstances.length > 0 && (
                <div className="rounded-lg bg-primary/10 border border-primary/20 p-6">
                  <h4 className="font-semibold mb-3">Reward Distribution Modules (Automatic)</h4>
                  <p className="text-xs text-muted-foreground mb-3">
                    ⚡ These percentages will be automatically distributed to all token holders proportionally based on their ownership share. No manual tax recipient configuration needed.
                  </p>
                  <div className="space-y-3">
                    {moduleInstances.map((instance, index) => (
                      <div key={instance.id} className="text-sm border-b border-border/30 pb-2 last:border-0">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-medium capitalize">
                            {getModuleLabel(instance.moduleType)} #{index + 1}
                          </span>
                          <span className="text-muted-foreground">
                            Buy: {instance.buyTax}% • Sell: {instance.sellTax}%
                          </span>
                        </div>
                        {instance.moduleType === ModuleType.reflection && (
                          <p className="text-xs text-purple-600 dark:text-purple-400 flex items-center gap-1">
                            <Repeat className="h-3 w-3" />
                            Automatically targets your token itself for self-token rewards
                          </p>
                        )}
                        {instance.moduleType === ModuleType.liquidity && (
                          <p className="text-xs text-orange-600 dark:text-orange-400 flex items-center gap-1">
                            <Flame className="h-3 w-3" />
                            LP tokens automatically burned to {LIQUIDITY_BURN_ADDRESS} (non-recoverable)
                          </p>
                        )}
                        {instance.treasuryAddress && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Wallet className="h-3 w-3" />
                            Treasury: {instance.treasuryAddress.slice(0, 20)}... (project treasury wallet)
                          </p>
                        )}
                        {instance.rewardTokenAddress && (
                          <p className="text-xs text-muted-foreground">
                            🎯 Reward Token: {instance.rewardTokenAddress.slice(0, 20)}... (distributed proportionally to all holders)
                          </p>
                        )}
                        {instance.tokenAddress && (
                          <p className="text-xs text-muted-foreground">
                            🔥 Support Token: {instance.tokenAddress.slice(0, 20)}... (burned proportionally)
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="rounded-lg bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20 p-6">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                  Total Tax Summary & Distribution Logic
                </h4>
                <div className="space-y-2 text-sm">
                  {moduleInstances.length > 0 && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Module Buy Tax:</span>
                        <span className="font-medium">
                          {moduleInstances.reduce((sum, m) => sum + (Number(m.buyTax) || 0), 0).toFixed(2)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Module Sell Tax:</span>
                        <span className="font-medium">
                          {moduleInstances.reduce((sum, m) => sum + (Number(m.sellTax) || 0), 0).toFixed(2)}%
                        </span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between items-center p-2 bg-amber-500/10 rounded border border-amber-500/20">
                    <span className="text-muted-foreground">Fixed Treasury Fee:</span>
                    <span className="font-semibold text-amber-600 dark:text-amber-400">{AUTOMATIC_TREASURY_FEE}%</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Buy Tax:</span>
                      <span className="font-semibold text-foreground">{totalBuy.toFixed(2)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Sell Tax:</span>
                      <span className="font-semibold text-foreground">{totalSell.toFixed(2)}%</span>
                    </div>
                  </div>
                  <div className="pt-3 mt-3 border-t space-y-2">
                    <div className="flex items-start gap-2">
                      <Wallet className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground">
                        <strong>Treasury Fee (0.25%):</strong> Routed exclusively to developer wallet <code className="bg-muted px-1 rounded">{DEVELOPER_WALLET.slice(0, 12)}...</code>
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground">
                        <strong>Proportional Distribution ({(totalBuy - AUTOMATIC_TREASURY_FEE).toFixed(2)}% buy / {(totalSell - AUTOMATIC_TREASURY_FEE).toFixed(2)}% sell):</strong> Automatically distributed to ALL token holders based on their ownership percentage. Backend calculates: <code className="bg-muted px-1 rounded">holderReward = totalFee × (holderBalance / totalSupply)</code>
                      </p>
                    </div>
                    {hasReflectionModule && (
                      <div className="flex items-start gap-2">
                        <Repeat className="h-4 w-4 text-purple-600 dark:text-purple-400 shrink-0 mt-0.5" />
                        <p className="text-xs text-muted-foreground">
                          <strong>Reflection Modules:</strong> Automatically target your token itself for self-token rewards using the token&apos;s canister ID assigned at mint time
                        </p>
                      </div>
                    )}
                    {hasLiquidityModule && (
                      <div className="flex items-start gap-2">
                        <Flame className="h-4 w-4 text-orange-600 dark:text-orange-400 shrink-0 mt-0.5" />
                        <p className="text-xs text-muted-foreground">
                          <strong>Liquidity LP Tokens:</strong> Automatically burned to permanent address <code className="bg-muted px-1 rounded">{LIQUIDITY_BURN_ADDRESS}</code> - non-recoverable, no developer/creator routing
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-6">
                <div className="flex items-start gap-4">
                  <Coins className="h-6 w-6 text-amber-500 shrink-0 mt-1" />
                  <div className="flex-1">
                    <h4 className="font-semibold mb-2">Deployment Fee</h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      A one-time fee of <span className="font-semibold text-foreground">1 ICP</span> is required to
                      deploy your token to the Internet Computer network with automatic proportional reward distribution.
                    </p>
                    <p className="text-xs text-muted-foreground">
                      This fee covers the cost of canister creation and initial cycles. Payment address:{' '}
                      <span className="font-mono">{TREASURY_MINT_FEE_ADDRESS.slice(0, 20)}...</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-6 border-t">
            <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            {currentStep < 4 ? (
              <Button onClick={handleNext} className="forge-gradient border-0">
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleDeployClick}
                disabled={createToken.isPending || isUploading || isPaymentProcessing}
                className="gap-2 forge-gradient border-0 forge-glow"
              >
                {createToken.isPending || isUploading || isPaymentProcessing ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    Deploying...
                  </>
                ) : (
                  <>
                    <Flame className="h-4 w-4" />
                    Review & Deploy
                  </>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {renderDistributionPreview()}

      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Confirm Token Deployment
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3 pt-2">
              <p className="font-medium text-foreground">Important Notice</p>
              <p>
                Please ensure all token data is correct before proceeding. Token deployment is{' '}
                <span className="font-semibold text-foreground">irreversible</span> and there are no refunds once the
                transaction is confirmed.
              </p>
              <p className="text-sm">
                By proceeding, you confirm that you have reviewed all token parameters and agree to pay the 1 ICP
                deployment fee via your connected Web3 wallet. The automatic proportional reward distribution system will distribute all configured fees to token holders based on their ownership percentage. A fixed 0.25% treasury fee will be routed exclusively to the developer wallet on all transactions. Developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...) is whitelisted - no fees, full reward eligibility.
              </p>
              {hasReflectionModule && (
                <p className="text-sm font-medium text-purple-600 dark:text-purple-400 flex items-center gap-2">
                  <Repeat className="h-4 w-4" />
                  Reflection modules will automatically target your token itself for self-token rewards using the token&apos;s canister ID assigned at mint time.
                </p>
              )}
              {hasLiquidityModule && (
                <p className="text-sm font-medium text-orange-600 dark:text-orange-400 flex items-center gap-2">
                  <Flame className="h-4 w-4" />
                  All LP tokens created during minting will be automatically burned to permanent address ({LIQUIDITY_BURN_ADDRESS}) and are non-recoverable.
                </p>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Back</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDeploy} className="forge-gradient border-0">
              Proceed to Payment
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              Pay & Deploy
            </DialogTitle>
            <DialogDescription>
              Complete the payment via your Web3 wallet to deploy your token with automatic proportional reward distribution
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {!walletConnected && (
              <Alert className="bg-amber-500/10 border-amber-500/20">
                <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                <AlertTitle className="text-amber-600 dark:text-amber-400">Wallet Not Connected</AlertTitle>
                <AlertDescription className="text-sm">
                  Please connect your Web3 wallet (Plug) to proceed with payment. Your form data is preserved. Click the button below to connect.
                </AlertDescription>
              </Alert>
            )}
            <div className="rounded-lg bg-primary/10 border border-primary/20 p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Deployment Fee</span>
                <span className="text-lg font-bold">1 ICP</span>
              </div>
              <p className="text-xs text-muted-foreground">
                One-time fee for token creation and deployment with automatic reward distribution
              </p>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Payment Address</Label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-muted rounded-md px-3 py-2 text-xs font-mono break-all">
                  {TREASURY_MINT_FEE_ADDRESS}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCopyAddress}
                  className="shrink-0"
                >
                  {addressCopied ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
            <div className="rounded-lg bg-green-500/10 border border-green-500/20 p-4">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">
                  Your Web3 wallet will be prompted to sign and send exactly 1 ICP to the address above. The request will remain active until you confirm or cancel in your wallet popup. Once payment is confirmed on-chain, your token will be
                  deployed automatically with the proportional reward distribution system. The fixed 0.25% treasury fee will be routed to the developer wallet, while all other fees will be automatically distributed to token holders based on their ownership percentage. No manual configuration required. Developer wallet ({DEVELOPER_WALLET.slice(0, 12)}...) is whitelisted - no fees, full reward eligibility.
                  {hasReflectionModule && (
                    <span className="block mt-2 text-purple-600 dark:text-purple-400 font-medium">
                      🔄 Reflection modules will automatically target your token itself for self-token rewards.
                    </span>
                  )}
                  {hasLiquidityModule && (
                    <span className="block mt-2 text-orange-600 dark:text-orange-400 font-medium">
                      🔥 All LP tokens will be automatically burned to permanent address ({LIQUIDITY_BURN_ADDRESS}) and are non-recoverable.
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setShowPaymentDialog(false)}
              disabled={createToken.isPending || isUploading || isPaymentProcessing || waitingForConfirmation}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            {!walletConnected ? (
              <Button
                onClick={connectPlug}
                className="w-full sm:w-auto gap-2 forge-gradient border-0"
              >
                <Wallet className="h-4 w-4" />
                Connect Wallet
              </Button>
            ) : (
              <Button
                onClick={handlePayAndDeploy}
                disabled={createToken.isPending || isUploading || isPaymentProcessing || waitingForConfirmation}
                className="w-full sm:w-auto gap-2 forge-gradient border-0 forge-glow"
              >
                {createToken.isPending || isUploading || isPaymentProcessing || waitingForConfirmation ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    {isUploading ? 'Preparing...' : waitingForConfirmation ? 'Waiting for Confirmation...' : isPaymentProcessing ? 'Processing Payment...' : 'Deploying...'}
                  </>
                ) : (
                  <>
                    <Flame className="h-4 w-4" />
                    Confirm Payment & Deploy
                  </>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-2xl">
              <div className="h-12 w-12 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center border-2 border-green-500/30">
                <Sparkles className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              Token Successfully Minted & Deployed!
            </DialogTitle>
            <DialogDescription className="text-base pt-2">
              Your token <strong className="text-foreground">{deployedTokenSymbol}</strong> has been successfully deployed to the Internet Computer with automatic proportional reward distribution.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <Alert className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/20">
              <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
              <AlertTitle className="text-green-600 dark:text-green-400 text-base">✅ Deployment Complete</AlertTitle>
              <AlertDescription className="text-sm space-y-2 mt-2">
                <p>✓ <strong>Token minted successfully</strong> with proportional reward distribution system</p>
                <p>✓ <strong>Fixed 0.25% treasury fee</strong> configured and isolated for developer wallet</p>
                <p>✓ <strong>All other fees</strong> will be automatically distributed to token holders based on ownership percentage</p>
                {hasReflectionModule && (
                  <p>🔄 <strong>Reflection modules</strong> automatically target your token itself for self-token rewards</p>
                )}
                {hasLiquidityModule && (
                  <p>🔥 <strong>Liquidity LP tokens</strong> automatically burned to permanent address ({LIQUIDITY_BURN_ADDRESS})</p>
                )}
                <p>🎯 <strong>Developer wallet whitelisted</strong> - no fees, full reward eligibility</p>
                <p>✓ <strong>No manual configuration required</strong> - backend handles all reward calculations</p>
              </AlertDescription>
            </Alert>

            {deployedCanisterId && (
              <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-4">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Coins className="h-4 w-4 text-blue-500" />
                  Token Canister ID
                </h4>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-muted rounded-md px-3 py-2 text-xs font-mono break-all">
                    {deployedCanisterId}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopyCanisterId}
                    className="shrink-0"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Use this Canister ID to add liquidity on ICPSwap or Sonic
                </p>
              </div>
            )}

            <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-4">
              <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                <Info className="h-4 w-4 text-blue-500" />
                What Happens Next?
              </h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Your token is now live on the Internet Computer</li>
                <li>• Proportional reward distribution is active for all transactions</li>
                <li>• Token holders automatically receive rewards based on their ownership percentage</li>
                <li>• Fixed 0.25% treasury fee routes to developer wallet</li>
                <li>• Developer wallet is whitelisted - no fees, full rewards</li>
                <li>• View your token details in the Dashboard</li>
                <li>• Share your token with the community via Forged Tokens explorer</li>
                <li>• Add liquidity on ICPSwap or Sonic using the Canister ID above</li>
              </ul>
            </div>
          </div>

          <DialogFooter>
            <Button onClick={handleSuccessClose} className="w-full gap-2 forge-gradient border-0 forge-glow">
              <CheckCircle2 className="h-4 w-4" />
              Go to Dashboard
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
