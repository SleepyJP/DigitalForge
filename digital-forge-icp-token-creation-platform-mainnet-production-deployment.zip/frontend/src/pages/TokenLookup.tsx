import { useState } from 'react';
import { useLookupToken } from '../hooks/useQueries';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Alert, AlertDescription, AlertTitle } from '../components/ui/alert';
import { Separator } from '../components/ui/separator';
import { ArrowLeft, Search, Copy, CheckCircle2, AlertTriangle, Coins, TrendingUp, Calendar, Hash, Wallet, ExternalLink, Info } from 'lucide-react';
import { toast } from 'sonner';
import type { TokenMetadata } from '../backend';

type View = 'home' | 'create' | 'dashboard' | 'forged' | 'lookup';

interface TokenLookupProps {
  onNavigate: (view: View) => void;
}

export default function TokenLookup({ onNavigate }: TokenLookupProps) {
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const { data: token, isLoading, isError, error } = useLookupToken(searchQuery);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleSearch = () => {
    if (!searchInput.trim()) {
      toast.error('Please enter a canister ID or transaction hash');
      return;
    }
    setSearchQuery(searchInput.trim());
  };

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast.success(`${fieldName} copied to clipboard`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const formatDate = (timestamp: bigint) => {
    try {
      const date = new Date(Number(timestamp) / 1000000);
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      console.error('Failed to format date:', error);
      return 'Invalid date';
    }
  };

  const formatSupply = (supply: bigint, decimals: bigint) => {
    try {
      const divisor = BigInt(10) ** decimals;
      const whole = supply / divisor;
      return whole.toLocaleString();
    } catch (error) {
      console.error('Failed to format supply:', error);
      return '0';
    }
  };

  const renderTokenDetails = (token: TokenMetadata) => {
    return (
      <div className="space-y-8">
        {/* General Information */}
        <Card className="border-border/50 bg-gradient-to-br from-background to-primary/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">General Information</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleCopy(JSON.stringify(token, null, 2), 'All Data')}
                className="gap-2"
              >
                {copiedField === 'All Data' ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                Copy All
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Token Address</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCopy(token.canisterId.toString(), 'Token Address')}
                      className="h-6 gap-1"
                    >
                      {copiedField === 'Token Address' ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                  <p className="font-mono text-sm break-all bg-muted/50 p-2 rounded">
                    {token.canisterId.toString()}
                  </p>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Name</span>
                  <span className="font-semibold text-lg">{token.name}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Symbol</span>
                  <Badge variant="outline" className="bg-primary/10 text-lg px-3 py-1">
                    {token.symbol}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Initial Supply</span>
                  <span className="font-medium">{formatSupply(token.totalSupply, token.decimals)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Current Supply</span>
                  <span className="font-medium">{formatSupply(token.circulatingSupply, token.decimals)}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Decimals</span>
                  <span className="font-medium">{token.decimals.toString()}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Standard</span>
                  <Badge variant="outline" className="bg-primary/10">ICRC-2</Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Ownership Renounced</span>
                  <Badge variant={token.verified ? 'default' : 'secondary'}>
                    {token.verified ? 'Yes' : 'No'}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Trading Enabled</span>
                  <Badge variant={token.mintFeePaid ? 'default' : 'secondary'}>
                    {token.mintFeePaid ? 'Yes' : 'Pending'}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Created</span>
                  <span className="font-medium text-sm">{formatDate(token.deployedAt)}</span>
                </div>
              </div>
            </div>

            {token.description && (
              <>
                <Separator />
                <div>
                  <span className="text-sm text-muted-foreground block mb-2">Description</span>
                  <p className="text-sm">{token.description}</p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Tax Information */}
        <Card className="border-border/50 bg-gradient-to-br from-background to-blue-500/5">
          <CardHeader>
            <CardTitle className="text-2xl">Tax Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Buy Tax</span>
                  <span className="font-semibold text-lg text-green-600 dark:text-green-400">
                    {Number(token.buyTax) / 100}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Sell Tax</span>
                  <span className="font-semibold text-lg text-red-600 dark:text-red-400">
                    {Number(token.sellTax) / 100}%
                  </span>
                </div>
                {Number(token.treasuryFee) > 0 && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Treasury Fee</span>
                    <span className="font-semibold text-lg text-primary">
                      {Number(token.treasuryFee) / 100}%
                    </span>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <span className="text-sm text-muted-foreground block mb-2">Treasury Address</span>
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-xs break-all bg-muted/50 p-2 rounded flex-1">
                      {token.treasuryAddress}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCopy(token.treasuryAddress, 'Treasury Address')}
                      className="h-8"
                    >
                      {copiedField === 'Treasury Address' ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {token.moduleConfigs && token.moduleConfigs.length > 0 && (
              <>
                <Separator />
                <div>
                  <h3 className="text-lg font-semibold mb-4">Active Tax Modules</h3>
                  <div className="space-y-4">
                    {token.moduleConfigs.map((config, idx) => (
                      <Card key={idx} className="border-border/30 bg-muted/30">
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between mb-3">
                            <Badge variant="secondary" className="text-sm">
                              {String(config.moduleType).replace('_', ' ').toUpperCase()}
                            </Badge>
                            <div className="text-right">
                              <div className="text-xs text-muted-foreground">Buy / Sell</div>
                              <div className="font-semibold">
                                {Number(config.buyTax) / 100}% / {Number(config.sellTax) / 100}%
                              </div>
                            </div>
                          </div>
                          {config.rewardTokenAddress && (
                            <div className="mt-2">
                              <span className="text-xs text-muted-foreground">Reward Token: </span>
                              <span className="text-xs font-mono">{config.rewardTokenAddress}</span>
                            </div>
                          )}
                          {config.tokenAddress && (
                            <div className="mt-2">
                              <span className="text-xs text-muted-foreground">Token Address: </span>
                              <span className="text-xs font-mono">{config.tokenAddress}</span>
                            </div>
                          )}
                          {config.reflectionTarget && (
                            <div className="mt-2">
                              <span className="text-xs text-muted-foreground">Reflection Target: </span>
                              <span className="text-xs font-mono">{config.reflectionTarget.toString()}</span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
              <div className="flex items-start gap-3">
                <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium mb-1">Automatic 0.25% Treasury Fee</p>
                  <p className="text-muted-foreground">
                    All transactions automatically include a 0.25% treasury fee routed to the platform treasury address.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Creator Information */}
        <Card className="border-border/50 bg-gradient-to-br from-background to-purple-500/5">
          <CardHeader>
            <CardTitle className="text-2xl">Creator Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Creator Principal</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCopy(token.creator.toString(), 'Creator Principal')}
                  className="h-6 gap-1"
                >
                  {copiedField === 'Creator Principal' ? (
                    <CheckCircle2 className="h-3 w-3 text-green-500" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                </Button>
              </div>
              <p className="font-mono text-sm break-all bg-muted/50 p-2 rounded">
                {token.creator.toString()}
              </p>
            </div>

            {token.creatorName && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Creator Name</span>
                <span className="font-medium">{token.creatorName}</span>
              </div>
            )}

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Deployment Date</span>
              <span className="font-medium">{formatDate(token.deployedAt)}</span>
            </div>

            {token.tags && token.tags.length > 0 && (
              <div>
                <span className="text-sm text-muted-foreground block mb-2">Tags</span>
                <div className="flex flex-wrap gap-2">
                  {token.tags.map((tag, idx) => (
                    <Badge key={idx} variant="outline">{tag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* External Links */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-2xl">External Resources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => window.open(`https://dashboard.internetcomputer.org/canister/${token.canisterId.toString()}`, '_blank')}
            >
              <ExternalLink className="h-4 w-4" />
              View on IC Dashboard
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => window.open(`https://dexscreener.com/icp/${token.canisterId.toString()}`, '_blank')}
            >
              <ExternalLink className="h-4 w-4" />
              View on Dexscreener
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
        <div>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">
            Token Lookup
          </h1>
          <p className="text-muted-foreground">Enter a transaction hash or token address to view token details</p>
        </div>
      </div>

      {/* Search Interface */}
      <Card className="border-border/50 mb-8 bg-gradient-to-br from-background to-primary/5">
        <CardHeader>
          <CardTitle>Token Address or Transaction Hash</CardTitle>
          <CardDescription>Search for any token deployed on Digital Forge ICP</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="0x..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
              className="flex-1 font-mono"
            />
            <Button onClick={handleSearch} disabled={isLoading} className="gap-2">
              <Search className="h-4 w-4" />
              Lookup
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="text-center">
            <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
            <p className="text-muted-foreground">Searching for token...</p>
          </div>
        </div>
      )}

      {isError && searchQuery && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Token Not Found</AlertTitle>
          <AlertDescription>
            {error instanceof Error ? error.message : 'The token you are looking for could not be found. Please check the canister ID and try again.'}
          </AlertDescription>
        </Alert>
      )}

      {!isLoading && !isError && !token && !searchQuery && (
        <Card className="border-border/50 text-center py-16">
          <CardContent>
            <Search className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-2xl font-bold mb-2">Search for a Token</h3>
            <p className="text-muted-foreground">
              Enter a canister ID or transaction hash above to view detailed token information
            </p>
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && token && searchQuery && (
        <div>
          {renderTokenDetails(token)}
        </div>
      )}
    </div>
  );
}
