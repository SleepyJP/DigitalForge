import { useState, useMemo } from 'react';
import { useGetForgedTokens } from '../hooks/useQueries';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Skeleton } from '../components/ui/skeleton';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ScrollArea } from '../components/ui/scroll-area';
import { Separator } from '../components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '../components/ui/alert';
import { Coins, TrendingUp, Calendar, ArrowLeft, Search, Image as ImageIcon, Video, Music, ExternalLink, BarChart3, Info, X, RefreshCw, Sparkles, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import type { TokenMetadata } from '../backend';

type View = 'home' | 'create' | 'dashboard' | 'forged';

interface ForgedTokensProps {
  onNavigate: (view: View) => void;
}

type SortOption = 'date-desc' | 'date-asc' | 'name-asc' | 'name-desc' | 'fee-desc' | 'fee-asc' | 'supply-desc' | 'supply-asc';

export default function ForgedTokens({ onNavigate }: ForgedTokensProps) {
  const { data: tokens, isLoading, isError, error, refetch } = useGetForgedTokens();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('date-desc');
  const [selectedToken, setSelectedToken] = useState<TokenMetadata | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const formatDate = (timestamp: bigint) => {
    try {
      const date = new Date(Number(timestamp) / 1000000);
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    } catch (error) {
      console.error('Failed to format date:', error);
      return 'Invalid date';
    }
  };

  const formatSupply = (supply: bigint, decimals: bigint) => {
    try {
      const divisor = BigInt(10) ** decimals;
      const whole = supply / divisor;
      return whole.toLocaleString();
    } catch (error) {
      console.error('Failed to format supply:', error);
      return '0';
    }
  };

  const getMediaType = (url: string): 'image' | 'video' | 'audio' | 'unknown' => {
    if (!url) return 'unknown';
    const lower = url.toLowerCase();
    if (lower.match(/\.(png|jpg|jpeg|gif|webp)$/) || lower.startsWith('data:image/')) return 'image';
    if (lower.match(/\.(mp4|webm|mov)$/) || lower.startsWith('data:video/')) return 'video';
    if (lower.match(/\.(mp3|wav|ogg)$/) || lower.startsWith('data:audio/')) return 'audio';
    return 'unknown';
  };

  const filteredAndSortedTokens = useMemo(() => {
    if (!tokens || !Array.isArray(tokens)) {
      console.warn('Tokens data is not an array:', tokens);
      return [];
    }

    let filtered = tokens.filter((token) => {
      if (!token || !token.name || !token.symbol) {
        console.warn('Invalid token in list:', token);
        return false;
      }

      const query = searchQuery.toLowerCase();
      return (
        token.name.toLowerCase().includes(query) ||
        token.symbol.toLowerCase().includes(query) ||
        (token.description && token.description.toLowerCase().includes(query)) ||
        (token.creator && token.creator.toString().toLowerCase().includes(query))
      );
    });

    filtered.sort((a, b) => {
      try {
        switch (sortBy) {
          case 'date-desc':
            return Number(b.deployedAt - a.deployedAt);
          case 'date-asc':
            return Number(a.deployedAt - b.deployedAt);
          case 'name-asc':
            return a.name.localeCompare(b.name);
          case 'name-desc':
            return b.name.localeCompare(a.name);
          case 'fee-desc':
            return Number(b.treasuryFee - a.treasuryFee);
          case 'fee-asc':
            return Number(a.treasuryFee - b.treasuryFee);
          case 'supply-desc':
            return Number(b.totalSupply - a.totalSupply);
          case 'supply-asc':
            return Number(a.totalSupply - b.totalSupply);
          default:
            return 0;
        }
      } catch (error) {
        console.error('Error sorting tokens:', error);
        return 0;
      }
    });

    return filtered;
  }, [tokens, searchQuery, sortBy]);

  const handleTokenClick = (token: TokenMetadata) => {
    if (!token || !token.symbol) {
      console.error('Invalid token clicked:', token);
      toast.error('Unable to display token details');
      return;
    }

    setSelectedToken(token);
    setShowDetailsModal(true);
  };

  const handleCloseModal = () => {
    setShowDetailsModal(false);
    setTimeout(() => setSelectedToken(null), 300);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refetch();
      toast.success('Token list refreshed');
    } catch (error) {
      toast.error('Failed to refresh');
    } finally {
      setIsRefreshing(false);
    }
  };

  const renderMediaPreview = (token: TokenMetadata, size: 'small' | 'large' = 'small') => {
    if (!token) {
      return (
        <div className="w-full h-64 aspect-square bg-gradient-to-br from-blue-500/10 via-magenta-500/10 to-cyan-500/10 flex items-center justify-center rounded-lg shadow-lg border-2 border-primary/20">
          <ImageIcon className="h-16 w-16 text-muted-foreground opacity-50" />
        </div>
      );
    }

    const mediaType = getMediaType(token.mediaUrl || '');
    const hasMedia = token.mediaUrl && token.mediaUrl.trim() !== '';
    const sizeClass = size === 'small' ? 'w-full h-64' : 'w-full max-w-md mx-auto aspect-square';

    if (!hasMedia) {
      return (
        <div className={`${sizeClass} aspect-square bg-gradient-to-br from-blue-500/10 via-magenta-500/10 to-cyan-500/10 flex items-center justify-center rounded-lg shadow-lg border-2 border-primary/20`}>
          <ImageIcon className="h-16 w-16 text-muted-foreground opacity-50" />
        </div>
      );
    }

    return (
      <div className={`${sizeClass} aspect-square bg-muted/30 overflow-hidden rounded-lg shadow-lg border-2 border-primary/20`}>
        {mediaType === 'image' && (
          <img
            src={token.mediaUrl}
            alt={token.name || 'Token emblem'}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
              const parent = e.currentTarget.parentElement;
              if (parent) {
                parent.innerHTML = `<div class="flex items-center justify-center h-full"><div class="text-muted-foreground"><svg class="h-12 w-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg></div></div>`;
              }
            }}
          />
        )}
        {mediaType === 'video' && (
          <video
            src={token.mediaUrl}
            className="w-full h-full object-cover"
            controls
            preload="metadata"
          />
        )}
        {mediaType === 'audio' && (
          <div className="flex flex-col items-center justify-center h-full p-4 bg-gradient-to-br from-blue-500/10 via-magenta-500/10 to-cyan-500/10">
            <Music className="h-16 w-16 text-primary mb-4" />
            <audio src={token.mediaUrl} controls className="w-full max-w-md" />
          </div>
        )}
        {mediaType === 'unknown' && (
          <div className="flex items-center justify-center h-full bg-gradient-to-br from-blue-500/10 via-magenta-500/10 to-cyan-500/10">
            <ImageIcon className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        )}
      </div>
    );
  };

  const renderDexscreenerWidget = (token: TokenMetadata) => {
    if (!token || !token.canisterId) {
      return (
        <div className="h-full px-6 pb-6">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Invalid Token Data</AlertTitle>
            <AlertDescription>Unable to display chart information for this token.</AlertDescription>
          </Alert>
        </div>
      );
    }

    const canisterId = token.canisterId.toString();
    const isDeployed = token.mintFeePaid;

    return (
      <div className="h-full px-6 pb-6">
        <div className="bg-muted/30 rounded-lg h-full flex flex-col items-center justify-center p-8">
          <div className="w-full max-w-3xl space-y-6">
            <div className="text-center">
              <BarChart3 className="h-16 w-16 text-primary mx-auto mb-4" />
              <h3 className="text-2xl font-semibold mb-2">Live Trading Charts</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                {isDeployed 
                  ? 'Once this token is listed on a DEX and indexed by Dexscreener, live trading data will appear here.'
                  : 'This token needs to be deployed before trading charts can be displayed.'}
              </p>
            </div>

            <div className="bg-background/50 rounded-lg p-6 border border-border/50 space-y-4">
              <div className="flex items-start gap-3">
                <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="space-y-3 flex-1">
                  <div>
                    <h4 className="font-semibold mb-2">Integration Requirements</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Token must be deployed with liquidity on a supported DEX (e.g., ICPSwap, Sonic)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Automatic indexing by Dexscreener after trading begins</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Sufficient trading volume to generate meaningful chart data</span>
                      </li>
                    </ul>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Token Symbol:</span>
                      <span className="font-mono font-medium">{token.symbol}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Canister ID:</span>
                      <span className="font-mono text-xs break-all">{canisterId}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Status:</span>
                      {isDeployed ? (
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400">
                          Deployed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 dark:text-yellow-400">
                          Pending Deployment
                        </Badge>
                      )}
                    </div>
                  </div>

                  {isDeployed && (
                    <>
                      <Separator />
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">External Resources</h4>
                        <div className="flex flex-col gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full justify-start gap-2"
                            onClick={() => window.open(`https://dexscreener.com/icp/${canisterId}`, '_blank')}
                          >
                            <ExternalLink className="h-4 w-4" />
                            View on Dexscreener
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full justify-start gap-2"
                            onClick={() => window.open(`https://dashboard.internetcomputer.org/canister/${canisterId}`, '_blank')}
                          >
                            <ExternalLink className="h-4 w-4" />
                            View Canister Details
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {isDeployed && (
              <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium mb-1">Coming Soon: Embedded Charts</p>
                    <p className="text-muted-foreground">
                      We're working on integrating live Dexscreener charts directly into this interface. 
                      For now, use the external links above to view trading data.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  if (isError) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </div>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Failed to Load Community Tokens</AlertTitle>
          <AlertDescription>
            {error instanceof Error ? error.message : 'An unexpected error occurred while loading community tokens.'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
        <div className="flex flex-col gap-4">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2 forge-text-gradient">
                Community Token Explorer
              </h1>
              <p className="text-muted-foreground">Discover and analyze all tokens forged on Digital Forge ICP</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, symbol, creator, or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date-desc">Newest First</SelectItem>
                <SelectItem value="date-asc">Oldest First</SelectItem>
                <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                <SelectItem value="supply-desc">Highest Supply</SelectItem>
                <SelectItem value="supply-asc">Lowest Supply</SelectItem>
                <SelectItem value="fee-desc">Highest Fee</SelectItem>
                <SelectItem value="fee-asc">Lowest Fee</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="border-border/50">
              <CardHeader>
                <Skeleton className="aspect-square w-full mb-4 rounded-lg" />
                <Skeleton className="h-6 w-32 mb-2" />
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredAndSortedTokens.length > 0 ? (
        <>
          <div className="mb-6 text-sm text-muted-foreground">
            Showing {filteredAndSortedTokens.length} {filteredAndSortedTokens.length === 1 ? 'token' : 'tokens'}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedTokens.map((token) => {
              if (!token || !token.symbol || !token.name) {
                console.warn('Invalid token in filtered list:', token);
                return null;
              }

              return (
                <Card
                  key={token.symbol}
                  className="border-border/50 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10 transition-all cursor-pointer overflow-hidden group"
                  onClick={() => handleTokenClick(token)}
                >
                  <div className="p-4">
                    {renderMediaPreview(token, 'small')}
                  </div>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl group-hover:text-primary transition-colors">{token.name}</CardTitle>
                        <CardDescription className="text-lg font-mono">{token.symbol}</CardDescription>
                      </div>
                      <Badge variant="outline" className="bg-primary/10 shrink-0">
                        ICRC-2
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {token.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{token.description}</p>
                    )}
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Coins className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Supply:</span>
                      </div>
                      <span className="font-medium text-right">{formatSupply(token.totalSupply, token.decimals)}</span>
                      
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Taxes:</span>
                      </div>
                      <span className="font-medium text-right">
                        {Number(token.buyTax) / 100}% / {Number(token.sellTax) / 100}%
                      </span>
                      
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Created:</span>
                      </div>
                      <span className="font-medium text-right">{formatDate(token.deployedAt)}</span>
                    </div>
                    <div className="flex items-center justify-end pt-2 border-t border-border/50">
                      {token.mintFeePaid && (
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400">
                          Deployed
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            }).filter(Boolean)}
          </div>
        </>
      ) : (
        <Card className="border-border/50 text-center py-16">
          <CardContent>
            <Coins className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-2xl font-bold mb-2">
              {searchQuery ? 'No Tokens Found' : 'No Tokens Available'}
            </h3>
            <p className="text-muted-foreground mb-6">
              {searchQuery
                ? 'Try adjusting your search criteria'
                : 'No community tokens are available yet'}
            </p>
            {!searchQuery && (
              <Button onClick={() => onNavigate('create')} className="gap-2">
                <Coins className="h-4 w-4" />
                Create First Token
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="max-w-6xl max-h-[90vh] p-0 overflow-hidden">
          {selectedToken && selectedToken.symbol && selectedToken.name ? (
            <div className="flex flex-col h-full">
              <DialogHeader className="px-6 pt-6 pb-4">
                <div className="flex items-start justify-between">
                  <div>
                    <DialogTitle className="text-3xl mb-2">{selectedToken.name}</DialogTitle>
                    <DialogDescription className="text-xl font-mono">{selectedToken.symbol}</DialogDescription>
                  </div>
                  <Button variant="ghost" size="icon" onClick={handleCloseModal}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </DialogHeader>
              
              <Tabs defaultValue="details" className="flex-1 flex flex-col overflow-hidden">
                <TabsList className="mx-6 w-fit">
                  <TabsTrigger value="details" className="gap-2">
                    <Info className="h-4 w-4" />
                    Details
                  </TabsTrigger>
                  <TabsTrigger value="chart" className="gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Live Chart
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="flex-1 overflow-hidden mt-0">
                  <ScrollArea className="h-full">
                    <div className="px-6 pb-6 space-y-6">
                      <div className="flex justify-center">
                        {renderMediaPreview(selectedToken, 'large')}
                      </div>
                      
                      {selectedToken.description && (
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Description</h3>
                          <p className="text-muted-foreground">{selectedToken.description}</p>
                        </div>
                      )}

                      <Separator />

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold">Token Information</h3>
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Symbol:</span>
                              <span className="font-mono font-medium">{selectedToken.symbol}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Total Supply:</span>
                              <span className="font-medium">{formatSupply(selectedToken.totalSupply, selectedToken.decimals)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Circulating Supply:</span>
                              <span className="font-medium">{formatSupply(selectedToken.circulatingSupply, selectedToken.decimals)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Decimals:</span>
                              <span className="font-medium">{selectedToken.decimals.toString()}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Standard:</span>
                              <Badge variant="outline" className="bg-primary/10">ICRC-2</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Status:</span>
                              {selectedToken.mintFeePaid ? (
                                <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400">
                                  Deployed
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 dark:text-yellow-400">
                                  Pending
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold">Tax Configuration</h3>
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Buy Tax:</span>
                              <span className="font-medium">{Number(selectedToken.buyTax) / 100}%</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Sell Tax:</span>
                              <span className="font-medium">{Number(selectedToken.sellTax) / 100}%</span>
                            </div>
                            {Number(selectedToken.treasuryFee) > 0 && (
                              <div className="flex justify-between items-center">
                                <span className="text-muted-foreground">Treasury Fee:</span>
                                <span className="font-medium">{Number(selectedToken.treasuryFee) / 100}%</span>
                              </div>
                            )}
                            {selectedToken.moduleConfigs && selectedToken.moduleConfigs.length > 0 && (
                              <div className="pt-2">
                                <p className="text-sm text-muted-foreground mb-2">Active Modules:</p>
                                <div className="flex flex-wrap gap-2">
                                  {selectedToken.moduleConfigs.map((config, idx) => (
                                    <Badge key={idx} variant="secondary">
                                      {String(config.moduleType).replace('_', ' ')}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Creator Information</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between items-start">
                            <span className="text-muted-foreground">Creator Principal:</span>
                            <span className="font-mono text-sm text-right break-all max-w-md">
                              {selectedToken.creator?.toString() || 'N/A'}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Created On:</span>
                            <span className="font-medium">{formatDate(selectedToken.deployedAt)}</span>
                          </div>
                          <div className="flex justify-between items-start">
                            <span className="text-muted-foreground">Treasury Address:</span>
                            <span className="font-mono text-sm text-right break-all max-w-md">
                              {selectedToken.treasuryAddress?.toString() || 'N/A'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="chart" className="flex-1 overflow-hidden mt-0">
                  {renderDexscreenerWidget(selectedToken)}
                </TabsContent>
              </Tabs>
            </div>
          ) : (
            <div className="p-6">
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Invalid Token Data</AlertTitle>
                <AlertDescription>Unable to display token details. The token data is incomplete or corrupted.</AlertDescription>
              </Alert>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
