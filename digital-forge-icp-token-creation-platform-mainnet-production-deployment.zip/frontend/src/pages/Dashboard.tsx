import { useGetAllTokens, useGetUserActivityMetrics, useGetGlobalPlatformStats } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Skeleton } from '../components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '../components/ui/alert';
import { Coins, TrendingUp, Calendar, Hash, ArrowLeft, Plus, Wallet, Image as ImageIcon, AlertTriangle, Users, DollarSign, Activity, Flame } from 'lucide-react';

type View = 'home' | 'create' | 'dashboard' | 'forged' | 'lookup';

interface DashboardProps {
  onNavigate: (view: View) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { identity } = useInternetIdentity();
  const { data: tokens, isLoading: tokensLoading, isError: tokensError, error: tokensErrorMsg } = useGetAllTokens();
  const { data: userMetrics, isLoading: metricsLoading, isError: metricsError } = useGetUserActivityMetrics();
  const { data: globalStats, isLoading: statsLoading } = useGetGlobalPlatformStats();

  const isAuthenticated = !!identity;
  const isLoading = tokensLoading || metricsLoading || statsLoading;

  const formatDate = (timestamp: bigint) => {
    try {
      const date = new Date(Number(timestamp) / 1000000);
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    } catch (error) {
      console.error('Failed to format date:', error);
      return 'Invalid date';
    }
  };

  const formatSupply = (supply: bigint, decimals: bigint) => {
    try {
      const divisor = BigInt(10) ** decimals;
      const whole = supply / divisor;
      return whole.toLocaleString();
    } catch (error) {
      console.error('Failed to format supply:', error);
      return '0';
    }
  };

  const getMediaType = (url: string): 'image' | 'video' | 'audio' | 'unknown' => {
    if (!url) return 'unknown';
    const lower = url.toLowerCase();
    if (lower.match(/\.(png|jpg|jpeg|gif|webp)$/) || lower.startsWith('data:image/')) return 'image';
    if (lower.match(/\.(mp4|webm|mov)$/) || lower.startsWith('data:video/')) return 'video';
    if (lower.match(/\.(mp3|wav|ogg)$/) || lower.startsWith('data:audio/')) return 'audio';
    return 'unknown';
  };

  if (tokensError) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </div>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Failed to Load Dashboard</AlertTitle>
          <AlertDescription>
            {tokensErrorMsg instanceof Error ? tokensErrorMsg.message : 'An unexpected error occurred while loading your tokens.'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold mb-2 forge-text-gradient">Token Dashboard</h1>
            <p className="text-muted-foreground text-lg">Manage and monitor your forged tokens</p>
          </div>
          <Button 
            onClick={() => onNavigate('create')} 
            className="gap-2 forge-gradient border-0 hover:opacity-90 forge-glow"
          >
            <Flame className="h-4 w-4" />
            Forge New Token
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="border-2 border-primary/20">
                <CardHeader>
                  <Skeleton className="h-6 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* User-Specific Metrics */}
          {isAuthenticated && userMetrics && !metricsError && (
            <div className="mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-4 forge-text-gradient">Your Activity</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-blue-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(userMetrics.tokensMinted)}</CardTitle>
                      <Coins className="h-8 w-8 text-blue-500 opacity-50" />
                    </div>
                    <CardDescription>Tokens Forged</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-purple-500/10 via-magenta-500/10 to-purple-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(userMetrics.treasuryConfigurations)}</CardTitle>
                      <Wallet className="h-8 w-8 text-purple-500 opacity-50" />
                    </div>
                    <CardDescription>Treasury Configurations</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-cyan-500/10 via-blue-500/10 to-cyan-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(userMetrics.totalFeesPaid) / 1_000_000_000}</CardTitle>
                      <DollarSign className="h-8 w-8 text-cyan-500 opacity-50" />
                    </div>
                    <CardDescription>Total Fees Paid (ICP)</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-magenta-500/10 via-purple-500/10 to-magenta-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{userMetrics.deploymentHistory.length}</CardTitle>
                      <Activity className="h-8 w-8 text-magenta-500 opacity-50" />
                    </div>
                    <CardDescription>Deployments</CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          )}

          {/* Global Platform Statistics */}
          {globalStats && (
            <div className="mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-4 forge-text-gradient">Platform Statistics</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-violet-500/10 via-blue-500/10 to-violet-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(globalStats.totalTokensCreated)}</CardTitle>
                      <Flame className="h-8 w-8 text-violet-500 opacity-50" />
                    </div>
                    <CardDescription>Total Tokens Forged</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-magenta-500/10 via-cyan-500/10 to-magenta-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-2xl">{Number(globalStats.totalSupplyAcrossTokens).toLocaleString()}</CardTitle>
                      <TrendingUp className="h-8 w-8 text-magenta-500 opacity-50" />
                    </div>
                    <CardDescription>Total Supply Across Tokens</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-indigo-500/10 via-purple-500/10 to-indigo-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(globalStats.platformTreasuryFees) / 1_000_000_000}</CardTitle>
                      <Wallet className="h-8 w-8 text-indigo-500 opacity-50" />
                    </div>
                    <CardDescription>Platform Fees (ICP)</CardDescription>
                  </CardHeader>
                </Card>
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-cyan-500/10 via-blue-500/10 to-cyan-600/10 hover:scale-105 transition-transform">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-3xl">{Number(globalStats.totalUsers)}</CardTitle>
                      <Users className="h-8 w-8 text-cyan-500 opacity-50" />
                    </div>
                    <CardDescription>Total Users</CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          )}

          {/* User's Tokens */}
          {tokens && tokens.length > 0 ? (
            <>
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-4 forge-text-gradient">Your Forged Tokens</h2>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tokens.map((token) => {
                  if (!token || !token.symbol || !token.name) {
                    console.warn('Invalid token data:', token);
                    return null;
                  }

                  const mediaType = getMediaType(token.mediaUrl || '');
                  const hasMedia = token.mediaUrl && token.mediaUrl.trim() !== '';

                  return (
                    <Card key={token.symbol} className="border-2 border-primary/20 hover:border-primary/40 transition-all hover:scale-105 hover:shadow-xl bg-gradient-to-br from-primary/5 to-transparent">
                      {hasMedia && (
                        <div className="p-4">
                          <div className="w-32 h-32 mx-auto aspect-square overflow-hidden rounded-lg shadow-lg border-2 border-primary/30 forge-glow">
                            {mediaType === 'image' && (
                              <img 
                                src={token.mediaUrl} 
                                alt={token.name} 
                                className="w-full h-full object-cover" 
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                }}
                              />
                            )}
                            {mediaType === 'video' && (
                              <video 
                                src={token.mediaUrl} 
                                className="w-full h-full object-cover" 
                              />
                            )}
                            {(mediaType === 'audio' || mediaType === 'unknown') && (
                              <div className="w-full h-full bg-gradient-to-br from-primary/10 to-purple-500/10 flex items-center justify-center">
                                <ImageIcon className="h-8 w-8 text-muted-foreground opacity-50" />
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-xl">{token.name}</CardTitle>
                            <CardDescription className="text-lg font-mono">{token.symbol}</CardDescription>
                          </div>
                          <Badge variant="outline" className="bg-primary/10 border-primary/30">
                            ICRC-2
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {token.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{token.description}</p>
                        )}
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <Coins className="h-4 w-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Supply:</span>
                            <span className="font-medium">{formatSupply(token.totalSupply, token.decimals)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <TrendingUp className="h-4 w-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Taxes:</span>
                            <span className="font-medium">
                              {Number(token.buyTax) / 100}% / {Number(token.sellTax) / 100}%
                            </span>
                          </div>
                          {Number(token.treasuryFee) > 0 && (
                            <div className="flex items-center gap-2 text-sm">
                              <Wallet className="h-4 w-4 text-muted-foreground" />
                              <span className="text-muted-foreground">Treasury Fee:</span>
                              <span className="font-medium">{Number(token.treasuryFee) / 100}%</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Deployed:</span>
                            <span className="font-medium">{formatDate(token.deployedAt)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Hash className="h-4 w-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Decimals:</span>
                            <span className="font-medium">{token.decimals.toString()}</span>
                          </div>
                        </div>
                        <div className="pt-4 border-t border-primary/20">
                          <p className="text-xs text-muted-foreground truncate">
                            Canister: {token.canisterId?.toString() || 'N/A'}
                          </p>
                        </div>
                        {token.mintFeePaid && (
                          <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30">
                            Fee Paid
                          </Badge>
                        )}
                      </CardContent>
                    </Card>
                  );
                }).filter(Boolean)}
              </div>
            </>
          ) : (
            <Card className="border-2 border-primary/20 text-center py-16 bg-gradient-to-br from-primary/5 to-transparent">
              <CardContent>
                <img
                  src="/assets/generated/dashboard-analytics.dim_600x400.png"
                  alt="No tokens yet"
                  className="mx-auto mb-6 rounded-lg opacity-50"
                />
                <h3 className="text-2xl font-bold mb-2 forge-text-gradient">No Tokens Forged Yet</h3>
                <p className="text-muted-foreground mb-6">Create your first token to get started</p>
                <Button 
                  onClick={() => onNavigate('create')} 
                  className="gap-2 forge-gradient border-0 hover:opacity-90 forge-glow"
                >
                  <Flame className="h-4 w-4" />
                  Forge Your First Token
                </Button>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
