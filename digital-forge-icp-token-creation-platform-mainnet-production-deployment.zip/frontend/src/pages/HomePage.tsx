import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Coins, Shield, Zap, TrendingUp, Sparkles, ArrowRight, Flame } from 'lucide-react';

type View = 'home' | 'create' | 'dashboard';

interface HomePageProps {
  onNavigate: (view: View) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { identity, login } = useInternetIdentity();
  const isAuthenticated = !!identity;

  const features = [
    {
      icon: Zap,
      title: 'Instant Deployment',
      description: 'Deploy ICRC-2 compliant tokens in minutes with our streamlined wizard.',
      gradient: 'from-blue-500/10 via-cyan-500/10 to-blue-600/10',
      iconColor: 'text-blue-500',
    },
    {
      icon: Shield,
      title: 'Built-in Taxation',
      description: 'Configure buy and sell taxes with automatic distribution to your treasury.',
      gradient: 'from-purple-500/10 via-magenta-500/10 to-purple-600/10',
      iconColor: 'text-purple-500',
    },
    {
      icon: TrendingUp,
      title: 'Full Control',
      description: 'Manage token parameters, supply, and advanced features from your dashboard.',
      gradient: 'from-cyan-500/10 via-blue-500/10 to-cyan-600/10',
      iconColor: 'text-cyan-500',
    },
    {
      icon: Sparkles,
      title: 'ICP Native',
      description: 'Leverages Internet Computer for secure, decentralized token management.',
      gradient: 'from-magenta-500/10 via-purple-500/10 to-magenta-600/10',
      iconColor: 'text-magenta-500',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <section className="text-center mb-20 relative">
        <div className="absolute inset-0 forge-gradient opacity-5 blur-3xl -z-10" />
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex justify-center relative">
            <div className="absolute inset-0 forge-glow rounded-2xl -z-10" />
            <img
              src="/assets/generated/token-wizard-hero.dim_800x400.png"
              alt="Token Creation Wizard"
              className="rounded-2xl shadow-2xl border-2 border-primary/20 forge-pulse"
            />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 forge-text-gradient">
            Digital Forge
          </h1>
          <p className="text-2xl md:text-3xl font-semibold mb-4 bg-gradient-to-r from-blue-400 via-magenta-400 to-cyan-400 bg-clip-text text-transparent">
            Create Custom Tokens on ICP
          </p>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Launch your own ICRC-2 compliant tokens with built-in taxation features. No coding required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <>
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('create')} 
                  className="gap-2 text-lg px-8 forge-gradient border-0 hover:opacity-90 transition-opacity forge-glow"
                >
                  <Flame className="h-5 w-5" />
                  Forge Token
                  <ArrowRight className="h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  onClick={() => onNavigate('dashboard')} 
                  className="text-lg px-8 border-2 border-primary/30 hover:border-primary/50 hover:bg-primary/5"
                >
                  View Dashboard
                </Button>
              </>
            ) : (
              <Button 
                size="lg" 
                onClick={login} 
                className="gap-2 text-lg px-8 forge-gradient border-0 hover:opacity-90 transition-opacity forge-glow"
              >
                <Coins className="h-5 w-5" />
                Connect to Start
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="mb-20">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 forge-text-gradient">
          Why Choose Digital Forge?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className={`border-2 border-primary/20 bg-gradient-to-br ${feature.gradient} backdrop-blur hover:border-primary/40 transition-all hover:scale-105 hover:shadow-xl`}
            >
              <CardHeader>
                <div className={`h-12 w-12 rounded-lg bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 border-2 border-primary/20`}>
                  <feature.icon className={`h-6 w-6 ${feature.iconColor}`} />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="mb-20">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 forge-text-gradient">
          How It Works
        </h2>
        <div className="max-w-3xl mx-auto space-y-6">
          {[
            { step: 1, title: 'Connect Wallet', description: 'Authenticate with Internet Identity', color: 'from-blue-500 to-cyan-500' },
            { step: 2, title: 'Configure Token', description: 'Set name, symbol, supply, and tax parameters', color: 'from-purple-500 to-magenta-500' },
            { step: 3, title: 'Pay Minting Fee', description: 'One-time fee of 1 ICP to deploy your token', color: 'from-cyan-500 to-blue-500' },
            { step: 4, title: 'Deploy & Manage', description: 'Your token is live on the Internet Computer', color: 'from-magenta-500 to-purple-500' },
          ].map((item) => (
            <div key={item.step} className="flex gap-6 items-start group hover:scale-105 transition-transform">
              <div className={`shrink-0 h-12 w-12 rounded-full bg-gradient-to-br ${item.color} flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:shadow-xl transition-shadow`}>
                {item.step}
              </div>
              <div className="flex-1 pt-2">
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center py-16 px-4 rounded-2xl bg-gradient-to-br from-blue-500/10 via-magenta-500/10 to-cyan-500/10 border-2 border-primary/20 relative overflow-hidden">
        <div className="absolute inset-0 forge-gradient opacity-10 molten-flow" />
        <div className="relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 forge-text-gradient">
            Ready to Launch Your Token?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg">
            Join the future of decentralized finance on the Internet Computer
          </p>
          {isAuthenticated ? (
            <Button 
              size="lg" 
              onClick={() => onNavigate('create')} 
              className="gap-2 text-lg px-8 forge-gradient border-0 hover:opacity-90 transition-opacity forge-glow"
            >
              <Flame className="h-5 w-5" />
              Start Forging
              <ArrowRight className="h-5 w-5" />
            </Button>
          ) : (
            <Button 
              size="lg" 
              onClick={login} 
              className="gap-2 text-lg px-8 forge-gradient border-0 hover:opacity-90 transition-opacity forge-glow"
            >
              <Coins className="h-5 w-5" />
              Connect Wallet
            </Button>
          )}
        </div>
      </section>
    </div>
  );
}
