import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, TokenMetadata, TokenConfig, UserActivityMetrics, GlobalPlatformStats } from '../backend';
import { toast } from 'sonner';

// Helper function to extract error message from backend responses
function extractErrorMessage(error: any): string {
  if (!error) return 'An unknown error occurred';
  
  // Handle string errors
  if (typeof error === 'string') return error;
  
  // Handle Error objects
  if (error instanceof Error) return error.message;
  
  // Handle backend trap messages
  if (error.message && typeof error.message === 'string') {
    // Clean up "Reject text:" prefix from IC errors
    const message = error.message.replace(/^Reject text:\s*/i, '');
    return message;
  }
  
  // Handle structured error objects
  if (error.error && typeof error.error === 'string') return error.error;
  if (error.description && typeof error.description === 'string') return error.description;
  
  return 'An unexpected error occurred';
}

// Helper function to check if error is a variant response
function isVariantError(result: any): result is { __kind__: 'error'; error: { message: string } } {
  return result && typeof result === 'object' && '__kind__' in result && result.__kind__ === 'error';
}

// Helper function to check if result is a variant success
function isVariantSuccess<T>(result: any): result is { __kind__: 'success'; success: T } {
  return result && typeof result === 'object' && '__kind__' in result && result.__kind__ === 'success';
}

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      try {
        const result = await actor.getCallerUserProfile();
        return result ?? null;
      } catch (error: any) {
        // Don't log errors for anonymous users - this is expected
        const errorMessage = extractErrorMessage(error);
        if (!errorMessage.includes('Anonymous')) {
          console.error('Failed to fetch user profile:', errorMessage);
        }
        return null;
      }
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      
      // Validate profile data before sending to backend
      if (!profile.name || profile.name.trim().length === 0) {
        throw new Error('Profile name cannot be empty');
      }
      if (profile.name.trim().length > 100) {
        throw new Error('Profile name too long (max 100 characters)');
      }
      
      try {
        await actor.saveCallerUserProfile(profile);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Save profile error:', errorMessage);
        throw new Error(errorMessage);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
    onError: (error: any) => {
      const errorMessage = extractErrorMessage(error);
      toast.error('Failed to save profile', {
        description: errorMessage,
      });
    },
  });
}

export function useGetAllTokens() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<TokenMetadata[]>({
    queryKey: ['allTokens'],
    queryFn: async () => {
      if (!actor) return [];
      try {
        const result = await actor.getAllTokens();
        if (!result || !Array.isArray(result)) {
          console.warn('getAllTokens returned invalid data:', result);
          return [];
        }
        return result.filter((token): token is TokenMetadata => token != null);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Failed to fetch all tokens:', errorMessage);
        toast.error('Failed to load tokens', {
          description: errorMessage,
        });
        return [];
      }
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetForgedTokens() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<TokenMetadata[]>({
    queryKey: ['forgedTokens'],
    queryFn: async () => {
      if (!actor) return [];
      try {
        const result = await actor.getForgedTokens();
        if (!result || !Array.isArray(result)) {
          console.warn('getForgedTokens returned invalid data:', result);
          return [];
        }
        return result.filter((token): token is TokenMetadata => {
          if (!token) return false;
          return !!(token.symbol && token.name && token.creator);
        });
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Failed to fetch forged tokens:', errorMessage);
        return [];
      }
    },
    enabled: !!actor && !actorFetching,
    refetchInterval: 30000,
  });
}

export function useGetToken(symbol: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<TokenMetadata | null>({
    queryKey: ['token', symbol],
    queryFn: async () => {
      if (!actor) return null;
      try {
        const result = await actor.getToken(symbol);
        if (!result) {
          console.warn(`Token ${symbol} not found or returned null`);
          return null;
        }
        if (!result.symbol || !result.name || !result.creator) {
          console.warn(`Token ${symbol} has invalid structure:`, result);
          return null;
        }
        return result;
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error(`❌ Failed to fetch token ${symbol}:`, errorMessage);
        return null;
      }
    },
    enabled: !!actor && !actorFetching && !!symbol,
  });
}

export function useLookupToken(canisterId: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<TokenMetadata | null>({
    queryKey: ['lookupToken', canisterId],
    queryFn: async () => {
      if (!actor) return null;
      try {
        const result = await actor.lookupToken(canisterId);
        if (!result) {
          return null;
        }
        if (!result.symbol || !result.name || !result.creator) {
          console.warn(`Token lookup ${canisterId} has invalid structure:`, result);
          return null;
        }
        return result;
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error(`❌ Failed to lookup token ${canisterId}:`, errorMessage);
        return null;
      }
    },
    enabled: !!actor && !actorFetching && !!canisterId,
  });
}

export function useGetUserActivityMetrics() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<UserActivityMetrics>({
    queryKey: ['userActivityMetrics'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      try {
        const result = await actor.getUserActivityMetrics();
        return result;
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Failed to fetch user activity metrics:', errorMessage);
        throw new Error(errorMessage);
      }
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetGlobalPlatformStats() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<GlobalPlatformStats>({
    queryKey: ['globalPlatformStats'],
    queryFn: async () => {
      if (!actor) {
        return {
          totalTokensCreated: BigInt(0),
          totalSupplyAcrossTokens: BigInt(0),
          platformTreasuryFees: BigInt(0),
          totalUsers: BigInt(0),
        };
      }
      try {
        const result = await actor.getGlobalPlatformStats();
        return result;
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Failed to fetch global platform stats:', errorMessage);
        return {
          totalTokensCreated: BigInt(0),
          totalSupplyAcrossTokens: BigInt(0),
          platformTreasuryFees: BigInt(0),
          totalUsers: BigInt(0),
        };
      }
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useRegisterToken() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (metadata: TokenMetadata) => {
      if (!actor) throw new Error('Actor not available');
      try {
        await actor.registerToken(metadata);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Register token error:', errorMessage);
        throw new Error(errorMessage);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allTokens'] });
      queryClient.invalidateQueries({ queryKey: ['forgedTokens'] });
      queryClient.invalidateQueries({ queryKey: ['globalPlatformStats'] });
      toast.success('Token registered successfully');
    },
    onError: (error: any) => {
      const errorMessage = extractErrorMessage(error);
      toast.error('Failed to register token', {
        description: errorMessage,
      });
    },
  });
}

export function useCreateToken() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (config: TokenConfig) => {
      if (!actor) {
        const error = 'Actor not available - please refresh the page';
        console.error('❌ Create token error:', error);
        throw new Error(error);
      }
      
      try {
        console.log('🔨 Calling backend createToken with config:', {
          symbol: config.symbol,
          name: config.name,
          paymentId: config.paymentId,
        });

        const result = await actor.createToken(config);
        
        console.log('📦 Backend createToken response:', result);
        
        // Handle discriminated union response
        if (isVariantError(result)) {
          const errorMsg = result.error.message;
          console.error('❌ Backend returned error variant:', errorMsg);
          throw new Error(errorMsg);
        }
        
        if (isVariantSuccess(result)) {
          console.log('✅ Backend returned success variant:', result.success.message);
          return result;
        }
        
        // Fallback for unexpected response format
        const fallbackError = 'Unexpected response format from backend';
        console.error('⚠️ Unexpected response format from backend:', result);
        throw new Error(fallbackError);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('💥 Create token error caught:', {
          originalError: error,
          extractedMessage: errorMessage,
        });
        throw new Error(errorMessage);
      }
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['allTokens'] });
      queryClient.invalidateQueries({ queryKey: ['forgedTokens'] });
      queryClient.invalidateQueries({ queryKey: ['userActivityMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['globalPlatformStats'] });
      
      if (isVariantSuccess(result)) {
        toast.success('✅ Token Created Successfully', {
          description: result.success.message,
          duration: 5000,
        });
      }
    },
    onError: (error: any) => {
      const errorMessage = extractErrorMessage(error);
      console.error('🚨 Token creation mutation error:', errorMessage);
      
      // Show toast notification for all errors
      toast.error('Token creation failed', {
        description: errorMessage,
        duration: 7000,
      });
    },
  });
}

export function useRecordPayment() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({ amount, treasuryAddress }: { amount: bigint; treasuryAddress: string }): Promise<bigint> => {
      if (!actor) {
        const error = 'Actor not available - please refresh the page';
        console.error('❌ Record payment error:', error);
        throw new Error(error);
      }
      
      try {
        console.log('💰 Recording payment:', { amount: amount.toString(), treasuryAddress });
        
        const result = await actor.recordPayment(amount, treasuryAddress);
        
        console.log('📝 Payment record response:', result);
        
        // Handle discriminated union response
        if (isVariantError(result)) {
          const errorMsg = result.error.message;
          console.error('❌ Payment recording failed:', errorMsg);
          throw new Error(errorMsg);
        }
        
        if (isVariantSuccess<{ paymentId: bigint; message: string }>(result)) {
          console.log('✅ Payment recorded successfully:', {
            paymentId: result.success.paymentId.toString(),
            message: result.success.message,
          });
          
          toast.success('Payment recorded', {
            description: result.success.message,
          });
          
          return result.success.paymentId;
        }
        
        const fallbackError = 'Unexpected response format from backend';
        console.error('⚠️ Unexpected payment response:', result);
        throw new Error(fallbackError);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('💥 Record payment error:', errorMessage);
        throw new Error(errorMessage);
      }
    },
    onError: (error: any) => {
      const errorMessage = extractErrorMessage(error);
      console.error('🚨 Payment recording mutation error:', errorMessage);
      
      // Show toast notification for payment errors
      toast.error('Payment recording failed', {
        description: errorMessage,
        duration: 7000,
      });
    },
  });
}

export function useVerifyPayment() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ transactionId, paymentId }: { transactionId: string; paymentId: bigint }): Promise<void> => {
      if (!actor) {
        const error = 'Actor not available - please refresh the page';
        console.error('❌ Verify payment error:', error);
        throw new Error(error);
      }
      
      try {
        console.log('🔍 Verifying payment:', { transactionId, paymentId: paymentId.toString() });
        
        const result = await actor.verifyPaymentWithLedger(transactionId, paymentId);
        
        console.log('✅ Payment verification response:', result);
        
        // Handle discriminated union response
        if (isVariantError(result)) {
          const errorMsg = result.error.message;
          console.error('❌ Payment verification failed:', errorMsg);
          throw new Error(errorMsg);
        }
        
        if (isVariantSuccess<{ message: string }>(result)) {
          console.log('✅ Payment verified successfully:', result.success.message);
          
          toast.success('Payment verified', {
            description: result.success.message,
          });
          
          return;
        }
        
        const fallbackError = 'Unexpected response format from backend';
        console.error('⚠️ Unexpected verification response:', result);
        throw new Error(fallbackError);
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('💥 Verify payment error:', errorMessage);
        throw new Error(errorMessage);
      }
    },
    onSuccess: () => {
      // Invalidate relevant queries after successful verification
      queryClient.invalidateQueries({ queryKey: ['userActivityMetrics'] });
    },
    onError: (error: any) => {
      const errorMessage = extractErrorMessage(error);
      console.error('🚨 Payment verification mutation error:', errorMessage);
      
      // Show toast notification for verification errors
      toast.error('Payment verification failed', {
        description: errorMessage,
        duration: 7000,
      });
    },
  });
}

export function useGetBuyMeACoffeeAddress() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<string>({
    queryKey: ['buyMeACoffeeAddress'],
    queryFn: async () => {
      if (!actor) return 'ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936';
      try {
        const result = await actor.getBuyMeACoffeeAddress();
        return result || 'ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936';
      } catch (error: any) {
        const errorMessage = extractErrorMessage(error);
        console.error('❌ Failed to fetch coffee address:', errorMessage);
        return 'ab6f9d02f1930037c53b781620754e804b140732f0990cc252fc604915303936';
      }
    },
    enabled: !!actor && !actorFetching,
  });
}
