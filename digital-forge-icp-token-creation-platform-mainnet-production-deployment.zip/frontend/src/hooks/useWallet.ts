import { useState, useEffect, useCallback, useRef } from 'react';
import { Principal } from '@icp-sdk/core/principal';
import { toast } from 'sonner';

export interface WalletState {
  connected: boolean;
  connecting: boolean;
  address: string | null;
  principal: Principal | null;
  walletType: 'plug' | null;
  detecting: boolean;
  detected: boolean;
  waitingForConfirmation: boolean;
}

export interface TransferParams {
  to: string;
  amount: bigint;
  memo?: bigint;
}

export interface TransferResult {
  success: boolean;
  blockHeight?: bigint;
  error?: string;
}

declare global {
  interface Window {
    ic?: {
      plug?: {
        isConnected: () => Promise<boolean>;
        requestConnect: (params?: { whitelist?: string[]; host?: string }) => Promise<boolean>;
        disconnect: () => Promise<void>;
        getPrincipal: () => Promise<Principal>;
        requestBalance: () => Promise<Array<{ amount: number; canisterId: string; decimals: number; name: string; symbol: string }>>;
        requestTransfer: (params: {
          to: string;
          amount: number;
          opts?: { fee?: number; memo?: bigint; from_subaccount?: number; created_at_time?: bigint };
        }) => Promise<{ height: bigint }>;
        sessionManager?: {
          sessionData?: any;
        };
        agent: any;
      };
    };
    plug?: {
      isConnected: () => Promise<boolean>;
      requestConnect: (params?: { whitelist?: string[]; host?: string }) => Promise<boolean>;
      disconnect: () => Promise<void>;
      getPrincipal: () => Promise<Principal>;
      requestBalance: () => Promise<Array<{ amount: number; canisterId: string; decimals: number; name: string; symbol: string }>>;
      requestTransfer: (params: {
        to: string;
        amount: number;
        opts?: { fee?: number; memo?: bigint; from_subaccount?: number; created_at_time?: bigint };
      }) => Promise<{ height: bigint }>;
      sessionManager?: {
        sessionData?: any;
      };
      agent: any;
    };
    __plugWalletState?: {
      detected: boolean;
      detectionStartTime: number;
      detectionAttempts: number;
      intervalId: number | null;
    };
  }
}

const ICP_LEDGER_CANISTER_ID = 'ryjl3-tyaaa-aaaaa-aaaba-cai';
const DEFAULT_HOST = 'https://icp0.io';
const SESSION_STORAGE_KEY = 'plug_wallet_connected';
const LAST_PRINCIPAL_KEY = 'plug_wallet_last_principal';
const CONNECTION_TIMEOUT = 30000; // 30 seconds
const DETECTION_TIMEOUT = 30000; // 30 seconds for detection

export function useWallet() {
  const [walletState, setWalletState] = useState<WalletState>({
    connected: false,
    connecting: false,
    address: null,
    principal: null,
    walletType: null,
    detecting: true,
    detected: false,
    waitingForConfirmation: false,
  });

  const hasAttemptedAutoReconnect = useRef(false);
  const mountedRef = useRef(true);
  const detectionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const connectionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pendingTransferRef = useRef<{
    resolve: (result: TransferResult) => void;
    reject: (error: any) => void;
  } | null>(null);

  const logDebug = useCallback((message: string, data?: any) => {
    console.log(`[Plug Wallet] ${message}`, data || '');
  }, []);

  // Safe Plug detection with Brave browser compatibility
  const getPlugInstance = useCallback(() => {
    try {
      if (window.ic?.plug) {
        return window.ic.plug;
      }
    } catch (error) {
      // Brave may block access, continue to fallback
    }

    try {
      if (window.plug) {
        return window.plug;
      }
    } catch (error) {
      // Silently handle errors
    }

    return null;
  }, []);

  const hasExistingSession = useCallback((): boolean => {
    const plug = getPlugInstance();
    if (!plug) return false;
    
    try {
      if (plug.sessionManager?.sessionData) {
        logDebug('Session found in sessionManager');
        return true;
      }
    } catch (error) {
      // Ignore errors
    }
    
    const cachedConnection = sessionStorage.getItem(SESSION_STORAGE_KEY);
    const lastPrincipal = localStorage.getItem(LAST_PRINCIPAL_KEY);
    
    if (cachedConnection === 'true' || lastPrincipal) {
      logDebug('Session found in storage', { cachedConnection, lastPrincipal: !!lastPrincipal });
      return true;
    }
    
    return false;
  }, [getPlugInstance, logDebug]);

  const saveConnectionState = useCallback((connected: boolean, principal?: Principal) => {
    if (connected) {
      sessionStorage.setItem(SESSION_STORAGE_KEY, 'true');
      if (principal) {
        localStorage.setItem(LAST_PRINCIPAL_KEY, principal.toString());
        logDebug('Connection state saved', { principal: principal.toString() });
      }
    } else {
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      localStorage.removeItem(LAST_PRINCIPAL_KEY);
      logDebug('Connection state cleared');
    }
  }, [logDebug]);

  // Immediate detection on mount
  const detectPlugWallet = useCallback((): boolean => {
    // Check global state first
    if (typeof window !== 'undefined' && window.__plugWalletState?.detected) {
      return true;
    }

    // Direct detection
    const plug = getPlugInstance();
    return !!plug;
  }, [getPlugInstance]);

  // Auto-revalidate wallet session before operations
  const revalidateSession = useCallback(async (): Promise<boolean> => {
    logDebug('🔄 Revalidating wallet session...');
    
    try {
      const plug = getPlugInstance();
      if (!plug) {
        logDebug('❌ Revalidation failed: Plug not available');
        return false;
      }

      const isConnected = await plug.isConnected();
      logDebug('Revalidation check', { isConnected });
      
      if (isConnected) {
        const principal = await plug.getPrincipal();
        const address = principal.toString();

        setWalletState((prev) => ({
          ...prev,
          connected: true,
          address,
          principal,
          walletType: 'plug',
        }));

        saveConnectionState(true, principal);
        
        logDebug('✅ Session revalidated successfully', { address });
        return true;
      } else {
        logDebug('⚠️ Session not active, reconnection required');
        setWalletState((prev) => ({
          ...prev,
          connected: false,
          address: null,
          principal: null,
          walletType: null,
        }));
        saveConnectionState(false);
        return false;
      }
    } catch (error: any) {
      logDebug('❌ Revalidation error', error);
      setWalletState((prev) => ({
        ...prev,
        connected: false,
        address: null,
        principal: null,
        walletType: null,
      }));
      saveConnectionState(false);
      return false;
    }
  }, [getPlugInstance, saveConnectionState, logDebug]);

  const autoReconnect = useCallback(async () => {
    logDebug('Attempting auto-reconnect...');
    
    try {
      const plug = getPlugInstance();
      if (!plug) {
        logDebug('Auto-reconnect failed: Plug not available');
        return false;
      }

      if (!hasExistingSession()) {
        logDebug('Auto-reconnect skipped: No existing session');
        return false;
      }

      const isConnected = await plug.isConnected();
      logDebug('Plug connection status', { isConnected });
      
      if (isConnected) {
        const principal = await plug.getPrincipal();
        const address = principal.toString();

        setWalletState({
          connected: true,
          connecting: false,
          address,
          principal,
          walletType: 'plug',
          detecting: false,
          detected: true,
          waitingForConfirmation: false,
        });

        saveConnectionState(true, principal);
        
        logDebug('✅ Auto-reconnect successful', { address });
        
        toast.success('Wallet automatically reconnected!', {
          description: 'Your previous session has been restored.',
        });
        return true;
      } else {
        // Try to reconnect if we have a previous session
        const lastPrincipal = localStorage.getItem(LAST_PRINCIPAL_KEY);
        if (lastPrincipal) {
          logDebug('Attempting to restore session with requestConnect', { lastPrincipal });
          
          const whitelist = [ICP_LEDGER_CANISTER_ID];
          const host = DEFAULT_HOST;
          
          const connected = await plug.requestConnect({ whitelist, host });
          
          if (connected) {
            const principal = await plug.getPrincipal();
            const address = principal.toString();

            setWalletState({
              connected: true,
              connecting: false,
              address,
              principal,
              walletType: 'plug',
              detecting: false,
              detected: true,
              waitingForConfirmation: false,
            });

            saveConnectionState(true, principal);
            
            logDebug('✅ Session restored via requestConnect', { address });
            
            toast.success('Wallet session restored!', {
              description: 'Your wallet has been reconnected.',
            });
            return true;
          }
        }
      }
      
      logDebug('Auto-reconnect: No active session to restore');
      return false;
    } catch (error: any) {
      logDebug('Auto-reconnect error', error);
      saveConnectionState(false);
      return false;
    }
  }, [getPlugInstance, hasExistingSession, saveConnectionState, logDebug]);

  const reconnectWallet = useCallback(async () => {
    logDebug('Manual reconnect triggered');
    
    try {
      const plug = getPlugInstance();
      if (!plug) {
        toast.error('Plug wallet not accessible', {
          description: 'Please refresh the page and try again.',
        });
        return false;
      }

      const isConnected = await plug.isConnected();
      logDebug('Reconnect: Current connection status', { isConnected });
      
      if (isConnected) {
        const principal = await plug.getPrincipal();
        const address = principal.toString();

        setWalletState({
          connected: true,
          connecting: false,
          address,
          principal,
          walletType: 'plug',
          detecting: false,
          detected: true,
          waitingForConfirmation: false,
        });

        saveConnectionState(true, principal);
        
        logDebug('✅ Reconnect successful', { address });
        
        toast.success('Wallet reconnected successfully!');
        return true;
      } else {
        toast.info('No existing session found', {
          description: 'Please connect your wallet using the Connect Wallet button.',
        });
        return false;
      }
    } catch (error: any) {
      logDebug('Reconnect error', error);
      toast.error('Failed to reconnect wallet', {
        description: 'Please try connecting manually.',
      });
      return false;
    }
  }, [getPlugInstance, saveConnectionState, logDebug]);

  const connectPlug = useCallback(async () => {
    logDebug('Connect Plug initiated');
    setWalletState((prev) => ({ ...prev, connecting: true }));

    // Clear any existing timeout
    if (connectionTimeoutRef.current) {
      clearTimeout(connectionTimeoutRef.current);
    }

    try {
      const plug = getPlugInstance();
      if (!plug) {
        toast.error('Plug wallet not detected', {
          description: 'Please install the Plug browser extension and refresh the page.',
          action: {
            label: 'Install Plug',
            onClick: () => window.open('https://plugwallet.ooo/', '_blank'),
          },
        });
        setWalletState((prev) => ({ ...prev, connecting: false }));
        return false;
      }

      // Set connection timeout (30 seconds)
      const timeoutPromise = new Promise<never>((_, reject) => {
        connectionTimeoutRef.current = setTimeout(() => {
          reject(new Error('Connection timeout - please try again'));
        }, CONNECTION_TIMEOUT);
      });

      const alreadyConnected = await plug.isConnected();
      logDebug('Connect: Already connected check', { alreadyConnected });
      
      if (alreadyConnected) {
        const principal = await plug.getPrincipal();
        const address = principal.toString();

        setWalletState({
          connected: true,
          connecting: false,
          address,
          principal,
          walletType: 'plug',
          detecting: false,
          detected: true,
          waitingForConfirmation: false,
        });

        saveConnectionState(true, principal);
        
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
        }
        
        logDebug('✅ Connected (already connected)', { address });
        
        toast.success('Wallet connected successfully!');
        return true;
      }

      const whitelist = [ICP_LEDGER_CANISTER_ID];
      const host = DEFAULT_HOST;

      logDebug('Requesting connection...', { whitelist, host });

      // Race between connection and timeout
      const connected = await Promise.race([
        plug.requestConnect({ whitelist, host }),
        timeoutPromise,
      ]);

      if (connectionTimeoutRef.current) {
        clearTimeout(connectionTimeoutRef.current);
      }

      if (connected) {
        const principal = await plug.getPrincipal();
        const address = principal.toString();

        setWalletState({
          connected: true,
          connecting: false,
          address,
          principal,
          walletType: 'plug',
          detecting: false,
          detected: true,
          waitingForConfirmation: false,
        });

        saveConnectionState(true, principal);
        
        logDebug('✅ Connection successful', { address });
        
        toast.success('Wallet connected successfully!');
        return true;
      } else {
        setWalletState((prev) => ({ ...prev, connecting: false }));
        
        logDebug('Connection rejected by user');
        
        toast.error('Connection rejected', {
          description: 'Please approve the connection in your Plug wallet.',
        });
        return false;
      }
    } catch (error: any) {
      logDebug('Connection error', error);
      
      if (connectionTimeoutRef.current) {
        clearTimeout(connectionTimeoutRef.current);
      }
      
      setWalletState((prev) => ({ ...prev, connecting: false }));
      
      let errorMessage = 'Failed to connect wallet';
      let errorDescription = 'Please try again or refresh the page.';
      
      if (error?.message?.includes('timeout')) {
        errorMessage = 'Connection timeout';
        errorDescription = 'The connection request took too long. Please try again.';
      } else if (error?.message?.includes('locked')) {
        errorMessage = 'Wallet is locked';
        errorDescription = 'Please unlock your Plug wallet and try again.';
      } else if (error?.message?.includes('rejected') || error?.message?.includes('denied')) {
        errorMessage = 'Connection rejected';
        errorDescription = 'You rejected the connection request. Your form data is preserved - click Connect Wallet to try again.';
      }
      
      toast.error(errorMessage, { description: errorDescription });
      return false;
    }
  }, [getPlugInstance, saveConnectionState, logDebug]);

  const disconnect = useCallback(async () => {
    logDebug('Disconnect initiated');
    
    try {
      const plug = getPlugInstance();
      if (walletState.walletType === 'plug' && plug) {
        await plug.disconnect();
      }

      setWalletState({
        connected: false,
        connecting: false,
        address: null,
        principal: null,
        walletType: null,
        detecting: false,
        detected: walletState.detected,
        waitingForConfirmation: false,
      });

      saveConnectionState(false);
      
      logDebug('✅ Disconnected successfully');
      
      toast.success('Wallet disconnected');
    } catch (error: any) {
      logDebug('Disconnect error', error);
      toast.error('Failed to disconnect wallet');
    }
  }, [walletState.walletType, walletState.detected, getPlugInstance, saveConnectionState, logDebug]);

  const transferICP = useCallback(
    async (params: TransferParams): Promise<TransferResult> => {
      if (!walletState.connected || !walletState.walletType) {
        toast.error('Wallet not connected', {
          description: 'Please connect your wallet first. Your form data is preserved.',
        });
        return { success: false, error: 'Wallet not connected' };
      }

      // AUTO-REVALIDATE SESSION BEFORE SIGNING
      logDebug('🔄 Auto-revalidating session before transfer...');
      const sessionValid = await revalidateSession();
      
      if (!sessionValid) {
        toast.error('Wallet session expired', {
          description: 'Please reconnect your wallet and try again. Your form data is preserved.',
        });
        return { success: false, error: 'Session expired - reconnection required' };
      }

      const plug = getPlugInstance();
      if (!plug) {
        toast.error('Wallet not accessible', {
          description: 'Please reconnect your wallet. Your form data is preserved.',
        });
        return { success: false, error: 'Wallet not accessible' };
      }

      // Set waiting state for UI overlay
      setWalletState((prev) => ({ ...prev, waitingForConfirmation: true }));

      try {
        const amountNumber = Number(params.amount);

        logDebug('Initiating transfer with persistent promise handler', { to: params.to, amount: amountNumber });

        // Create persistent promise that waits indefinitely for user confirmation
        const transferPromise = new Promise<{ height: bigint }>((resolve, reject) => {
          // Store promise handlers for potential cleanup
          pendingTransferRef.current = {
            resolve: (result: TransferResult) => {
              if (result.success && result.blockHeight) {
                resolve({ height: result.blockHeight });
              } else {
                reject(new Error(result.error || 'Transfer failed'));
              }
            },
            reject,
          };

          // Call Plug requestTransfer WITHOUT any timeout
          // This allows the popup to stay open until user confirms or cancels
          plug.requestTransfer({
            to: params.to,
            amount: amountNumber,
            opts: {
              fee: 10000,
              memo: params.memo,
            },
          })
            .then((result) => {
              logDebug('✅ Transfer promise resolved', { result });
              resolve(result);
            })
            .catch((error) => {
              logDebug('❌ Transfer promise rejected', { error });
              reject(error);
            })
            .finally(() => {
              // Clear pending reference
              pendingTransferRef.current = null;
            });
        });

        // Show persistent notification
        toast.info('Waiting for Wallet Confirmation…', {
          description: 'Please review and approve the 1 ICP payment in your Plug wallet popup. The request will remain active until you confirm or cancel.',
          duration: Infinity, // Keep toast visible until resolved
          id: 'wallet-confirmation',
        });

        // Await the transfer WITHOUT any timeout - waits indefinitely
        const result = await transferPromise;

        // Dismiss the waiting toast
        toast.dismiss('wallet-confirmation');

        if (!result.height || result.height <= 0n) {
          throw new Error('Transaction not confirmed - no block height returned');
        }

        logDebug('✅ Transfer successful', { blockHeight: result.height });

        setWalletState((prev) => ({ ...prev, waitingForConfirmation: false }));

        toast.success('✅ Payment confirmed on-chain!', {
          description: `Transaction completed at block ${result.height}`,
        });

        return {
          success: true,
          blockHeight: result.height,
        };
      } catch (error: any) {
        logDebug('Transfer error', error);
        
        // Dismiss the waiting toast
        toast.dismiss('wallet-confirmation');
        
        setWalletState((prev) => ({ ...prev, waitingForConfirmation: false }));
        
        let errorMessage = 'Transfer failed';
        let errorDescription = 'Your form data is preserved. Please try again.';
        
        if (error?.message?.includes('locked')) {
          errorMessage = 'Wallet is locked';
          errorDescription = 'Please unlock your Plug wallet and try again. Your form data is preserved.';
        } else if (error?.message?.includes('rejected') || error?.message?.includes('denied') || error?.message?.includes('User rejected')) {
          errorMessage = 'Transaction rejected';
          errorDescription = 'You rejected the transaction. Your form data is preserved - click "Confirm Payment & Deploy" when ready.';
        } else if (error?.message?.includes('Insufficient') || error?.message?.includes('insufficient')) {
          errorMessage = 'Insufficient balance';
          errorDescription = 'Please add ICP to your wallet and try again. Your form data is preserved.';
        } else if (error?.message) {
          errorDescription = `${error.message}. Your form data is preserved.`;
        }
        
        toast.error(errorMessage, { description: errorDescription });
        return { success: false, error: errorMessage };
      }
    },
    [walletState.connected, walletState.walletType, getPlugInstance, revalidateSession, logDebug]
  );

  const getBalance = useCallback(async (): Promise<bigint | null> => {
    if (!walletState.connected || !walletState.walletType) {
      return null;
    }

    const plug = getPlugInstance();
    if (!plug) return null;

    try {
      const balances = await plug.requestBalance();
      const icpBalance = balances.find((b) => b.symbol === 'ICP');
      if (icpBalance) {
        return BigInt(Math.floor(icpBalance.amount * 100000000));
      }

      return null;
    } catch (error: any) {
      logDebug('Balance fetch error', error);
      return null;
    }
  }, [walletState.connected, walletState.walletType, getPlugInstance, logDebug]);

  const isPlugInstalled = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined') return false;
    return detectPlugWallet();
  }, [detectPlugWallet]);

  // Initialize detection on mount with timeout
  useEffect(() => {
    mountedRef.current = true;
    logDebug('🚀 Wallet hook mounted - starting detection');

    // Immediate detection check
    const isDetected = detectPlugWallet();
    
    if (isDetected) {
      logDebug('✅ Plug detected immediately');
      setWalletState((prev) => ({
        ...prev,
        detected: true,
        detecting: false,
      }));
      
      toast.success('Plug wallet detected!', {
        description: 'Your wallet is ready to connect.',
      });
    } else {
      logDebug('⏳ Plug not detected, starting detection interval...');
      
      // Set detection timeout (30 seconds)
      detectionTimeoutRef.current = setTimeout(() => {
        if (!mountedRef.current) return;
        
        const finalCheck = detectPlugWallet();
        
        if (!finalCheck) {
          logDebug('❌ Detection timeout - Plug not found after 30 seconds');
          setWalletState((prev) => ({
            ...prev,
            detected: false,
            detecting: false,
          }));
          
          toast.error('Plug wallet not detected', {
            description: 'Please install the Plug browser extension.',
            action: {
              label: 'Install Plug',
              onClick: () => window.open('https://plugwallet.ooo/', '_blank'),
            },
          });
        }
      }, DETECTION_TIMEOUT);

      // Poll for detection every 300ms
      const detectionInterval = setInterval(() => {
        if (!mountedRef.current) return;

        const detected = detectPlugWallet();
        
        if (detected) {
          logDebug('✅ Plug detected during polling');
          
          if (detectionTimeoutRef.current) {
            clearTimeout(detectionTimeoutRef.current);
          }
          clearInterval(detectionInterval);
          
          setWalletState((prev) => ({
            ...prev,
            detected: true,
            detecting: false,
          }));
          
          toast.success('Plug wallet detected!', {
            description: 'Your wallet is ready to connect.',
          });
        }
      }, 300);

      // Cleanup function
      return () => {
        if (detectionTimeoutRef.current) {
          clearTimeout(detectionTimeoutRef.current);
        }
        clearInterval(detectionInterval);
      };
    }

    return () => {
      mountedRef.current = false;
      if (detectionTimeoutRef.current) {
        clearTimeout(detectionTimeoutRef.current);
      }
      if (connectionTimeoutRef.current) {
        clearTimeout(connectionTimeoutRef.current);
      }
      if (pendingTransferRef.current) {
        pendingTransferRef.current.reject(new Error('Component unmounted'));
        pendingTransferRef.current = null;
      }
      logDebug('Wallet hook unmounted');
    };
  }, [detectPlugWallet, logDebug]);

  // Auto-reconnect when wallet is detected
  useEffect(() => {
    if (!walletState.detected || hasAttemptedAutoReconnect.current || walletState.connected) return;

    const attemptAutoReconnect = async () => {
      hasAttemptedAutoReconnect.current = true;
      
      logDebug('Wallet detected, attempting auto-reconnect after delay');
      
      // Wait a bit to ensure Plug is fully initialized
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const plug = getPlugInstance();
      
      if (plug) {
        await autoReconnect();
      }
    };

    attemptAutoReconnect();
  }, [walletState.detected, walletState.connected, getPlugInstance, autoReconnect, logDebug]);

  return {
    ...walletState,
    connectPlug,
    disconnect,
    transferICP,
    getBalance,
    isPlugInstalled,
    reconnectWallet,
    revalidateSession,
  };
}
